/**
 * promotions.js — Module de Promotions de Grade
 * Recherche de membre, changement de grade, historique filtrable
 */

/* ═══════════════════════════════════════════════════════════
   STATE
═══════════════════════════════════════════════════════════ */
let _promoAllMembers  = [];
let _promoAllEglises  = [];
let _promoAllRegions  = [];
let _promoHistPage    = 1;
const _promoHistLimit = 20;
let _promoHistFilters = { eglise: '', grade: '', date_from: '', date_to: '', search: '' };

/* ═══════════════════════════════════════════════════════════
   ENTRY POINT
═══════════════════════════════════════════════════════════ */
async function renderPromotions() {
  setBreadcrumb([{ label: I18n.t('promo.title') }]);
  const content = document.getElementById('pageContent');
  if (!content) return;

  content.innerHTML = `
    <div class="page-header">
      <div class="page-header-left">
        <h2>
          <i class="fas fa-level-up-alt" style="color:var(--primary);margin-right:10px"></i>
          ${I18n.t('promo.title')}
        </h2>
        <p>${I18n.lang==='en'?'Change a member\'s grade and view promotion history':'Changer le grade d\'un membre et consulter l\'historique des promotions'}</p>
      </div>
    </div>

    <!-- Onglets -->
    <div class="promo-tabs" role="tablist" style="
      display:flex;gap:4px;margin-bottom:24px;
      background:var(--bg-secondary,#F3F4F6);border-radius:12px;padding:5px">
      <button class="promo-tab active" role="tab" aria-selected="true"
        id="tabPromouvoir" onclick="promoSwitchTab('promouvoir')"
        style="flex:1;padding:9px 16px;border:none;border-radius:9px;cursor:pointer;
               font-weight:600;font-size:13px;transition:all .2s;
               background:var(--primary);color:#fff">
        <i class="fas fa-level-up-alt"></i> ${I18n.t('promo.new')}
      </button>
      <button class="promo-tab" role="tab" aria-selected="false"
        id="tabHistorique" onclick="promoSwitchTab('historique')"
        style="flex:1;padding:9px 16px;border:none;border-radius:9px;cursor:pointer;
               font-weight:600;font-size:13px;transition:all .2s;
               background:transparent;color:var(--text-muted)">
        <i class="fas fa-history"></i> ${I18n.t('promo.history')}
      </button>
    </div>

    <!-- Panneau Nouvelle Promotion -->
    <div id="panelPromouvoir">
      ${_buildPromoPanel()}
    </div>

    <!-- Panneau Historique -->
    <div id="panelHistorique" style="display:none">
      <div class="loading-spinner">
        <i class="fas fa-circle-notch fa-spin"></i>
        <p>Chargement...</p>
      </div>
    </div>
  `;

  /* Charger les données en arrière-plan */
  _promoLoadData();
}

/* ── Panneau "Nouvelle Promotion" HTML ────────────────── */
function _buildPromoPanel() {
  return `
    <div class="grid-2" style="gap:24px;align-items:start">

      <!-- Colonne gauche : recherche + résultats -->
      <div class="card" style="border:none;box-shadow:var(--shadow)">
        <div class="card-header" style="background:linear-gradient(135deg,#7C3AED,#6d28d9);color:#fff;border-radius:var(--radius) var(--radius) 0 0">
          <h3 style="color:#fff;margin:0">
            <i class="fas fa-search"></i> ${I18n.t('promo.search')}
          </h3>
        </div>
        <div class="card-body" style="padding:20px">

          <!-- Filtres -->
          <div style="display:flex;flex-direction:column;gap:12px;margin-bottom:16px">
            <div class="form-group" style="margin:0">
              <label style="font-size:12px;font-weight:600;color:var(--text-muted);text-transform:uppercase;letter-spacing:.5px">
                ${I18n.lang==='en'?'Search by last/first name':'Recherche par nom / prénom'}
              </label>
              <div style="position:relative">
                <i class="fas fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:13px"></i>
                <input type="search" id="promoSearchNom"
                  class="form-control"
                  placeholder="${I18n.lang==='en'?'Last or first name...':'Nom ou prénom...'}"
                  style="padding-left:36px"
                  oninput="promoFilterMembers()" />
              </div>
            </div>

            <div class="form-group" style="margin:0">
              <label style="font-size:12px;font-weight:600;color:var(--text-muted);text-transform:uppercase;letter-spacing:.5px">
                ${I18n.lang==='en'?'Filter by parish':'Filtrer par paroisse'}
              </label>
              <select id="promoFilterEglise" class="form-control"
                onchange="promoFilterMembers()">
                <option value="">— ${I18n.lang==='en'?'All parishes':'Toutes les paroisses'} —</option>
              </select>
            </div>
          </div>

          <!-- Résultats -->
          <div id="promoMemberResults"
            style="max-height:420px;overflow-y:auto;border:1px solid var(--border);border-radius:10px">
            <div style="padding:32px;text-align:center;color:var(--text-muted)">
              <i class="fas fa-users" style="font-size:32px;margin-bottom:8px;display:block;opacity:.4"></i>
              ${I18n.lang==='en'?'Enter a name or select a parish to search':'Entrez un nom ou sélectionnez une paroisse pour rechercher'}
            </div>
          </div>

        </div>
      </div>

      <!-- Colonne droite : fiche membre + formulaire promotion -->
      <div id="promoMemberCard" style="display:none">
        <!-- Rempli dynamiquement par promoSelectMember() -->
      </div>

      <!-- Placeholder colonne droite quand rien n'est sélectionné -->
      <div id="promoCardPlaceholder" class="card" style="border:2px dashed var(--border);box-shadow:none;background:var(--bg-secondary,#F9FAFB)">
        <div class="card-body" style="padding:48px 24px;text-align:center;color:var(--text-muted)">
          <div style="font-size:56px;margin-bottom:16px;opacity:.25">👤</div>
          <h3 style="font-size:16px;font-weight:600;margin-bottom:8px;color:var(--text-muted)">
            Aucun membre sélectionné
          </h3>
          <p style="font-size:13px;margin:0">
            Sélectionnez un membre dans la liste de gauche pour afficher sa fiche et effectuer une promotion.
          </p>
        </div>
      </div>

    </div>
  `;
}

/* ── Charger données en arrière-plan ──────────────────── */
async function _promoLoadData() {
  try {
    const [eglRes, regRes, memRes] = await Promise.all([
      API.getAll('eglises',  { limit: 500 }),
      API.getAll('regions',  { limit: 200 }),
      API.getAll('membres',  { limit: 2000 })
    ]);

    _promoAllEglises = eglRes.data  || [];
    _promoAllRegions = regRes.data  || [];
    _promoAllMembers = memRes.data  || [];

    /* Peupler le select paroisse */
    const sel = document.getElementById('promoFilterEglise');
    if (sel) {
      const sorted = [..._promoAllEglises].sort((a, b) => (a.nom || '').localeCompare(b.nom || '', 'fr'));
      sorted.forEach(e => {
        const opt = document.createElement('option');
        opt.value = e.id;
        opt.textContent = e.nom;
        sel.appendChild(opt);
      });
    }

    /* Afficher automatiquement tous si déjà un filtre actif */
    promoFilterMembers();

  } catch (err) {
    showToast('Erreur chargement données : ' + err.message, 'error');
  }
}

/* ═══════════════════════════════════════════════════════════
   RECHERCHE / FILTRE MEMBRES
═══════════════════════════════════════════════════════════ */
function promoFilterMembers() {
  const query    = (document.getElementById('promoSearchNom')?.value || '').toLowerCase().trim();
  const egliseId = document.getElementById('promoFilterEglise')?.value || '';
  const container = document.getElementById('promoMemberResults');
  if (!container) return;

  if (!query && !egliseId) {
    container.innerHTML = `
      <div style="padding:32px;text-align:center;color:var(--text-muted)">
        <i class="fas fa-users" style="font-size:32px;margin-bottom:8px;display:block;opacity:.4"></i>
        Entrez un nom ou sélectionnez une paroisse pour rechercher
      </div>`;
    return;
  }

  let results = _promoAllMembers;

  if (egliseId) {
    results = results.filter(m => m.eglise_id === egliseId);
  }
  if (query) {
    results = results.filter(m => {
      const full = `${m.prenom || ''} ${m.nom || ''}`.toLowerCase();
      return full.includes(query);
    });
  }

  /* Trier : nom ASC */
  results.sort((a, b) => (a.nom || '').localeCompare(b.nom || '', 'fr'));

  if (results.length === 0) {
    container.innerHTML = `
      <div style="padding:32px;text-align:center;color:var(--text-muted)">
        <i class="fas fa-search" style="font-size:32px;margin-bottom:8px;display:block;opacity:.3"></i>
        Aucun membre trouvé
      </div>`;
    return;
  }

  const limit = 50;
  const shown = results.slice(0, limit);

  container.innerHTML = shown.map(m => {
    const egl  = _promoAllEglises.find(e => e.id === m.eglise_id);
    const eglNom = egl ? egl.nom : '—';
    const sexeIcon = m.sexe === 'femme' ? '♀' : '♂';
    const gradeColor = _promoGradeColor(m.grade);

    return `
      <div class="promo-member-row" onclick="promoSelectMember('${m.id}')"
        style="
          display:flex;align-items:center;gap:12px;padding:10px 14px;
          cursor:pointer;transition:background .15s;border-bottom:1px solid var(--border)">
        ${memberAvatar(m, 38)}
        <div style="flex:1;min-width:0">
          <div style="font-weight:600;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            ${sexeIcon} ${m.prenom || ''} ${m.nom || ''}
          </div>
          <div style="font-size:11px;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            ${eglNom}
          </div>
        </div>
        <span class="badge ${gradeColor}" style="font-size:10px;white-space:nowrap;flex-shrink:0">
          ${m.grade || 'N/D'}
        </span>
      </div>`;
  }).join('') + (results.length > limit ? `
    <div style="padding:10px;text-align:center;font-size:12px;color:var(--text-muted)">
      … et ${results.length - limit} autres résultats. Affinez la recherche.
    </div>` : '');
}

/* ── Couleur badge grade ──────────────────────────────── */
function _promoGradeColor(grade) {
  const map = {
    'Fidèle simple': 'badge-secondary', 'Dehoto': 'badge-info',
    'Allagba': 'badge-primary', 'Senior Allagba': 'badge-primary',
    'Wolijah': 'badge-warning', 'Senior Wolijah': 'badge-warning',
    'Leader': 'badge-success', 'Senior Leader': 'badge-success',
    'Évangéliste': 'badge-gold', 'Pasteur': 'badge-danger',
    'Révérend Pasteur': 'badge-danger', 'Maman': 'badge-primary',
    'Supérieur Maman': 'badge-gold', 'Vénérable Supérieur Maman': 'badge-danger'
  };
  /* Fallback par mot-clé */
  if (map[grade]) return map[grade];
  if (!grade) return 'badge-secondary';
  const g = grade.toLowerCase();
  if (g.includes('pasteur') || g.includes('suprême')) return 'badge-danger';
  if (g.includes('évangéliste') || g.includes('maman')) return 'badge-gold';
  if (g.includes('leader')) return 'badge-success';
  if (g.includes('woli')) return 'badge-warning';
  if (g.includes('allagba')) return 'badge-primary';
  return 'badge-secondary';
}

/* ═══════════════════════════════════════════════════════════
   SÉLECTION D'UN MEMBRE
═══════════════════════════════════════════════════════════ */
function promoSelectMember(memberId) {
  const m = _promoAllMembers.find(x => x.id === memberId);
  if (!m) return;

  /* Highlight ligne sélectionnée */
  document.querySelectorAll('.promo-member-row').forEach(r => {
    r.style.background = '';
  });
  const rows = document.querySelectorAll('.promo-member-row');
  rows.forEach(r => {
    if (r.getAttribute('onclick')?.includes(memberId)) {
      r.style.background = 'rgba(124,58,237,.08)';
    }
  });

  /* Cacher placeholder, afficher fiche */
  const placeholder = document.getElementById('promoCardPlaceholder');
  const card        = document.getElementById('promoMemberCard');
  if (placeholder) placeholder.style.display = 'none';
  if (!card) return;
  card.style.display = '';

  const egl    = _promoAllEglises.find(e => e.id === m.eglise_id);
  const reg    = _promoAllRegions.find(r => r.id === egl?.region_id);
  const grades = m.sexe === 'femme' ? GRADES_FEMME : GRADES_HOMME;
  const currentIdx = grades.indexOf(m.grade);

  card.innerHTML = `
    <!-- Fiche identité -->
    <div class="card" style="border:none;box-shadow:var(--shadow);margin-bottom:16px">
      <div class="card-header" style="background:linear-gradient(135deg,#1A5276,#2471A3);color:#fff;border-radius:var(--radius) var(--radius) 0 0">
        <h3 style="color:#fff;margin:0"><i class="fas fa-id-card"></i> Fiche Membre</h3>
      </div>
      <div class="card-body" style="padding:20px">
        <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px">
          ${memberAvatar(m, 64)}
          <div>
            <h3 style="margin:0 0 4px;font-size:17px;font-weight:700">
              ${m.prenom || ''} ${m.nom || ''}
            </h3>
            <div style="font-size:12px;color:var(--text-muted)">
              ${m.sexe === 'femme' ? '♀ Femme' : '♂ Homme'} · ${m.date_naissance ? formatDateShort(m.date_naissance) : 'Date N/D'}
            </div>
          </div>
        </div>

        <div class="detail-grid" style="grid-template-columns:1fr 1fr;gap:10px 16px">
          <div>
            <span style="font-size:11px;color:var(--text-muted);font-weight:600;text-transform:uppercase">Paroisse</span>
            <p style="margin:2px 0;font-size:13px;font-weight:500">${egl?.nom || '—'}</p>
          </div>
          <div>
            <span style="font-size:11px;color:var(--text-muted);font-weight:600;text-transform:uppercase">Région</span>
            <p style="margin:2px 0;font-size:13px;font-weight:500">${reg?.nom || '—'}</p>
          </div>
          <div>
            <span style="font-size:11px;color:var(--text-muted);font-weight:600;text-transform:uppercase">Pays</span>
            <p style="margin:2px 0;font-size:13px;font-weight:500">${egl?.pays || m.pays || '—'}</p>
          </div>
          <div>
            <span style="font-size:11px;color:var(--text-muted);font-weight:600;text-transform:uppercase">Statut</span>
            <p style="margin:2px 0">${statutBadge(m.statut || 'actif')}</p>
          </div>
        </div>

        <div style="margin-top:12px;padding:12px;background:var(--bg-secondary,#F9FAFB);border-radius:8px;border:1px solid var(--border)">
          <span style="font-size:11px;color:var(--text-muted);font-weight:600;text-transform:uppercase;display:block;margin-bottom:4px">
            Grade actuel
          </span>
          ${gradeBadge(m.grade || 'Non défini')}
          ${currentIdx >= 0 ? `<span style="font-size:11px;color:var(--text-muted);margin-left:8px">
            (rang ${currentIdx + 1}/${grades.length})
          </span>` : ''}
        </div>
      </div>
    </div>

    <!-- Formulaire promotion -->
    <div class="card" style="border:2px solid var(--primary);box-shadow:0 0 0 4px rgba(124,58,237,.08)">
      <div class="card-header" style="background:linear-gradient(135deg,#7C3AED,#9333EA);color:#fff;border-radius:var(--radius) var(--radius) 0 0">
        <h3 style="color:#fff;margin:0"><i class="fas fa-level-up-alt"></i> Nouvelle Promotion</h3>
      </div>
      <div class="card-body" style="padding:20px">

        <div class="form-group" style="margin-bottom:16px">
          <label style="font-weight:600">Nouveau grade <span style="color:var(--danger)">*</span></label>
          <select id="promoNewGrade" class="form-control" onchange="promoPreviewChange('${m.id}')">
            <option value="">— Sélectionner un grade —</option>
            ${grades.map((g, i) => `
              <option value="${g}" ${g === m.grade ? 'disabled style="opacity:.4"' : ''}
                data-rank="${i}">
                ${g}${i === currentIdx ? ' ← actuel' : (i > currentIdx ? ' ↑' : ' ↓')}
              </option>`
            ).join('')}
          </select>
        </div>

        <div class="form-group" style="margin-bottom:16px">
          <label style="font-weight:600">Motif / Observation</label>
          <textarea id="promoMotif" class="form-control" rows="2"
            placeholder="Ex : Promotion ordinaire lors du colloque régional..."
            style="resize:vertical"></textarea>
        </div>

        <!-- Aperçu du changement -->
        <div id="promoPreview" style="display:none;margin-bottom:16px;
          padding:12px;background:linear-gradient(135deg,#f0fdf4,#dcfce7);
          border:1px solid #86efac;border-radius:10px">
        </div>

        <button class="btn btn-primary" style="width:100%;padding:12px;font-size:14px;font-weight:600"
          onclick="promoConfirm('${m.id}')">
          <i class="fas fa-check-circle"></i>
          Confirmer la Promotion
        </button>

        <button class="btn btn-secondary" style="width:100%;margin-top:8px;font-size:13px"
          onclick="promoCancel()">
          <i class="fas fa-times"></i> Annuler
        </button>
      </div>
    </div>
  `;
}

/* ── Aperçu de la promotion ───────────────────────────── */
function promoPreviewChange(memberId) {
  const m = _promoAllMembers.find(x => x.id === memberId);
  if (!m) return;
  const newGrade = document.getElementById('promoNewGrade')?.value;
  const preview  = document.getElementById('promoPreview');
  if (!preview) return;
  if (!newGrade) { preview.style.display = 'none'; return; }

  const grades  = m.sexe === 'femme' ? GRADES_FEMME : GRADES_HOMME;
  const oldIdx  = grades.indexOf(m.grade);
  const newIdx  = grades.indexOf(newGrade);
  const diff    = newIdx - oldIdx;
  const arrow   = diff > 0 ? '⬆️' : diff < 0 ? '⬇️' : '↔️';
  const label   = diff > 0 ? `Promotion (+${diff} rang${diff > 1 ? 's' : ''})` :
                  diff < 0 ? `Rétrogradation (${diff} rang${diff < -1 ? 's' : ''})` : 'Même rang';
  const color   = diff > 0 ? '#15803D' : diff < 0 ? '#DC2626' : '#92400E';

  preview.style.display = '';
  preview.innerHTML = `
    <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <div style="flex:1;min-width:120px">
        <div style="font-size:10px;color:var(--text-muted);font-weight:600;text-transform:uppercase;margin-bottom:2px">Ancien grade</div>
        ${gradeBadge(m.grade || '—')}
      </div>
      <div style="font-size:20px">${arrow}</div>
      <div style="flex:1;min-width:120px">
        <div style="font-size:10px;color:var(--text-muted);font-weight:600;text-transform:uppercase;margin-bottom:2px">Nouveau grade</div>
        ${gradeBadge(newGrade)}
      </div>
      <div style="font-size:12px;font-weight:700;color:${color};padding:4px 10px;background:rgba(0,0,0,.05);border-radius:20px">
        ${label}
      </div>
    </div>`;
}

/* ── Annuler ──────────────────────────────────────────── */
function promoCancel() {
  const card = document.getElementById('promoMemberCard');
  const placeholder = document.getElementById('promoCardPlaceholder');
  if (card) card.style.display = 'none';
  if (placeholder) placeholder.style.display = '';
  document.querySelectorAll('.promo-member-row').forEach(r => { r.style.background = ''; });
}

/* ═══════════════════════════════════════════════════════════
   CONFIRMATION DE LA PROMOTION
═══════════════════════════════════════════════════════════ */
async function promoConfirm(memberId) {
  const m = _promoAllMembers.find(x => x.id === memberId);
  if (!m) return;

  const newGrade = document.getElementById('promoNewGrade')?.value;
  const motif    = document.getElementById('promoMotif')?.value.trim() || '';

  if (!newGrade) {
    showToast('Veuillez sélectionner un nouveau grade', 'warning'); return;
  }
  if (newGrade === m.grade) {
    showToast('Le nouveau grade doit être différent du grade actuel', 'warning'); return;
  }

  const btn = document.querySelector('#promoMemberCard .btn-primary');
  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Enregistrement...'; }

  try {
    const egl     = _promoAllEglises.find(e => e.id === m.eglise_id);
    const reg     = _promoAllRegions.find(r => r.id === egl?.region_id);
    const admin   = Auth.getCurrentUser();
    const now     = new Date().toISOString().split('T')[0];

    /* 1. GET membre complet puis PUT (PATCH non autorisé par l'API) */
    const memFull = await API.getById('membres', m.id);
    await API.update('membres', m.id, { ...memFull, grade: newGrade });

    /* 2. Créer enregistrement promotion */
    const promoRecord = {
      id:             generateId('promo'),
      membre_id:      m.id,
      membre_nom:     `${m.prenom || ''} ${m.nom || ''}`.trim(),
      membre_prenom:  m.prenom || '',
      eglise_id:      m.eglise_id || '',
      eglise_nom:     egl?.nom || '',
      region_id:      reg?.id || '',
      region_nom:     reg?.nom || '',
      continent:      egl?.continent || '',
      pays:           egl?.pays || m.pays || '',
      ancien_grade:   m.grade || '',
      nouveau_grade:  newGrade,
      date_promotion: now,
      admin_id:       admin?.id || '',
      admin_nom:      admin?.nom || admin?.username || 'Système',
      motif:          motif
    };

    await API.create('promotions', promoRecord);

    /* 3. Mettre à jour le tableau local */
    const idx = _promoAllMembers.findIndex(x => x.id === m.id);
    if (idx >= 0) _promoAllMembers[idx] = { ..._promoAllMembers[idx], grade: newGrade };

    showToast(`✅ Promotion de ${m.prenom} ${m.nom} enregistrée avec succès`, 'success', 4000);

    /* 4. Rafraîchir la fiche membre */
    promoSelectMember(m.id);
    promoFilterMembers();

    /* Réinitialiser formulaire */
    setTimeout(() => {
      const sg = document.getElementById('promoNewGrade');
      const sm = document.getElementById('promoMotif');
      const pv = document.getElementById('promoPreview');
      if (sg) sg.value = '';
      if (sm) sm.value = '';
      if (pv) pv.style.display = 'none';
    }, 100);

  } catch (err) {
    showToast('Erreur lors de la promotion : ' + err.message, 'error');
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check-circle"></i> Confirmer la Promotion'; }
  }
}

/* ═══════════════════════════════════════════════════════════
   ONGLETS
═══════════════════════════════════════════════════════════ */
function promoSwitchTab(tab) {
  const tabs = document.querySelectorAll('.promo-tab');
  tabs.forEach(t => {
    const isActive = t.id === `tab${tab.charAt(0).toUpperCase() + tab.slice(1)}`;
    t.style.background = isActive ? 'var(--primary)' : 'transparent';
    t.style.color      = isActive ? '#fff' : 'var(--text-muted)';
    t.setAttribute('aria-selected', isActive);
    t.classList.toggle('active', isActive);
  });

  const pnlPromouvoir = document.getElementById('panelPromouvoir');
  const pnlHistorique = document.getElementById('panelHistorique');
  if (!pnlPromouvoir || !pnlHistorique) return;

  if (tab === 'promouvoir') {
    pnlPromouvoir.style.display = '';
    pnlHistorique.style.display = 'none';
  } else {
    pnlPromouvoir.style.display = 'none';
    pnlHistorique.style.display = '';
    _promoHistPage = 1;
    _promoHistFilters = { eglise: '', grade: '', date_from: '', date_to: '', search: '' };
    _renderHistorique();
  }
}

/* ═══════════════════════════════════════════════════════════
   HISTORIQUE DES PROMOTIONS
═══════════════════════════════════════════════════════════ */
async function _renderHistorique() {
  const panel = document.getElementById('panelHistorique');
  if (!panel) return;

  /* HTML fixe : filtres + tableau */
  panel.innerHTML = `
    <!-- Filtres -->
    <div class="card" style="margin-bottom:20px;border:none;box-shadow:var(--shadow)">
      <div class="card-body" style="padding:16px">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;align-items:end">

          <div class="form-group" style="margin:0">
            <label style="font-size:11px;font-weight:600;color:var(--text-muted);text-transform:uppercase">Recherche</label>
            <div style="position:relative">
              <i class="fas fa-search" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:12px"></i>
              <input type="search" id="promoHistSearch" class="form-control"
                placeholder="Nom membre..." style="padding-left:32px"
                oninput="promoHistApplyFilter()" />
            </div>
          </div>

          <div class="form-group" style="margin:0">
            <label style="font-size:11px;font-weight:600;color:var(--text-muted);text-transform:uppercase">Paroisse</label>
            <select id="promoHistEglise" class="form-control" onchange="promoHistApplyFilter()">
              <option value="">Toutes</option>
              ${[..._promoAllEglises].sort((a,b) => (a.nom||'').localeCompare(b.nom||'','fr'))
                .map(e => `<option value="${e.id}">${e.nom}</option>`).join('')}
            </select>
          </div>

          <div class="form-group" style="margin:0">
            <label style="font-size:11px;font-weight:600;color:var(--text-muted);text-transform:uppercase">Grade promu</label>
            <select id="promoHistGrade" class="form-control" onchange="promoHistApplyFilter()">
              <option value="">Tous grades</option>
              <optgroup label="Homme">
                ${GRADES_HOMME.map(g => `<option value="${g}">${g}</option>`).join('')}
              </optgroup>
              <optgroup label="Femme">
                ${GRADES_FEMME.map(g => `<option value="${g}">${g}</option>`).join('')}
              </optgroup>
            </select>
          </div>

          <div class="form-group" style="margin:0">
            <label style="font-size:11px;font-weight:600;color:var(--text-muted);text-transform:uppercase">Du</label>
            <input type="date" id="promoHistDateFrom" class="form-control" onchange="promoHistApplyFilter()" />
          </div>

          <div class="form-group" style="margin:0">
            <label style="font-size:11px;font-weight:600;color:var(--text-muted);text-transform:uppercase">Au</label>
            <input type="date" id="promoHistDateTo" class="form-control" onchange="promoHistApplyFilter()" />
          </div>

          <div>
            <button class="btn btn-secondary" onclick="promoHistReset()" style="width:100%;font-size:12px">
              <i class="fas fa-undo"></i> Réinitialiser
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Tableau -->
    <div class="card" style="border:none;box-shadow:var(--shadow)">
      <div class="card-header" style="display:flex;align-items:center;justify-content:space-between">
        <h3 style="margin:0"><i class="fas fa-history" style="color:var(--primary)"></i> Historique des Promotions</h3>
        <span id="promoHistCount" style="font-size:12px;color:var(--text-muted)"></span>
      </div>
      <div class="card-body" style="padding:0">
        <div id="promoHistTableContainer">
          <div class="loading-spinner" style="padding:40px">
            <i class="fas fa-circle-notch fa-spin"></i>
            <p>Chargement...</p>
          </div>
        </div>
      </div>
    </div>
  `;

  promoHistApplyFilter();
}

/* ── Appliquer les filtres et charger ─────────────────── */
async function promoHistApplyFilter() {
  _promoHistFilters.search    = document.getElementById('promoHistSearch')?.value || '';
  _promoHistFilters.eglise    = document.getElementById('promoHistEglise')?.value || '';
  _promoHistFilters.grade     = document.getElementById('promoHistGrade')?.value || '';
  _promoHistFilters.date_from = document.getElementById('promoHistDateFrom')?.value || '';
  _promoHistFilters.date_to   = document.getElementById('promoHistDateTo')?.value || '';
  _promoHistPage = 1;
  await _promoHistFetch();
}

function promoHistReset() {
  const fields = ['promoHistSearch', 'promoHistEglise', 'promoHistGrade', 'promoHistDateFrom', 'promoHistDateTo'];
  fields.forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  _promoHistFilters = { eglise: '', grade: '', date_from: '', date_to: '', search: '' };
  _promoHistPage = 1;
  _promoHistFetch();
}

/* ── Fetch + rendu tableau ────────────────────────────── */
async function _promoHistFetch() {
  const container = document.getElementById('promoHistTableContainer');
  if (!container) return;
  container.innerHTML = `<div class="loading-spinner" style="padding:40px"><i class="fas fa-circle-notch fa-spin"></i><p>Chargement...</p></div>`;

  try {
    /* Récupérer toutes les promotions côté client puis filtrer */
    const res  = await API.getAll('promotions', { limit: 2000 });
    let rows   = res.data || [];

    /* Filtres client */
    const { search, eglise, grade, date_from, date_to } = _promoHistFilters;
    if (search) {
      const q = search.toLowerCase();
      rows = rows.filter(r => (r.membre_nom || '').toLowerCase().includes(q));
    }
    if (eglise)    rows = rows.filter(r => r.eglise_id === eglise);
    if (grade)     rows = rows.filter(r => r.nouveau_grade === grade);
    if (date_from) rows = rows.filter(r => r.date_promotion >= date_from);
    if (date_to)   rows = rows.filter(r => r.date_promotion <= date_to);

    /* Trier : plus récent en premier */
    rows.sort((a, b) => (b.date_promotion || '').localeCompare(a.date_promotion || ''));

    const total = rows.length;
    const start = (_promoHistPage - 1) * _promoHistLimit;
    const paged = rows.slice(start, start + _promoHistLimit);

    const countEl = document.getElementById('promoHistCount');
    if (countEl) countEl.textContent = `${total} promotion${total !== 1 ? 's' : ''}`;

    if (paged.length === 0) {
      container.innerHTML = `
        <div style="padding:48px;text-align:center;color:var(--text-muted)">
          <i class="fas fa-history" style="font-size:40px;opacity:.25;display:block;margin-bottom:12px"></i>
          <p style="font-size:14px">Aucune promotion trouvée</p>
        </div>`;
      return;
    }

    /* Table responsive */
    container.innerHTML = `
      <div style="overflow-x:auto">
        <table class="data-table" style="width:100%;min-width:700px">
          <thead>
            <tr>
              <th style="width:180px">Membre</th>
              <th>Paroisse</th>
              <th style="width:160px">Ancien grade</th>
              <th style="width:160px">Nouveau grade</th>
              <th style="width:100px">Date</th>
              <th style="width:120px">Admin</th>
              <th style="width:180px">Motif</th>
            </tr>
          </thead>
          <tbody>
            ${paged.map(r => `
              <tr style="transition:background .15s" onmouseover="this.style.background='var(--accent,#F3F4F6)'" onmouseout="this.style.background=''">
                <td>
                  <div style="font-weight:600;font-size:13px">${r.membre_nom || '—'}</div>
                  ${r.pays ? `<div style="font-size:11px;color:var(--text-muted)">${r.pays}</div>` : ''}
                </td>
                <td style="font-size:12px">${r.eglise_nom || '—'}</td>
                <td>${gradeBadge(r.ancien_grade || '—')}</td>
                <td>${gradeBadge(r.nouveau_grade || '—')}</td>
                <td style="font-size:12px;white-space:nowrap">${formatDateShort(r.date_promotion)}</td>
                <td style="font-size:12px">${r.admin_nom || '—'}</td>
                <td style="font-size:11px;color:var(--text-muted);max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${r.motif || ''}">
                  ${r.motif || '<em style="opacity:.5">—</em>'}
                </td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
      ${_promoHistPagination(total)}
    `;

  } catch (err) {
    container.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erreur</h3><p>${err.message}</p></div>`;
  }
}

/* ── Pagination historique ────────────────────────────── */
function _promoHistPagination(total) {
  const pages = Math.ceil(total / _promoHistLimit);
  if (pages <= 1) return '';
  let btns = '';
  for (let i = 1; i <= pages; i++) {
    const active = i === _promoHistPage;
    btns += `<button onclick="promoHistGoPage(${i})" style="
      min-width:32px;padding:4px 8px;border:1px solid ${active ? 'var(--primary)' : 'var(--border)'};
      background:${active ? 'var(--primary)' : 'transparent'};
      color:${active ? '#fff' : 'var(--text-primary)'};
      border-radius:6px;cursor:pointer;font-size:12px;font-weight:${active ? '700' : '400'}">${i}</button>`;
  }
  return `<div style="display:flex;justify-content:center;gap:4px;padding:14px">${btns}</div>`;
}

function promoHistGoPage(page) {
  _promoHistPage = page;
  _promoHistFetch();
}

/* ═══════════════════════════════════════════════════════════
   ENREGISTREMENT DU HANDLER "Nouvelle promotion"
═══════════════════════════════════════════════════════════ */
if (typeof App !== 'undefined') {
  App.registerAddHandler('promotions', () => {
    promoSwitchTab('promouvoir');
    document.getElementById('promoSearchNom')?.focus();
  });
}
