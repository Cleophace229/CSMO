/**
 * geo.js — Données géographiques : Continents & Pays
 * Structure extensible — ajouter des pays dans le tableau correspondant
 * Usage : GEO.continents, GEO.paysByCont('Afrique'), GEO.allPays()
 */
const GEO = (() => {

  const DATA = {
    'Afrique': [
      'Algérie','Angola','Bénin','Botswana','Burkina Faso','Burundi',
      'Cabo Verde','Cameroun','Centrafrique','Comores','Congo (Brazzaville)',
      'Congo (RDC)','Côte d\'Ivoire','Djibouti','Égypte','Érythrée',
      'Éthiopie','Gabon','Gambie','Ghana','Guinée','Guinée-Bissau',
      'Guinée équatoriale','Kenya','Lesotho','Libéria','Libye','Madagascar',
      'Malawi','Mali','Maroc','Maurice','Mauritanie','Mozambique','Namibie',
      'Niger','Nigéria','Ouganda','Rwanda','São Tomé-et-Príncipe','Sénégal',
      'Seychelles','Sierra Leone','Somalie','Soudan','Soudan du Sud',
      'Swaziland','Tanzanie','Tchad','Togo','Tunisie','Zambie','Zimbabwe'
    ],
    'Europe': [
      'Albanie','Allemagne','Andorre','Arménie','Autriche','Azerbaïdjan',
      'Belgique','Biélorussie','Bosnie-Herzégovine','Bulgarie','Chypre',
      'Croatie','Danemark','Espagne','Estonie','Finlande','France',
      'Géorgie','Grèce','Hongrie','Irlande','Islande','Italie','Kosovo',
      'Lettonie','Liechtenstein','Lituanie','Luxembourg','Macédoine du Nord',
      'Malte','Moldavie','Monaco','Monténégro','Norvège','Pays-Bas',
      'Pologne','Portugal','République tchèque','Roumanie','Royaume-Uni',
      'Russie','Saint-Marin','Serbie','Slovaquie','Slovénie','Suède',
      'Suisse','Turquie','Ukraine','Vatican'
    ],
    'Amérique du Nord': [
      'Antigua-et-Barbuda','Bahamas','Barbade','Belize','Canada','Costa Rica',
      'Cuba','Dominique','El Salvador','États-Unis','Grenade','Guatemala',
      'Haïti','Honduras','Jamaïque','Mexique','Nicaragua','Panama',
      'République dominicaine','Saint-Kitts-et-Nevis','Saint-Vincent-et-les-Grenadines',
      'Sainte-Lucie','Trinité-et-Tobago'
    ],
    'Amérique du Sud': [
      'Argentine','Bolivie','Brésil','Chili','Colombie','Équateur',
      'Guyana','Paraguay','Pérou','Suriname','Uruguay','Venezuela'
    ],
    'Asie': [
      'Afghanistan','Arabie saoudite','Arménie','Azerbaïdjan','Bahreïn',
      'Bangladesh','Bhoutan','Birmanie','Brunei','Cambodge','Chine',
      'Corée du Nord','Corée du Sud','Émirats arabes unis','Géorgie',
      'Inde','Indonésie','Irak','Iran','Israël','Japon','Jordanie',
      'Kazakhstan','Kirghizistan','Koweït','Laos','Liban','Malaisie',
      'Maldives','Mongolie','Népal','Oman','Ouzbékistan','Pakistan',
      'Palestine','Philippines','Qatar','Singapour','Sri Lanka','Syrie',
      'Tadjikistan','Taïwan','Thaïlande','Timor oriental','Turkménistan',
      'Viêt Nam','Yémen'
    ],
    'Océanie': [
      'Australie','Fidji','Kiribati','Îles Marshall','Îles Salomon',
      'Micronésie','Nauru','Nouvelle-Zélande','Palaos','Papouasie-Nouvelle-Guinée',
      'Samoa','Tonga','Tuvalu','Vanuatu'
    ],
    'Moyen-Orient': [
      'Arabie saoudite','Bahreïn','Chypre','Émirats arabes unis','Irak',
      'Iran','Israël','Jordanie','Koweït','Liban','Oman','Palestine',
      'Qatar','Syrie','Turquie','Yémen'
    ]
  };

  /* Couleurs par continent (pour graphiques) */
  const COLORS = {
    'Afrique':          '#10B981',
    'Europe':           '#3B82F6',
    'Amérique du Nord': '#F59E0B',
    'Amérique du Sud':  '#EF4444',
    'Asie':             '#8B5CF6',
    'Océanie':          '#06B6D4',
    'Moyen-Orient':     '#F97316'
  };

  /* Icônes par continent */
  const ICONS = {
    'Afrique':          'fa-globe-africa',
    'Europe':           'fa-globe-europe',
    'Amérique du Nord': 'fa-globe-americas',
    'Amérique du Sud':  'fa-globe-americas',
    'Asie':             'fa-globe-asia',
    'Océanie':          'fa-globe',
    'Moyen-Orient':     'fa-globe'
  };

  return {
    /** Liste des continents */
    get continents() { return Object.keys(DATA); },

    /** Pays d'un continent */
    paysByCont(continent) { return DATA[continent] || []; },

    /** Tous les pays (flat), triés */
    allPays() {
      return [...new Set(Object.values(DATA).flat())].sort((a, b) =>
        a.localeCompare(b, 'fr')
      );
    },

    /** Continent d'un pays */
    contOfPays(pays) {
      for (const [cont, list] of Object.entries(DATA)) {
        if (list.includes(pays)) return cont;
      }
      return '';
    },

    /** Couleur d'un continent */
    color(continent) { return COLORS[continent] || '#6B7280'; },

    /** Icône d'un continent */
    icon(continent)  { return ICONS[continent]  || 'fa-globe'; },

    /**
     * Génère le HTML d'un sélecteur de continent
     * @param {string} id        — id HTML du select
     * @param {string} selected  — valeur sélectionnée
     * @param {string} onchange  — handler onchange JS
     */
    continentSelect(id, selected = '', onchange = '') {
      const opts = this.continents.map(c =>
        `<option value="${c}" ${c === selected ? 'selected' : ''}>${c}</option>`
      ).join('');
      return `<select class="form-control" id="${id}"
        ${onchange ? `onchange="${onchange}"` : ''}
        aria-label="Continent">
        <option value="">— Continent —</option>
        ${opts}
      </select>`;
    },

    /**
     * Génère le HTML d'un sélecteur de pays
     * @param {string} id        — id HTML du select
     * @param {string} continent — filtrer par continent ('' = tous)
     * @param {string} selected  — valeur sélectionnée
     */
    paysSelect(id, continent = '', selected = '') {
      const list = continent ? this.paysByCont(continent) : this.allPays();
      const opts = list.map(p =>
        `<option value="${p}" ${p === selected ? 'selected' : ''}>${p}</option>`
      ).join('');
      return `<select class="form-control" id="${id}" aria-label="Pays">
        <option value="">— Pays —</option>
        ${opts}
      </select>`;
    },

    /**
     * Met à jour dynamiquement un select pays quand le continent change
     * @param {string} continentSelectId
     * @param {string} paysSelectId
     * @param {string} currentPays  — valeur à pré-sélectionner
     */
    bindContinentToPays(continentSelectId, paysSelectId, currentPays = '') {
      const contSel = document.getElementById(continentSelectId);
      const paysSel = document.getElementById(paysSelectId);
      if (!contSel || !paysSel) return;

      const _refresh = (cont) => {
        const list = cont ? this.paysByCont(cont) : this.allPays();
        paysSel.innerHTML = '<option value="">— Pays —</option>' +
          list.map(p =>
            `<option value="${p}" ${p === currentPays ? 'selected' : ''}>${p}</option>`
          ).join('');
      };

      contSel.addEventListener('change', () => {
        currentPays = ''; // reset pays courant quand on change de continent
        _refresh(contSel.value);
      });

      // Initialiser avec le continent actuel
      _refresh(contSel.value);
    }
  };
})();
