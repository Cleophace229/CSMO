/**
 * enfants_aj.js — Enfants de l'Ami de Jésus (AJ)
 *
 * RÈGLES D'ACCÈS :
 *  - Compte église : voit UNIQUEMENT ses propres données, peut AJOUTER / MODIFIER / SUPPRIMER
 *  - Admin / Super-admin : page BLOQUÉE (réservée aux églises) — ne devrait pas arriver ici
 *
 * Tables utilisées :
 *  - enfants_aj    (enfants inscrits)
 *  - encadreurs_aj (encadreurs avec coordonnées)
 *
 * Colonnes enfants_aj    : id, nom, prenom, sexe, date_naissance, eglise_id,
 *                          classe, date_inscription, nom_parent, telephone_parent,
 *                          statut, notes
 * Colonnes encadreurs_aj : id, nom, prenom, sexe, grade, role_encadrement,
 *                          telephone, email, eglise_id, date_nomination, statut, notes
 */

App.registerAddHandler('enfants_aj', () => showEnfantAJForm());

let _ajTab        = 'enfants'; // onglet actif : 'enfants' | 'encadreurs'
let _ajEnfants    = [];
let _ajEncadreurs = [];
let _ajEgliseId   = '';        // id de l'église connectée

/* ══════════════════════════════════════════════════════════════════
   RENDU PRINCIPAL
══════════════════════════════════════════════════════════════════ */
async function renderEnfantsAJ(params = {}) {
  setBreadcrumb([{ label: "Enfants de l'Ami de Jésus" }]);
  const content = document.getElementById('pageContent');
  const user    = Auth.getCurrentUser();

  /* Seuls les comptes église ont accès */
  const isEglise = user && user.eglise_id &&
                   user.role !== 'super_admin' && user.role !== 'admin';

  if (!isEglise) {
    content.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-lock" style="color:var(--warning);font-size:48px"></i>
        <h3>Accès réservé aux paroisses</h3>
        <p>Cette section est exclusivement destinée aux comptes paroisses.<br>
           Les administrateurs n'y ont pas accès.</p>
        <button class="btn btn-primary" onclick="App.navigate('dashboard')">
          <i class="fas fa-home"></i> Retour au tableau de bord
        </button>
      </div>`;
    return;
  }

  _ajEgliseId = user.eglise_id;

  content.innerHTML = `<div class="loading-spinner">
    <i class="fas fa-circle-notch fa-spin"></i><p>Chargement...</p></div>`;

  try {
    /* Récupérer uniquement les données de cette église */
    const [enfRes, encRes, eglRes] = await Promise.all([
      API.getAll('enfants_aj',    { limit: 500 }),
      API.getAll('encadreurs_aj', { limit: 500 }),
      API.getById('eglises', _ajEgliseId).catch(() => ({ nom: '' }))
    ]);

    /* Filtrer par église connectée */
    _ajEnfants    = (enfRes.data || []).filter(e => e.eglise_id === _ajEgliseId);
    _ajEncadreurs = (encRes.data || []).filter(e => e.eglise_id === _ajEgliseId);
    const nomEglise = eglRes.nom || '';

    if (params.tab) _ajTab = params.tab;

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-child" style="margin-right:10px"></i>Enfants de l'Ami de Jésus
          </h2>
          <p style="color:var(--text-muted)">
            ${nomEglise ? `Paroisse : <strong>${nomEglise}</strong>` : 'Votre paroisse'}
          </p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-primary" onclick="showEnfantAJForm()" id="btnAjAjouter">
            <i class="fas fa-plus"></i>
            ${_ajTab === 'encadreurs' ? 'Nouvel encadreur' : 'Nouvel enfant'}
          </button>
        </div>
      </div>

      <!-- Bannière AJ -->
      <div style="background:linear-gradient(135deg,#6d28d9,#7c3aed,#4f46e5);
        border-radius:16px;padding:20px 24px;margin-bottom:24px;color:#fff;
        display:flex;align-items:center;gap:16px">
        <div style="font-size:44px;flex-shrink:0">✝️</div>
        <div style="flex:1">
          <div style="font-weight:800;font-size:17px;letter-spacing:.3px">
            Enfants de l'Ami de Jésus — AJ
          </div>
          <div style="font-size:12px;opacity:.88;margin-top:4px">
            Jeunesse de la Communauté Céleste · Gestion locale à la paroisse
          </div>
          <div style="display:flex;gap:14px;margin-top:12px;flex-wrap:wrap">
            <span style="background:rgba(255,255,255,0.2);padding:4px 14px;
              border-radius:20px;font-size:13px;font-weight:600">
              <i class="fas fa-child"></i> ${_ajEnfants.length} enfant(s)
            </span>
            <span style="background:rgba(255,255,255,0.2);padding:4px 14px;
              border-radius:20px;font-size:13px;font-weight:600">
              <i class="fas fa-user-tie"></i> ${_ajEncadreurs.length} encadreur(s)
            </span>
          </div>
        </div>
      </div>

      <!-- Onglets Enfants / Encadreurs -->
      <div style="display:flex;gap:2px;border-bottom:2px solid var(--border);
                  margin-bottom:20px">
        <button onclick="switchAJTab('enfants')" id="ajTabEnfants"
          style="padding:10px 22px;border:none;background:none;cursor:pointer;
            font-weight:600;font-size:14px;font-family:inherit;
            border-bottom:3px solid ${_ajTab==='enfants' ? 'var(--primary)' : 'transparent'};
            color:${_ajTab==='enfants' ? 'var(--primary)' : 'var(--text-muted)'};
            margin-bottom:-2px;transition:all .2s">
          <i class="fas fa-child"></i> Enfants (${_ajEnfants.length})
        </button>
        <button onclick="switchAJTab('encadreurs')" id="ajTabEncadreurs"
          style="padding:10px 22px;border:none;background:none;cursor:pointer;
            font-weight:600;font-size:14px;font-family:inherit;
            border-bottom:3px solid ${_ajTab==='encadreurs' ? 'var(--primary)' : 'transparent'};
            color:${_ajTab==='encadreurs' ? 'var(--primary)' : 'var(--text-muted)'};
            margin-bottom:-2px;transition:all .2s">
          <i class="fas fa-user-tie"></i> Encadreurs (${_ajEncadreurs.length})
        </button>
      </div>

      <!-- Barre de recherche -->
      <div class="page-search" style="margin-bottom:18px;flex-wrap:wrap;gap:8px">
        <div class="search-input-wrapper" style="flex:1;min-width:200px">
          <i class="fas fa-search"></i>
          <input type="text" id="ajSearch" placeholder="Rechercher..."
            oninput="filterAJ()" />
        </div>
        <select class="form-control" id="ajStatutFilter"
          style="width:150px" onchange="filterAJ()">
          <option value="">Tous les statuts</option>
          <option value="actif">Actifs</option>
          <option value="inactif">Inactifs</option>
        </select>
      </div>

      <!-- Zone de contenu dynamique -->
      <div id="ajContent">
        ${_ajTab === 'enfants'
          ? _renderTableEnfants(_ajEnfants)
          : _renderTableEncadreurs(_ajEncadreurs)}
      </div>
    `;

    /* Stocker pour le filtrage */
    window._ajData = { enfants: _ajEnfants, encadreurs: _ajEncadreurs };

  } catch (err) {
    content.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
        <h3>Erreur de chargement</h3>
        <p>${err.message}</p>
        <button class="btn btn-primary" onclick="renderEnfantsAJ()">
          <i class="fas fa-redo"></i> Réessayer
        </button>
      </div>`;
  }
}

/* ══════════════════════════════════════════════════════════════════
   SWITCH D'ONGLET
══════════════════════════════════════════════════════════════════ */
function switchAJTab(tab) {
  _ajTab = tab;

  /* Styles des onglets */
  ['enfants', 'encadreurs'].forEach(t => {
    const btn = document.getElementById(
      t === 'enfants' ? 'ajTabEnfants' : 'ajTabEncadreurs'
    );
    if (!btn) return;
    const actif = t === tab;
    btn.style.borderBottomColor = actif ? 'var(--primary)' : 'transparent';
    btn.style.color             = actif ? 'var(--primary)' : 'var(--text-muted)';
  });

  /* Libellé bouton Ajouter */
  const btnAj = document.getElementById('btnAjAjouter');
  if (btnAj) {
    btnAj.innerHTML = `<i class="fas fa-plus"></i> ${
      tab === 'encadreurs' ? 'Nouvel encadreur' : 'Nouvel enfant'
    }`;
  }

  /* Réinitialiser la recherche */
  const s = document.getElementById('ajSearch');
  if (s) s.value = '';
  const sf = document.getElementById('ajStatutFilter');
  if (sf) sf.value = '';

  /* Rafraîchir le tableau */
  const d = window._ajData || {};
  const data = tab === 'enfants' ? (d.enfants || []) : (d.encadreurs || []);
  const zone = document.getElementById('ajContent');
  if (zone) {
    zone.innerHTML = tab === 'enfants'
      ? _renderTableEnfants(data)
      : _renderTableEncadreurs(data);
  }
}

/* ══════════════════════════════════════════════════════════════════
   FILTRE
══════════════════════════════════════════════════════════════════ */
function filterAJ() {
  const q  = (document.getElementById('ajSearch')?.value || '').toLowerCase().trim();
  const st = document.getElementById('ajStatutFilter')?.value || '';
  const d  = window._ajData || {};
  let data = _ajTab === 'enfants' ? (d.enfants || []) : (d.encadreurs || []);

  if (q)  data = data.filter(x =>
    `${x.nom || ''} ${x.prenom || ''} ${x.nom_parent || ''} ${x.classe || ''}`
      .toLowerCase().includes(q)
  );
  if (st) data = data.filter(x => (x.statut || 'actif') === st);

  const zone = document.getElementById('ajContent');
  if (zone) {
    zone.innerHTML = _ajTab === 'enfants'
      ? _renderTableEnfants(data)
      : _renderTableEncadreurs(data);
  }
}

/* ══════════════════════════════════════════════════════════════════
   TABLEAU ENFANTS
══════════════════════════════════════════════════════════════════ */
function _renderTableEnfants(liste) {
  if (!liste.length) {
    return emptyState(
      'fa-child',
      'Aucun enfant enregistré',
      'Commencez par inscrire un enfant AJ de votre paroisse.',
      'Inscrire un enfant',
      'showEnfantAJForm()'
    );
  }

  return `
    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Nom &amp; Prénom</th>
            <th>Sexe</th>
            <th>Date de naissance</th>
            <th>Classe / Groupe</th>
            <th>Parent / Tuteur</th>
            <th>Tél. parent</th>
            <th>Date inscription</th>
            <th>Statut</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${liste.map((e, i) => `
            <tr>
              <td style="font-weight:700;color:var(--text-muted)">${i + 1}</td>
              <td>
                <div style="font-weight:700">${e.nom || ''} ${e.prenom || ''}</div>
                ${e.notes ? `<div style="font-size:11px;color:var(--text-muted);
                  font-style:italic">${e.notes}</div>` : ''}
              </td>
              <td>
                ${e.sexe === 'fille'
                  ? '<span style="color:#db2777">♀ Fille</span>'
                  : '<span style="color:#2563eb">♂ Garçon</span>'}
              </td>
              <td>${formatDate(e.date_naissance)}</td>
              <td>
                ${e.classe
                  ? `<span class="badge badge-primary">${e.classe}</span>`
                  : '<span style="color:var(--text-muted)">—</span>'}
              </td>
              <td style="font-weight:600">${e.nom_parent || '—'}</td>
              <td>
                ${e.telephone_parent
                  ? `<a href="tel:${e.telephone_parent}"
                      style="color:var(--primary)">${e.telephone_parent}</a>`
                  : '—'}
              </td>
              <td>${formatDateShort(e.date_inscription)}</td>
              <td>${statutBadge(e.statut || 'actif')}</td>
              <td>
                <div style="display:flex;gap:6px">
                  <button class="btn btn-sm btn-outline"
                    onclick="showEnfantAJForm('${e.id}','enfant')"
                    title="Modifier">
                    <i class="fas fa-pen"></i>
                  </button>
                  <button class="btn btn-sm btn-danger"
                    onclick="supprimerEnfantAJ('${e.id}',
                      '${(e.nom+' '+e.prenom).replace(/'/g,"\\'")}')"
                    title="Supprimer">
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

/* ══════════════════════════════════════════════════════════════════
   TABLEAU ENCADREURS
══════════════════════════════════════════════════════════════════ */
function _renderTableEncadreurs(liste) {
  if (!liste.length) {
    return emptyState(
      'fa-user-tie',
      'Aucun encadreur enregistré',
      'Ajoutez les encadreurs AJ de votre paroisse.',
      'Ajouter un encadreur',
      "showEnfantAJForm('','encadreur')"
    );
  }

  return `
    <div style="display:flex;justify-content:flex-end;margin-bottom:10px">
      <button class="btn btn-outline" onclick="imprimerEncadreursAJ()"
        title="Exporter la liste des encadreurs en PDF">
        <i class="fas fa-file-pdf" style="color:#E74C3C"></i> Imprimer PDF
      </button>
    </div>
    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Nom &amp; Prénom</th>
            <th>Sexe</th>
            <th>Grade</th>
            <th>Rôle d'encadrement</th>
            <th>Téléphone</th>
            <th>Email</th>
            <th>Date nomination</th>
            <th>Statut</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${liste.map((e, i) => `
            <tr>
              <td style="font-weight:700;color:var(--text-muted)">${i + 1}</td>
              <td>
                <div style="font-weight:700">${e.nom || ''} ${e.prenom || ''}</div>
              </td>
              <td>
                ${e.sexe === 'femme'
                  ? '<span style="color:#db2777">♀ Femme</span>'
                  : '<span style="color:#2563eb">♂ Homme</span>'}
              </td>
              <td>${e.grade ? gradeBadge(e.grade) : '—'}</td>
              <td>
                <span style="background:var(--gold-light);color:var(--gold);
                  padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600">
                  ${e.role_encadrement || '—'}
                </span>
              </td>
              <td>
                ${e.telephone
                  ? `<a href="tel:${e.telephone}"
                      style="color:var(--primary)">${e.telephone}</a>`
                  : '—'}
              </td>
              <td style="font-size:12px">
                ${e.email
                  ? `<a href="mailto:${e.email}"
                      style="color:var(--primary)">${e.email}</a>`
                  : '—'}
              </td>
              <td>${formatDateShort(e.date_nomination)}</td>
              <td>${statutBadge(e.statut || 'actif')}</td>
              <td>
                <div style="display:flex;gap:6px">
                  <button class="btn btn-sm btn-outline"
                    onclick="showEnfantAJForm('${e.id}','encadreur')"
                    title="Modifier">
                    <i class="fas fa-pen"></i>
                  </button>
                  <button class="btn btn-sm btn-danger"
                    onclick="supprimerEncadreurAJ('${e.id}',
                      '${(e.nom+' '+e.prenom).replace(/'/g,"\\'")}')"
                    title="Supprimer">
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

/* ══════════════════════════════════════════════════════════════════
   FORMULAIRE — ENFANT
══════════════════════════════════════════════════════════════════ */
async function showEnfantAJForm(id = null, type = null) {
  /* Déterminer le type selon l'onglet actif si non précisé */
  const formType = type || (_ajTab === 'encadreurs' ? 'encadreur' : 'enfant');

  if (formType === 'encadreur') {
    await _ouvrirFormEncadreur(id);
  } else {
    await _ouvrirFormEnfant(id);
  }
}

/* ── Formulaire Enfant ──────────────────────────────────────────── */
async function _ouvrirFormEnfant(id) {
  let ex = {};
  if (id) {
    try { ex = await API.getById('enfants_aj', id); }
    catch { ex = {}; }
  }

  const today = new Date().toISOString().slice(0, 10);

  openModal(
    id ? 'Modifier l\'enfant AJ' : 'Inscrire un enfant AJ',
    `<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

      <div class="form-group">
        <label>Nom <span style="color:var(--danger)">*</span></label>
        <input type="text" id="ajNom" class="form-control"
          value="${(ex.nom || '').replace(/"/g,'&quot;')}"
          placeholder="Nom de famille" />
      </div>

      <div class="form-group">
        <label>Prénom <span style="color:var(--danger)">*</span></label>
        <input type="text" id="ajPrenom" class="form-control"
          value="${(ex.prenom || '').replace(/"/g,'&quot;')}"
          placeholder="Prénom" />
      </div>

      <div class="form-group">
        <label>Sexe <span style="color:var(--danger)">*</span></label>
        <select id="ajSexe" class="form-control">
          <option value="garcon" ${(ex.sexe||'garcon')==='garcon'?'selected':''}>♂ Garçon</option>
          <option value="fille"  ${ex.sexe==='fille'?'selected':''}>♀ Fille</option>
        </select>
      </div>

      <div class="form-group">
        <label>Date de naissance</label>
        <input type="date" id="ajDob" class="form-control"
          value="${ex.date_naissance || ''}" />
      </div>

      <div class="form-group">
        <label>Classe / Groupe</label>
        <input type="text" id="ajClasse" class="form-control"
          value="${(ex.classe || '').replace(/"/g,'&quot;')}"
          placeholder="Ex : CP, CE1, 6ème, Groupe A…" />
      </div>

      <div class="form-group">
        <label>Nom du parent / Tuteur <span style="color:var(--danger)">*</span></label>
        <input type="text" id="ajParent" class="form-control"
          value="${(ex.nom_parent || '').replace(/"/g,'&quot;')}"
          placeholder="Nom complet" />
      </div>

      <div class="form-group">
        <label>Téléphone du parent</label>
        <input type="tel" id="ajTelParent" class="form-control"
          value="${(ex.telephone_parent || '').replace(/"/g,'&quot;')}"
          placeholder="+229 01 XX XX XX XX" />
      </div>

      <div class="form-group">
        <label>Date d'inscription</label>
        <input type="date" id="ajDateInscr" class="form-control"
          value="${ex.date_inscription || today}" />
      </div>

      <div class="form-group">
        <label>Statut</label>
        <select id="ajStatut" class="form-control">
          <option value="actif"   ${(ex.statut||'actif')==='actif'?'selected':''}>Actif</option>
          <option value="inactif" ${ex.statut==='inactif'?'selected':''}>Inactif</option>
        </select>
      </div>

      <div class="form-group" style="grid-column:1/-1">
        <label>Notes / Observations</label>
        <textarea id="ajNotes" class="form-control" rows="2"
          placeholder="Allergies, besoins particuliers…">${ex.notes || ''}</textarea>
      </div>

    </div>`,
    id ? 'Enregistrer' : 'Inscrire',
    async () => {
      const nom    = (document.getElementById('ajNom')?.value    || '').trim();
      const prenom = (document.getElementById('ajPrenom')?.value || '').trim();
      const parent = (document.getElementById('ajParent')?.value || '').trim();

      if (!nom || !prenom) {
        showToast('Nom et prénom requis', 'warning'); return;
      }
      if (!parent) {
        showToast('Le nom du parent / tuteur est requis', 'warning'); return;
      }

      const payload = {
        nom,
        prenom,
        sexe:             document.getElementById('ajSexe').value,
        date_naissance:   document.getElementById('ajDob').value        || '',
        classe:           (document.getElementById('ajClasse').value    || '').trim(),
        nom_parent:       parent,
        telephone_parent: (document.getElementById('ajTelParent').value || '').trim(),
        date_inscription: document.getElementById('ajDateInscr').value  || today,
        eglise_id:        _ajEgliseId,
        statut:           document.getElementById('ajStatut').value     || 'actif',
        notes:            (document.getElementById('ajNotes').value     || '').trim()
      };

      try {
        if (id) {
          await API.update('enfants_aj', id, payload);
          showToast('Enfant mis à jour avec succès', 'success');
        } else {
          payload.id = generateId('aj');
          await API.create('enfants_aj', payload);
          showToast('Enfant inscrit avec succès', 'success');
        }
        closeModal();
        renderEnfantsAJ();
      } catch (err) {
        showToast('Erreur : ' + err.message, 'error');
      }
    },
    'medium'
  );
}

/* ── Formulaire Encadreur ───────────────────────────────────────── */
async function _ouvrirFormEncadreur(id) {
  let ex = {};
  if (id) {
    try { ex = await API.getById('encadreurs_aj', id); }
    catch { ex = {}; }
  }

  const sexeInit  = ex.sexe || 'homme';
  const gradesHTML = (sexeInit === 'femme' ? GRADES_FEMME : GRADES_HOMME)
    .map(g => `<option value="${g}" ${ex.grade===g?'selected':''}>${g}</option>`)
    .join('');
  const today = new Date().toISOString().slice(0, 10);

  openModal(
    id ? "Modifier l'encadreur AJ" : 'Ajouter un encadreur AJ',
    `<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

      <div class="form-group">
        <label>Nom <span style="color:var(--danger)">*</span></label>
        <input type="text" id="encNom" class="form-control"
          value="${(ex.nom || '').replace(/"/g,'&quot;')}"
          placeholder="Nom de famille" />
      </div>

      <div class="form-group">
        <label>Prénom <span style="color:var(--danger)">*</span></label>
        <input type="text" id="encPrenom" class="form-control"
          value="${(ex.prenom || '').replace(/"/g,'&quot;')}"
          placeholder="Prénom" />
      </div>

      <div class="form-group">
        <label>Sexe</label>
        <select id="encSexe" class="form-control"
          onchange="_ajMajGradesEnc(this.value)">
          <option value="homme" ${sexeInit==='homme'?'selected':''}>♂ Homme</option>
          <option value="femme" ${sexeInit==='femme'?'selected':''}>♀ Femme</option>
        </select>
      </div>

      <div class="form-group">
        <label>Grade</label>
        <select id="encGrade" class="form-control">
          <option value="">— Choisir —</option>
          ${gradesHTML}
        </select>
      </div>

      <div class="form-group" style="grid-column:1/-1">
        <label>Rôle d'encadrement <span style="color:var(--danger)">*</span></label>
        <input type="text" id="encRole" class="form-control"
          value="${(ex.role_encadrement || '').replace(/"/g,'&quot;')}"
          placeholder="Ex : Responsable AJ, Animateur, Assistant responsable…" />
      </div>

      <div class="form-group">
        <label>Téléphone</label>
        <input type="tel" id="encTel" class="form-control"
          value="${(ex.telephone || '').replace(/"/g,'&quot;')}"
          placeholder="+229 01 XX XX XX XX" />
      </div>

      <div class="form-group">
        <label>Email</label>
        <input type="email" id="encEmail" class="form-control"
          value="${(ex.email || '').replace(/"/g,'&quot;')}"
          placeholder="email@exemple.com" />
      </div>

      <div class="form-group">
        <label>Date de nomination</label>
        <input type="date" id="encDateNom" class="form-control"
          value="${ex.date_nomination || today}" />
      </div>

      <div class="form-group">
        <label>Statut</label>
        <select id="encStatut" class="form-control">
          <option value="actif"   ${(ex.statut||'actif')==='actif'?'selected':''}>Actif</option>
          <option value="inactif" ${ex.statut==='inactif'?'selected':''}>Inactif</option>
        </select>
      </div>

      <div class="form-group" style="grid-column:1/-1">
        <label>Notes</label>
        <textarea id="encNotes" class="form-control" rows="2"
          placeholder="Informations complémentaires…">${ex.notes || ''}</textarea>
      </div>

    </div>`,
    id ? 'Enregistrer' : 'Ajouter',
    async () => {
      const nom  = (document.getElementById('encNom')?.value   || '').trim();
      const prenom=(document.getElementById('encPrenom')?.value || '').trim();
      const role = (document.getElementById('encRole')?.value  || '').trim();

      if (!nom || !prenom) {
        showToast('Nom et prénom requis', 'warning'); return;
      }
      if (!role) {
        showToast("Le rôle d'encadrement est requis", 'warning'); return;
      }

      const payload = {
        nom,
        prenom,
        sexe:             document.getElementById('encSexe').value     || 'homme',
        grade:            document.getElementById('encGrade').value    || '',
        role_encadrement: role,
        telephone:        (document.getElementById('encTel').value     || '').trim(),
        email:            (document.getElementById('encEmail').value   || '').trim(),
        eglise_id:        _ajEgliseId,
        date_nomination:  document.getElementById('encDateNom').value  || today,
        statut:           document.getElementById('encStatut').value   || 'actif',
        notes:            (document.getElementById('encNotes').value   || '').trim()
      };

      try {
        if (id) {
          await API.update('encadreurs_aj', id, payload);
          showToast('Encadreur mis à jour avec succès', 'success');
        } else {
          payload.id = generateId('enc');
          await API.create('encadreurs_aj', payload);
          showToast('Encadreur ajouté avec succès', 'success');
        }
        closeModal();
        _ajTab = 'encadreurs';
        renderEnfantsAJ();
      } catch (err) {
        showToast('Erreur : ' + err.message, 'error');
      }
    },
    'medium'
  );
}

/* Mise à jour dynamique des grades selon le sexe (encadreur) */
function _ajMajGradesEnc(sexe) {
  const sel = document.getElementById('encGrade');
  if (!sel) return;
  const grades = sexe === 'femme' ? GRADES_FEMME : GRADES_HOMME;
  sel.innerHTML = `<option value="">— Choisir —</option>` +
    grades.map(g => `<option value="${g}">${g}</option>`).join('');
}

/* ══════════════════════════════════════════════════════════════════
   SUPPRESSIONS
══════════════════════════════════════════════════════════════════ */
function supprimerEnfantAJ(id, nom) {
  confirmDelete(nom, async () => {
    try {
      await API.remove('enfants_aj', id);
      showToast('Enfant supprimé', 'success');
      closeModal();
      /* Mettre à jour la liste locale */
      if (window._ajData) {
        window._ajData.enfants = (window._ajData.enfants || []).filter(e => e.id !== id);
        _ajEnfants = window._ajData.enfants;
      }
      renderEnfantsAJ();
    } catch (err) {
      showToast('Erreur lors de la suppression : ' + err.message, 'error');
    }
  });
}

/* ══════════════════════════════════════════════════════════════════
   IMPRESSION PDF — ENCADREURS AJ
══════════════════════════════════════════════════════════════════ */
function imprimerEncadreursAJ() {
  const liste = _ajEncadreurs || [];
  if (!liste.length) {
    showToast('Aucun encadreur à imprimer', 'warning');
    return;
  }

  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

    /* En-tête document */
    doc.setFillColor(79, 70, 229);
    doc.rect(0, 0, 297, 28, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('✝  Liste des Encadreurs AJ — Ami de Jésus', 14, 11);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Paroisse : ${_ajEgliseId ? '' : '(toutes)'}`, 14, 20);
    doc.text(`Imprimé le : ${new Date().toLocaleDateString('fr-FR')}  · Total : ${liste.length} encadreur(s)`, 14, 26);

    /* Lignes du tableau */
    const rows = liste.map((e, i) => [
      i + 1,
      `${e.nom || ''} ${e.prenom || ''}`.trim(),
      e.sexe === 'femme' ? '♀ Femme' : '♂ Homme',
      e.grade || '—',
      e.role_encadrement || '—',
      e.telephone || '—',
      e.email || '—',
      e.date_nomination ? new Date(e.date_nomination).toLocaleDateString('fr-FR') : '—',
      e.statut || 'actif'
    ]);

    doc.autoTable({
      head: [['#', 'Nom & Prénom', 'Sexe', 'Grade', 'Rôle', 'Téléphone', 'Email', 'Date nomination', 'Statut']],
      body: rows,
      startY: 33,
      styles: { font: 'helvetica', fontSize: 8, cellPadding: 3, overflow: 'linebreak' },
      headStyles: { fillColor: [79, 70, 229], textColor: 255, fontStyle: 'bold', fontSize: 8 },
      alternateRowStyles: { fillColor: [238, 242, 255] },
      columnStyles: { 0: { halign: 'center', cellWidth: 8 } }
    });

    /* Pied de page */
    const pages = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pages; i++) {
      doc.setPage(i);
      doc.setFontSize(7);
      doc.setTextColor(150);
      doc.text(
        `Communauté Céleste — AJ Encadreurs · Page ${i} / ${pages}`,
        148, 205, { align: 'center' }
      );
    }

    const date = new Date().toISOString().slice(0, 10);
    doc.save(`encadreurs_AJ_${date}.pdf`);
    showToast('PDF généré avec succès', 'success');
  } catch (err) {
    showToast('Erreur PDF : ' + err.message, 'error');
  }
}

function supprimerEncadreurAJ(id, nom) {
  confirmDelete(nom, async () => {
    try {
      await API.remove('encadreurs_aj', id);
      showToast('Encadreur supprimé', 'success');
      closeModal();
      _ajTab = 'encadreurs';
      renderEnfantsAJ();
    } catch (err) {
      showToast('Erreur lors de la suppression : ' + err.message, 'error');
    }
  });
}
