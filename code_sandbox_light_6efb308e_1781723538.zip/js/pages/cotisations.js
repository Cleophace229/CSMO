/**
 * Cotisations Page
 */
App.registerAddHandler('cotisations', () => showCotisationForm());

const TYPES_COT = ['Mensuelle', 'Trimestrielle', 'Annuelle', 'Offrande', 'Don spécial'];

async function renderCotisations(params = {}) {
  setBreadcrumb([{ label: I18n.t('cotisations.title') }]);
  const content = document.getElementById('pageContent');

  try {
    const [cots, mems, egls] = await Promise.all([
      API.getAll('cotisations'),
      API.getAll('membres'),
      API.getAll('eglises')
    ]);

    let filtered = cots.data;
    if (params.eglise_id) filtered = cots.data.filter(c => c.eglise_id === params.eglise_id);
    if (params.membre_id) filtered = cots.data.filter(c => c.membre_id === params.membre_id);

    const totalPaye  = filtered.filter(c => c.statut === 'payé').reduce((s, c) => s + Number(c.montant || 0), 0);
    const totalRetard = filtered.filter(c => c.statut === 'en retard').reduce((s, c) => s + Number(c.montant || 0), 0);
    const nbRetard    = filtered.filter(c => c.statut === 'en retard').length;

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2><i class="fas fa-hand-holding-usd" style="color:var(--success);margin-right:10px"></i>${I18n.t('cotisations.title')}</h2>
          <p>${filtered.length} ${I18n.lang==='en'?'contribution(s)':'cotisation(s)'}</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-primary" onclick="showCotisationForm()"><i class="fas fa-plus"></i> ${I18n.t('cotisations.new')}</button>
        </div>
      </div>

      <div class="stats-grid" style="grid-template-columns:repeat(2,1fr);margin-bottom:20px">
        <div class="stat-card success"><div class="stat-icon"><i class="fas fa-check-circle"></i></div>
          <div class="stat-info"><h3>${formatAmount(totalPaye)}</h3><p>${I18n.lang==='en'?'Total received':'Total perçu'}</p></div></div>
        <div class="stat-card danger"><div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
          <div class="stat-info"><h3>${nbRetard} / ${formatAmount(totalRetard)}</h3><p>${I18n.t('cotisations.overdue')}</p></div></div>
      </div>

      <div class="page-search" style="flex-wrap:wrap;gap:8px">
        <div class="search-input-wrapper" style="flex:1">
          <i class="fas fa-search"></i>
          <input type="text" id="cotSearch" placeholder="Rechercher..." oninput="filterCotisations()" />
        </div>
        <select class="form-control" id="cotEglFilter" style="width:180px" onchange="filterCotisations()">
          <option value="">${I18n.t('membres.all_churches')}</option>
          ${egls.data.map(e => `<option value="${e.id}" ${params.eglise_id===e.id?'selected':''}>${e.nom}</option>`).join('')}
        </select>
        <select class="form-control" id="cotStatutFilter" style="width:140px" onchange="filterCotisations()">
          <option value="">${I18n.t('membres.all_statuts')}</option>
          <option value="payé">${I18n.t('cotisations.paid')}</option>
          <option value="en retard">${I18n.t('cotisations.overdue')}</option>
        </select>
        <select class="form-control" id="cotTypeFilter" style="width:140px" onchange="filterCotisations()">
          <option value="">Tous types</option>
          ${TYPES_COT.map(t => `<option value="${t}">${t}</option>`).join('')}
        </select>
      </div>

      <div class="table-wrapper" id="cotTable">
        ${renderCotisationsTable(filtered, mems.data, egls.data)}
      </div>

      <div id="cotStore" data-cots='${JSON.stringify(cots.data)}' data-mems='${JSON.stringify(mems.data)}' data-egls='${JSON.stringify(egls.data)}' style="display:none"></div>
    `;

    if (params.eglise_id) document.getElementById('cotEglFilter').value = params.eglise_id;

  } catch (err) {
    document.getElementById('pageContent').innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erreur</h3><p>${err.message}</p></div>`;
  }
}

function renderCotisationsTable(cots, mems, egls) {
  if (!cots || cots.length === 0) return emptyState('fa-hand-holding-usd', 'Aucune cotisation', 'Enregistrez votre première cotisation.', 'Ajouter', 'showCotisationForm()');
  return `<table>
    <thead><tr><th>Membre</th><th>Église</th><th>Montant</th><th>Type</th><th>Période</th><th>Date paiement</th><th>Statut</th><th>Actions</th></tr></thead>
    <tbody>${cots.map(c => {
      const m = mems.find(mb => mb.id === c.membre_id);
      const egl = egls.find(e => e.id === c.eglise_id);
      const mName = m ? `${m.prenom} ${m.nom}` : '—';
      return `<tr data-name="${mName.toLowerCase()}" data-egl="${c.eglise_id}" data-statut="${c.statut || ''}" data-type="${c.type_cotisation || ''}">
        <td style="font-weight:600">${mName}</td>
        <td style="font-size:12px">${egl ? egl.nom : '—'}</td>
        <td><span class="amount">${formatAmount(c.montant)}</span></td>
        <td><span class="badge badge-info">${c.type_cotisation || '—'}</span></td>
        <td>${c.periode || '—'}</td>
        <td>${formatDateShort(c.date_paiement)}</td>
        <td>${statutBadge(c.statut)}</td>
        <td><div class="td-actions">
          <button class="btn btn-xs btn-success" onclick="marquerPaye('${c.id}')"><i class="fas fa-check"></i></button>
          <button class="btn btn-xs btn-outline" onclick="showCotisationForm('${c.id}')"><i class="fas fa-edit"></i></button>
          <button class="btn btn-xs btn-danger" onclick="deleteCotisation('${c.id}')"><i class="fas fa-trash"></i></button>
        </div></td>
      </tr>`;
    }).join('')}</tbody>
  </table>`;
}

function filterCotisations() {
  const q = (document.getElementById('cotSearch')?.value || '').toLowerCase();
  const egl = document.getElementById('cotEglFilter')?.value || '';
  const statut = document.getElementById('cotStatutFilter')?.value || '';
  const type = document.getElementById('cotTypeFilter')?.value || '';
  document.querySelectorAll('#cotTable tbody tr').forEach(tr => {
    const mQ = !q || tr.dataset.name.includes(q);
    const mE = !egl || tr.dataset.egl === egl;
    const mS = !statut || tr.dataset.statut === statut;
    const mT = !type || tr.dataset.type === type;
    tr.style.display = (mQ && mE && mS && mT) ? '' : 'none';
  });
}

async function showCotisationForm(id = null) {
  const [mems, egls] = await Promise.all([API.getAll('membres'), API.getAll('eglises')]);
  let data = {};
  if (id) { try { data = await API.getById('cotisations', id); } catch {} }

  const html = `
    <div class="form-row">
      <div class="form-group"><label>Membre <span style="color:var(--danger)">*</span></label>
        <select class="form-control" id="fCotMem">
          <option value="">— Choisir —</option>
          ${mems.data.map(m => `<option value="${m.id}" ${data.membre_id===m.id?'selected':''}>${m.prenom} ${m.nom}</option>`).join('')}
        </select></div>
      <div class="form-group"><label>Église <span style="color:var(--danger)">*</span></label>
        <select class="form-control" id="fCotEgl">
          <option value="">— Choisir —</option>
          ${egls.data.map(e => `<option value="${e.id}" ${data.eglise_id===e.id?'selected':''}>${e.nom}</option>`).join('')}
        </select></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Montant (FC) <span style="color:var(--danger)">*</span></label>
        <input class="form-control" type="number" id="fCotMontant" value="${data.montant || ''}" min="0" /></div>
      <div class="form-group"><label>Type</label>
        <select class="form-control" id="fCotType">
          ${TYPES_COT.map(t => `<option value="${t}" ${data.type_cotisation===t?'selected':''}>${t}</option>`).join('')}
        </select></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Période</label>
        <input class="form-control" id="fCotPeriode" value="${data.periode || ''}" placeholder="Ex: 2026-T2" /></div>
      <div class="form-group"><label>Date de paiement</label>
        <input class="form-control" type="date" id="fCotDate" value="${data.date_paiement || ''}" /></div>
    </div>
    <div class="form-group"><label>Statut</label>
      <select class="form-control" id="fCotStatut">
        <option value="payé" ${(data.statut||'payé')==='payé'?'selected':''}>Payé</option>
        <option value="en retard" ${data.statut==='en retard'?'selected':''}>En retard</option>
      </select></div>
    <div class="form-group"><label>Notes</label>
      <input class="form-control" id="fCotNotes" value="${data.notes || ''}" /></div>
  `;

  openModal(id ? 'Modifier la cotisation' : 'Nouvelle cotisation', html, id ? 'Enregistrer' : 'Créer', async () => {
    const membre_id = document.getElementById('fCotMem').value;
    const eglise_id = document.getElementById('fCotEgl').value;
    const montant = document.getElementById('fCotMontant').value;
    if (!membre_id || !eglise_id || !montant) { showToast('Membre, église et montant requis', 'warning'); return; }
    const payload = {
      membre_id, eglise_id,
      montant: Number(montant),
      type_cotisation: document.getElementById('fCotType').value,
      periode: document.getElementById('fCotPeriode').value.trim(),
      date_paiement: document.getElementById('fCotDate').value,
      statut: document.getElementById('fCotStatut').value,
      notes: document.getElementById('fCotNotes').value.trim()
    };
    try {
      if (id) { await API.update('cotisations', id, payload); showToast('Cotisation mise à jour', 'success'); }
      else { await API.create('cotisations', { id: generateId('cot'), ...payload }); showToast('Cotisation enregistrée', 'success'); }
      closeModal(); renderCotisations();
    } catch (err) { showToast('Erreur: ' + err.message, 'error'); }
  });
}

async function marquerPaye(id) {
  try {
    const cot = await API.getById('cotisations', id);
    await API.update('cotisations', id, { ...cot, statut: 'payé', date_paiement: new Date().toISOString().split('T')[0] });
    showToast('Marqué comme payé', 'success');
    renderCotisations();
  } catch (err) { showToast('Erreur: ' + err.message, 'error'); }
}

async function deleteCotisation(id) {
  confirmDelete('cette cotisation', async () => {
    try { await API.remove('cotisations', id); showToast('Cotisation supprimée', 'success'); closeModal(); renderCotisations(); }
    catch (err) { showToast('Erreur: ' + err.message, 'error'); }
  });
}
