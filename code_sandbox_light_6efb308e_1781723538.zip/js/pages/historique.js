/**
 * Historique des mouvements de membres
 */
async function renderHistorique(params = {}) {
  setBreadcrumb([{ label: 'Historique des mouvements' }]);
  const content = document.getElementById('pageContent');

  try {
    const [hist, mems, egls] = await Promise.all([
      API.getAll('historique'),
      API.getAll('membres'),
      API.getAll('eglises')
    ]);

    // Sort descending by date
    const sorted = [...hist.data].sort((a, b) => {
      const da = new Date(a.date_action || a.created_at || 0);
      const db = new Date(b.date_action || b.created_at || 0);
      return db - da;
    });

    const ACTION_ICONS = {
      'Adhésion': { icon: 'fa-user-plus', color: 'var(--success)' },
      'Transfert': { icon: 'fa-exchange-alt', color: 'var(--info)' },
      'Promotion de grade': { icon: 'fa-arrow-up', color: 'var(--gold)' },
      'Changement de rôle': { icon: 'fa-user-tag', color: 'var(--primary)' },
      'Suspension': { icon: 'fa-ban', color: 'var(--danger)' },
      'Réactivation': { icon: 'fa-redo', color: 'var(--success)' },
      'Départ': { icon: 'fa-user-minus', color: 'var(--warning)' }
    };

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2><i class="fas fa-history" style="color:var(--info);margin-right:10px"></i>Historique des mouvements</h2>
          <p>${hist.total} entrée(s) enregistrée(s)</p>
        </div>
      </div>

      <div class="page-search" style="flex-wrap:wrap;gap:8px">
        <div class="search-input-wrapper" style="flex:1">
          <i class="fas fa-search"></i>
          <input type="text" id="histSearch" placeholder="Rechercher un membre..." oninput="filterHistorique()" />
        </div>
        <select class="form-control" id="histEglFilter" style="width:180px" onchange="filterHistorique()">
          <option value="">Toutes les églises</option>
          ${egls.data.map(e => `<option value="${e.id}">${e.nom}</option>`).join('')}
        </select>
        <select class="form-control" id="histTypeFilter" style="width:180px" onchange="filterHistorique()">
          <option value="">Toutes les actions</option>
          ${['Adhésion', 'Transfert', 'Promotion de grade', 'Changement de rôle', 'Suspension', 'Réactivation', 'Départ'].map(t => `<option value="${t}">${t}</option>`).join('')}
        </select>
      </div>

      <div class="table-wrapper" id="histTable">
        ${renderHistTable(sorted, mems.data, egls.data, ACTION_ICONS)}
      </div>

      <div id="histStore" data-hist='${JSON.stringify(hist.data)}' data-mems='${JSON.stringify(mems.data)}' data-egls='${JSON.stringify(egls.data)}' style="display:none"></div>
    `;

  } catch (err) {
    document.getElementById('pageContent').innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erreur</h3><p>${err.message}</p></div>`;
  }
}

function renderHistTable(hist, mems, egls, icons) {
  if (!hist || hist.length === 0) return emptyState('fa-history', 'Aucun historique', 'Les mouvements des membres apparaîtront ici automatiquement.');

  const ACTION_ICONS = icons || {
    'Adhésion': { icon: 'fa-user-plus', color: 'var(--success)' },
    'Transfert': { icon: 'fa-exchange-alt', color: 'var(--info)' },
    'Promotion de grade': { icon: 'fa-arrow-up', color: 'var(--gold)' },
    'Changement de rôle': { icon: 'fa-user-tag', color: 'var(--primary)' },
    'Suspension': { icon: 'fa-ban', color: 'var(--danger)' },
    'Réactivation': { icon: 'fa-redo', color: 'var(--success)' },
    'Départ': { icon: 'fa-user-minus', color: 'var(--warning)' }
  };

  return `<table>
    <thead><tr>
      <th>Action</th><th>Membre</th><th>Ancienne valeur</th><th>Nouvelle valeur</th><th>Église</th><th>Date</th><th>Notes</th>
    </tr></thead>
    <tbody>${hist.map(h => {
      const m = mems.find(mb => mb.id === h.membre_id);
      const egl = egls.find(e => e.id === h.eglise_id);
      const ac = ACTION_ICONS[h.type_action] || { icon: 'fa-circle', color: 'var(--text-muted)' };
      const mName = m ? `${m.prenom} ${m.nom}` : '—';
      return `<tr data-name="${mName.toLowerCase()}" data-egl="${h.eglise_id || ''}" data-type="${h.type_action || ''}">
        <td>
          <div style="display:flex;align-items:center;gap:8px">
            <div style="width:32px;height:32px;border-radius:50%;background:${ac.color}22;display:flex;align-items:center;justify-content:center">
              <i class="fas ${ac.icon}" style="color:${ac.color};font-size:13px"></i>
            </div>
            <span style="font-weight:600;font-size:12px">${h.type_action || '—'}</span>
          </div>
        </td>
        <td><span style="font-weight:600">${mName}</span></td>
        <td>${h.ancienne_valeur ? `<span style="font-size:12px;color:var(--danger)">${h.ancienne_valeur}</span>` : '—'}</td>
        <td>${h.nouvelle_valeur ? `<span style="font-size:12px;color:var(--success)">${h.nouvelle_valeur}</span>` : '—'}</td>
        <td style="font-size:12px">${egl ? egl.nom : '—'}</td>
        <td style="font-size:12px">${formatDateShort(h.date_action)}</td>
        <td style="font-size:12px;color:var(--text-muted)">${h.notes || '—'}</td>
      </tr>`;
    }).join('')}</tbody>
  </table>`;
}

function filterHistorique() {
  const q = (document.getElementById('histSearch')?.value || '').toLowerCase();
  const egl = document.getElementById('histEglFilter')?.value || '';
  const type = document.getElementById('histTypeFilter')?.value || '';
  document.querySelectorAll('#histTable tbody tr').forEach(tr => {
    const mQ = !q || tr.dataset.name.includes(q);
    const mE = !egl || tr.dataset.egl === egl;
    const mT = !type || tr.dataset.type === type;
    tr.style.display = (mQ && mE && mT) ? '' : 'none';
  });
}
