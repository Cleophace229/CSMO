/**
 * Utility functions — Recensement Paroissial
 */

// ============================
// TOAST NOTIFICATIONS
// ============================
function showToast(message, type = 'info', duration = 3500) {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0'; toast.style.transform = 'translateX(100px)'; toast.style.transition = '0.3s';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// ============================
// MODAL
// ============================
let modalConfirmCallback = null;

function openModal(title, bodyHTML, confirmText = 'Sauvegarder', onConfirm = null, size = '') {
  const titleEl   = document.getElementById('modalTitle');
  const bodyEl    = document.getElementById('modalBody');
  const overlayEl = document.getElementById('modalOverlay');
  const confirmBtn = document.getElementById('modalConfirmBtn');
  const modal      = document.getElementById('modalBox');
  if (!titleEl || !bodyEl || !overlayEl) return;
  titleEl.textContent = title;
  bodyEl.innerHTML    = bodyHTML;
  overlayEl.classList.add('active');
  if (modal) modal.className = `modal ${size}`;
  if (confirmBtn) {
    confirmBtn.textContent = confirmText;
    modalConfirmCallback   = onConfirm;
    if (onConfirm === null) {
      confirmBtn.style.display = 'none';
    } else {
      confirmBtn.style.display = '';
      confirmBtn.onclick = () => { if (modalConfirmCallback) modalConfirmCallback(); };
    }
  }
}

function closeModal() {
  const overlayEl = document.getElementById('modalOverlay');
  if (overlayEl) overlayEl.classList.remove('active');
  modalConfirmCallback = null;
}

document.addEventListener('DOMContentLoaded', () => {
  const overlay = document.getElementById('modalOverlay');
  if (overlay) {
    overlay.addEventListener('click', function(e) {
      if (e.target === this) closeModal();
    });
  }
});

// ============================
// BREADCRUMB
// ============================
function setBreadcrumb(items) {
  const bc = document.getElementById('breadcrumb');
  if (!bc) return;
  bc.innerHTML = items.map((item, i) => {
    if (i === items.length - 1) return `<span>${item.label}</span>`;
    return `<a href="#" onclick="${item.onclick || 'return false'}" style="color:var(--text-muted)">${item.label}</a><span class="sep"> / </span>`;
  }).join('');
}

// ============================
// FORMAT DATE
// ============================
function formatDate(dateStr) {
  if (!dateStr) return '—';
  try {
    return new Date(dateStr).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });
  } catch { return dateStr; }
}

function formatDateShort(dateStr) {
  if (!dateStr) return '—';
  try {
    return new Date(dateStr).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  } catch { return dateStr; }
}

// ============================
// GENERATE ID
// ============================
function generateId(prefix = 'id') {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

// ============================
// GRADES PAR SEXE
// ============================

/**
 * ══════════════════════════════════════════════════════════════
 * GRADES HARMONISÉS — CSMO (Conseil Supérieur de Mise en Œuvre)
 * Instauré le 04 juin 2026 à Cotonou (Sofitel)
 * Sources : Tableaux 4.1 à 4.5 du Règlement Intérieur de l'ECC
 * ══════════════════════════════════════════════════════════════
 */

/** Corps des LEADERS — 18 onctions (tableau 4.1) */
const GRADES_LEADER = [
  'Dèhoto',                                 // 1
  'Assistant Leader',                       // 2
  'Leader',                                 // 3
  'Senior Leader',                          // 4
  'Vénérable Senior Leader',                // 5
  'Assistant Évangéliste',                  // 6
  'Évangéliste',                            // 7
  'Senior Évangéliste',                     // 8
  'Most Senior Évangéliste',                // 9
  'Vénérable Most Senior Évangéliste',      // 10
  'Assistant Supérieur Évangéliste',        // 11
  'Supérieur Évangéliste',                  // 12
  'Assistant Vénérable Supérieur Évangéliste', // 13
  'Vénérable Supérieur Évangéliste',        // 14
  'Assistant Most Supérieur Évangéliste',   // 15
  'Most Supérieur Évangéliste',             // 16
  'Assistant Révérend Évangéliste',         // 17
  'Révérend Évangéliste'                    // 18
];

/** Corps des VISIONNAIRES HOMMES — 5 onctions actives (tableau 4.2)
 *  Grades 6–14 supprimés par harmonisation → basculent dans Leaders */
const GRADES_WOLI_HOMME = [
  'Dèhoto Woly',                            // 1
  'Assistant Woly',                         // 2
  'Wolyjah / Wolyleader',                   // 3
  'Senior Wolyjah / Wolyleader',            // 4
  'Vénérable Sénior Wolijah / Wolyleader'   // 5
];

/** Corps des VISIONNAIRES FEMMES — 6 onctions actives (tableau 4.3)
 *  Grades 7–8 supprimés → basculent Vénérable Sénior Maman Woly */
const GRADES_WOLI_FEMME = [
  'Dèhoto Woly',                            // 1
  'Assistante Maman Woly',                  // 2
  'Maman Woly',                             // 3
  'Sénior Maman Woly',                      // 4
  'Vénérable Maman Woly',                   // 5
  'Vénérable Sénior Maman Woly'             // 6
];

/** Corps des ALLAGBA — 5 onctions (tableau 4.4) */
const GRADES_ALLAGBA = [
  'Dèhoto',                                 // 1
  'Assistant Allagba',                      // 2
  'Allagba',                                // 3
  'Senior Allagba',                         // 4
  'Vénérable Sénior Allagba'                // 5
];

/** Corps des MAMANS — 9 onctions (tableau 4.5) */
const GRADES_MAMAN = [
  'Sœur',                                   // 1
  'Dèhoto',                                 // 2
  'Assistante Maman',                       // 3
  'Maman',                                  // 4
  'Senior Maman',                           // 5
  'Vénérable Maman',                        // 6
  'Vénérable Senior Maman',                 // 7
  'Assistante Mère Céleste',                // 8
  'Mère Céleste'                            // 9
];

/** HOMME — tous grades combinés (compatibilité ascendante) */
const GRADES_HOMME = [
  'Fidèle simple',
  // Leaders (18 onctions CSMO)
  ...GRADES_LEADER,
  // Woli Homme (5 onctions CSMO)
  ...GRADES_WOLI_HOMME,
  // Allagba (5 onctions CSMO)
  ...GRADES_ALLAGBA.slice(1) // Dèhoto déjà inclus
];

/** FEMME — tous grades combinés (compatibilité ascendante) */
const GRADES_FEMME = [
  'Fidèle simple',
  // Mamans (9 onctions CSMO)
  ...GRADES_MAMAN,
  // Woli Femme (6 onctions CSMO)
  ...GRADES_WOLI_FEMME
];

/** Couleurs des badges — CSMO harmonisé */
const _GRADE_COLORS = {
  'Fidèle simple':                              'badge-secondary',
  // ── Leaders (tableau 4.1) ──
  'Dèhoto':                                     'badge-info',
  'Assistant Leader':                           'badge-success',
  'Leader':                                     'badge-success',
  'Senior Leader':                              'badge-success',
  'Vénérable Senior Leader':                    'badge-success',
  'Assistant Évangéliste':                      'badge-gold',
  'Évangéliste':                                'badge-gold',
  'Senior Évangéliste':                         'badge-gold',
  'Most Senior Évangéliste':                    'badge-gold',
  'Vénérable Most Senior Évangéliste':          'badge-gold',
  'Assistant Supérieur Évangéliste':            'badge-gold',
  'Supérieur Évangéliste':                      'badge-gold',
  'Assistant Vénérable Supérieur Évangéliste':  'badge-gold',
  'Vénérable Supérieur Évangéliste':            'badge-gold',
  'Assistant Most Supérieur Évangéliste':       'badge-danger',
  'Most Supérieur Évangéliste':                 'badge-danger',
  'Assistant Révérend Évangéliste':             'badge-danger',
  'Révérend Évangéliste':                       'badge-danger',
  // ── Woli Hommes (tableau 4.2) ──
  'Dèhoto Woly':                                'badge-warning',
  'Assistant Woly':                             'badge-warning',
  'Wolyjah / Wolyleader':                       'badge-warning',
  'Senior Wolyjah / Wolyleader':                'badge-warning',
  'Vénérable Sénior Wolijah / Wolyleader':      'badge-warning',
  // ── Woli Femmes (tableau 4.3) ──
  'Assistante Maman Woly':                      'badge-warning',
  'Maman Woly':                                 'badge-warning',
  'Sénior Maman Woly':                          'badge-warning',
  'Vénérable Maman Woly':                       'badge-warning',
  'Vénérable Sénior Maman Woly':                'badge-warning',
  // ── Allagba (tableau 4.4) ──
  'Assistant Allagba':                          'badge-info',
  'Allagba':                                    'badge-primary',
  'Senior Allagba':                             'badge-primary',
  'Vénérable Sénior Allagba':                   'badge-primary',
  // ── Mamans (tableau 4.5) ──
  'Sœur':                                       'badge-secondary',
  'Assistante Maman':                           'badge-info',
  'Maman':                                      'badge-primary',
  'Senior Maman':                               'badge-primary',
  'Vénérable Maman':                            'badge-warning',
  'Vénérable Senior Maman':                     'badge-warning',
  'Assistante Mère Céleste':                    'badge-gold',
  'Mère Céleste':                               'badge-danger',
  // ── Rétrocompatibilité (anciens grades) ──
  'Dehoto':                                     'badge-info',
  'Assistant Maman':                            'badge-info',
  'Supérieur Maman':                            'badge-gold',
  'Vénérable Supérieur Maman':                  'badge-danger',
  'Assistant Wolijah':                          'badge-warning',
  'Wolijah':                                    'badge-warning',
  'Senior Wolijah':                             'badge-warning',
  'Senior Wolileader':                          'badge-warning',
  'Vénérable Senior Wolijah':                   'badge-warning',
  'Vénérable Senior Wolileader':                'badge-warning',
  'Pasteur de Fonction':                        'badge-danger',
  'Révérend Pasteur':                           'badge-danger'
};

// ============================
// GRADE BADGE
// ============================
function gradeBadge(grade) {
  return `<span class="badge ${_GRADE_COLORS[grade] || 'badge-secondary'}">${grade || '—'}</span>`;
}

// ============================
// ROLE BADGE
// ============================
function roleBadge(role) {
  const colors = {
    'Chargé paroissial':  'badge-gold',
    'Secrétaire':         'badge-info',
    'Secrétaire adjoint': 'badge-info',
    'Maître de choeurs':  'badge-primary',
    'Adjoint choeurs':    'badge-primary',
    'Choriste':           'badge-info',
    'Fidèle':             'badge-secondary'
  };
  return `<span class="badge ${colors[role] || 'badge-secondary'}">${role || '—'}</span>`;
}

// ============================
// STATUT BADGE
// ============================
function statutBadge(statut) {
  const map = {
    'actif':     '<span class="badge badge-success"><i class="fas fa-circle" style="font-size:8px"></i> Actif</span>',
    'inactif':   '<span class="badge badge-secondary"><i class="fas fa-circle" style="font-size:8px"></i> Inactif</span>',
    'suspendu':  '<span class="badge badge-warning"><i class="fas fa-circle" style="font-size:8px"></i> Suspendu</span>',
    'payé':      '<span class="badge badge-success"><i class="fas fa-check"></i> Payé</span>',
    'en retard': '<span class="badge badge-danger"><i class="fas fa-exclamation"></i> En retard</span>'
  };
  return map[statut] || `<span class="badge badge-secondary">${statut || '—'}</span>`;
}

// ============================
// AVATAR MEMBRE
// ============================
function memberAvatar(membre, size = 40) {
  const initials = `${(membre.prenom || '?')[0]}${(membre.nom || '?')[0]}`.toUpperCase();
  if (membre.photo_url) {
    return `<div class="member-avatar" style="width:${size}px;height:${size}px;border-radius:50%;overflow:hidden;flex-shrink:0"><img src="${membre.photo_url}" alt="${initials}" style="width:100%;height:100%;object-fit:cover" onerror="this.parentElement.innerHTML='<span style=\\'display:flex;align-items:center;justify-content:center;width:100%;height:100%\\'>${initials}</span>'"></div>`;
  }
  const palette = ['#6C3483','#1A5276','#117A65','#D68910','#C0392B','#2471A3'];
  const color = palette[(membre.nom || '').charCodeAt(0) % palette.length];
  return `<div class="member-avatar" style="width:${size}px;height:${size}px;background:${color};color:#fff;font-size:${Math.floor(size/2.8)}px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0">${initials}</div>`;
}

// ============================
// EMPTY STATE
// ============================
function emptyState(icon, title, subtitle, btnLabel = null, btnClick = null) {
  return `<div class="empty-state">
    <i class="fas ${icon}"></i>
    <h3>${title}</h3>
    <p>${subtitle}</p>
    ${btnLabel ? `<button class="btn btn-primary" onclick="${btnClick}">${btnLabel}</button>` : ''}
  </div>`;
}

// ============================
// CONFIRM DELETE
// ============================
function confirmDelete(name, onConfirm) {
  openModal(
    'Confirmer la suppression',
    `<div style="text-align:center;padding:10px 0">
      <i class="fas fa-exclamation-triangle" style="font-size:48px;color:var(--danger);margin-bottom:16px"></i>
      <p style="font-size:15px;color:var(--text)">Êtes-vous sûr de vouloir supprimer <strong>${name}</strong> ?</p>
      <p style="font-size:13px;color:var(--text-muted);margin-top:6px">Cette action est irréversible.</p>
    </div>`,
    'Supprimer', onConfirm, 'small'
  );
  const btn = document.getElementById('modalConfirmBtn');
  if (btn) btn.className = 'btn btn-danger';
}

// ============================
// FORMAT MONTANT
// ============================
function formatAmount(n) {
  if (n === null || n === undefined) return '—';
  return Number(n).toLocaleString('fr-FR') + ' FC';
}

// ============================
// DEBOUNCE
// ============================
function debounce(fn, delay = 300) {
  let timer;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
}

// ============================
// PAGINATION
// ============================
function renderPagination(container, currentPage, totalPages, onPageChange) {
  if (!container || totalPages <= 1) { if (container) container.innerHTML = ''; return; }
  let html = '<div style="display:flex;gap:6px;align-items:center;justify-content:center;margin-top:20px">';
  html += `<button class="btn btn-sm btn-secondary" onclick="${onPageChange}(${currentPage-1})" ${currentPage<=1?'disabled':''}><i class="fas fa-chevron-left"></i></button>`;
  const start = Math.max(1, currentPage - 2);
  const end   = Math.min(totalPages, currentPage + 2);
  if (start > 1) html += `<button class="btn btn-sm btn-secondary" onclick="${onPageChange}(1)">1</button><span style="padding:0 4px">…</span>`;
  for (let p = start; p <= end; p++) {
    html += `<button class="btn btn-sm ${p===currentPage?'btn-primary':'btn-secondary'}" onclick="${onPageChange}(${p})">${p}</button>`;
  }
  if (end < totalPages) html += `<span style="padding:0 4px">…</span><button class="btn btn-sm btn-secondary" onclick="${onPageChange}(${totalPages})">${totalPages}</button>`;
  html += `<button class="btn btn-sm btn-secondary" onclick="${onPageChange}(${currentPage+1})" ${currentPage>=totalPages?'disabled':''}><i class="fas fa-chevron-right"></i></button>`;
  html += '</div>';
  container.innerHTML = html;
}

// ============================
// GENERATEUR IDENTIFIANTS EGLISE
// ============================
function generateEgliseCredentials(nomEglise) {
  const prefix = (nomEglise || 'EGL')
    .toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .replace(/[^A-Z]/g, '').slice(0, 3).padEnd(3, 'X');
  const suffix = Math.random().toString(36).slice(2, 5).toUpperCase();
  const identifiant = `${prefix}${suffix}`;
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789@#';
  let mot_de_passe = '';
  for (let i = 0; i < 8; i++) mot_de_passe += chars[Math.floor(Math.random() * chars.length)];
  return { identifiant, mot_de_passe };
}
