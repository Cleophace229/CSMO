/**
 * comites_nationaux.js — Comités Supérieurs : CSM, CDSS, CSMO
 * - CSM  : Comité Supérieur des Membres
 * - CDSS : Comité de Discipline et de Soutien Spirituel
 * - CSMO : Conseil Supérieur de Mise en Œuvre (installé le 04/06/2026 à Cotonou, Sofitel)
 * Rôles : saisie libre (non contrainte) — grade selon sexe
 * Table : membres_comite_nat
 */

App.registerAddHandler('comites_nationaux', () => showComiteNatForm());

/* ══════════════════════════════════════════════════════════════════
   CONFIG DES COMITÉS
══════════════════════════════════════════════════════════════════ */
const COMITES_CONFIG = {
  CSM: {
    label: 'CSM — Comité Supérieur des Membres',
    icon:  'fa-crown',
    color: 'linear-gradient(135deg,#7c3aed,#4f46e5)',
    desc:  'Organe suprême de représentation des membres de la communauté céleste.'
  },
  CDSS: {
    label: 'CDSS — Comité de Discipline et de Soutien Spirituel',
    icon:  'fa-balance-scale',
    color: 'linear-gradient(135deg,#059669,#0891b2)',
    desc:  'Veille à la discipline spirituelle et au soutien fraternel au sein des paroisses.'
  },
  CSMO: {
    label: 'CSMO — Conseil Supérieur de Mise en Œuvre',
    icon:  'fa-exchange-alt',
    color: 'linear-gradient(135deg,#d97706,#ef4444)',
    desc:  'Assure la gestion transitoire et la continuité institutionnelle.'
  }
};

let _comiteNatActif = 'CSM'; // onglet actif par défaut

/* ══════════════════════════════════════════════════════════════════
   RENDU PRINCIPAL
══════════════════════════════════════════════════════════════════ */
async function renderComitesNationaux(params = {}) {
  setBreadcrumb([{ label: 'Comités Supérieurs (CSM · CDSS · CSMO)' }]);
  const content = document.getElementById('pageContent');
  content.innerHTML = `<div class="loading-spinner">
    <i class="fas fa-circle-notch fa-spin"></i><p>Chargement...</p></div>`;

  try {
    const [membresRes, eglRes] = await Promise.all([
      API.getAll('membres_comite_nat', { limit: 500 }),
      API.getAll('eglises').catch(() => ({ data: [] }))
    ]);

    const tous  = membresRes.data || [];
    const egls  = eglRes.data    || [];

    if (params.type && COMITES_CONFIG[params.type]) _comiteNatActif = params.type;

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-crown" style="margin-right:10px"></i>Comités Supérieurs
          </h2>
          <p>CSM · CDSS · CSMO — Gestion des membres et rôles</p>
        </div>
        <div class="page-header-actions">
          ${Auth.canWrite()
            ? `<button class="btn btn-primary" onclick="showComiteNatForm()">
                 <i class="fas fa-user-plus"></i> Nouveau membre
               </button>` : ''}
        </div>
      </div>

      <!-- Onglets Comités -->
      <div style="display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap">
        ${Object.entries(COMITES_CONFIG).map(([key, cfg]) => {
          const count = tous.filter(m => m.type_comite === key).length;
          const isActive = _comiteNatActif === key;
          return `
          <button onclick="switchComiteNat('${key}')"
            style="flex:1;min-width:200px;padding:18px 20px;border:2px solid ${isActive ? 'transparent' : 'var(--border)'};
              border-radius:14px;cursor:pointer;text-align:left;
              background:${isActive ? cfg.color : 'var(--bg-card)'};
              color:${isActive ? '#fff' : 'var(--text)'};
              box-shadow:${isActive ? '0 4px 20px rgba(0,0,0,0.18)' : 'none'};
              transition:all .2s;font-family:inherit">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
              <i class="fas ${cfg.icon}" style="font-size:18px;${isActive ? '' : 'color:var(--primary)'}"></i>
              <span style="font-weight:700;font-size:13px">${key}</span>
              <span style="font-size:11px;padding:2px 8px;border-radius:20px;margin-left:auto;
                background:${isActive ? 'rgba(255,255,255,0.25)' : 'var(--accent)'};
                color:${isActive ? '#fff' : 'var(--primary)'}">
                ${count} membre${count > 1 ? 's' : ''}
              </span>
            </div>
            <div style="font-size:11px;${isActive ? 'opacity:.85' : 'color:var(--text-muted)'}">
              ${cfg.label.split('—')[1]?.trim() || cfg.label}
            </div>
          </button>`;
        }).join('')}
      </div>

      <!-- Bannière description -->
      <div id="comiteNatDesc"
        style="padding:14px 18px;border-radius:12px;margin-bottom:20px;
          background:${COMITES_CONFIG[_comiteNatActif].color};color:#fff;
          display:flex;align-items:center;gap:14px">
        <i class="fas ${COMITES_CONFIG[_comiteNatActif].icon}" style="font-size:24px;flex-shrink:0"></i>
        <div>
          <div style="font-weight:700;font-size:15px">${COMITES_CONFIG[_comiteNatActif].label}</div>
          <div style="font-size:12px;opacity:.9;margin-top:3px">${COMITES_CONFIG[_comiteNatActif].desc}</div>
        </div>
      </div>

      <!-- Recherche -->
      <div class="page-search" style="margin-bottom:16px">
        <div class="search-input-wrapper" style="flex:1">
          <i class="fas fa-search"></i>
          <input type="text" id="cnatSearch" placeholder="Rechercher un membre..."
            oninput="filterComiteNat()" />
        </div>
        <select class="form-control" id="cnatStatutFilter" style="width:140px"
          onchange="filterComiteNat()">
          <option value="">Tous statuts</option>
          <option value="actif">Actifs</option>
          <option value="inactif">Inactifs</option>
        </select>
      </div>

      <!-- Tableau membres -->
      <div id="comiteNatTable" class="table-wrapper">
        ${_renderComiteNatTable(tous.filter(m => m.type_comite === _comiteNatActif), egls)}
      </div>
    `;

    /* Stocker pour filtrage */
    window._cnatData = { tous, egls };

  } catch (err) {
    content.innerHTML = `<div class="empty-state">
      <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
      <h3>Erreur de chargement</h3><p>${err.message}</p>
      <button class="btn btn-primary" onclick="renderComitesNationaux()">
        <i class="fas fa-redo"></i> Réessayer
      </button></div>`;
  }
}

/* ── Tableau HTML ────────────────────────────────────────────── */
function _renderComiteNatTable(membres, egls) {
  if (membres.length === 0) {
    return emptyState('fa-crown',
      'Aucun membre enregistré',
      'Commencez par ajouter des membres pour ce comité.',
      Auth.canWrite() ? 'Ajouter un membre' : null,
      'showComiteNatForm()');
  }

  return `
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Nom & Prénom</th>
          <th>Sexe</th>
          <th>Grade</th>
          <th>Rôle dans le comité</th>
          <th>Église</th>
          <th>Téléphone</th>
          <th>Date nomination</th>
          <th>Statut</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="cnatTbody">
        ${membres.map((m, i) => {
          const egl = egls.find(e => e.id === m.eglise_id);
          return `
          <tr class="cnat-row"
            data-nom="${(m.nom + ' ' + m.prenom).toLowerCase()}"
            data-statut="${m.statut || 'actif'}">
            <td style="font-weight:600;color:var(--text-muted)">${i + 1}</td>
            <td>
              <div style="display:flex;align-items:center;gap:10px">
                ${memberAvatar({ nom: m.nom, prenom: m.prenom }, 32)}
                <div>
                  <div style="font-weight:700;font-size:13px">${m.prenom || ''} ${m.nom || ''}</div>
                  ${m.email ? `<div style="font-size:11px;color:var(--text-muted)">${m.email}</div>` : ''}
                </div>
              </div>
            </td>
            <td>${m.sexe === 'femme' ? '<span style="color:#db2777">♀ Femme</span>' : '<span style="color:#2563eb">♂ Homme</span>'}</td>
            <td>${m.grade ? gradeBadge(m.grade) : '—'}</td>
            <td>
              <span style="background:var(--accent);color:var(--primary);
                padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600">
                ${m.role || '—'}
              </span>
            </td>
            <td style="font-size:12px">${egl ? egl.nom : '—'}</td>
            <td style="font-size:12px">${m.telephone || '—'}</td>
            <td style="font-size:12px">${m.date_nomination ? formatDateShort(m.date_nomination) : '—'}</td>
            <td>${statutBadge(m.statut || 'actif')}</td>
            <td>
              <div style="display:flex;gap:4px">
                ${Auth.canWrite()
                  ? `<button class="btn btn-sm btn-outline" title="Modifier"
                       onclick="showComiteNatForm('${m.id}')">
                       <i class="fas fa-edit"></i>
                     </button>` : ''}
                ${Auth.canDelete()
                  ? `<button class="btn btn-sm btn-danger" title="Supprimer"
                       onclick="deleteComiteNatMembre('${m.id}','${(m.prenom + ' ' + m.nom).replace(/'/g,"\\'")}')">
                       <i class="fas fa-trash"></i>
                     </button>` : ''}
              </div>
            </td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>`;
}

/* ── Changer d'onglet comité ─────────────────────────────────── */
function switchComiteNat(type) {
  _comiteNatActif = type;
  const d = window._cnatData || {};
  const membres = (d.tous || []).filter(m => m.type_comite === type);
  const egls    = d.egls || [];
  const cfg     = COMITES_CONFIG[type];

  /* Mettre à jour les boutons onglets */
  document.querySelectorAll('[onclick^="switchComiteNat"]').forEach(btn => {
    const t = btn.getAttribute('onclick').match(/'(\w+)'/)?.[1];
    if (!t) return;
    const c = COMITES_CONFIG[t];
    const isA = t === type;
    btn.style.background = isA ? c.color : 'var(--bg-card)';
    btn.style.color      = isA ? '#fff' : 'var(--text)';
    btn.style.borderColor = isA ? 'transparent' : 'var(--border)';
    btn.style.boxShadow  = isA ? '0 4px 20px rgba(0,0,0,0.18)' : 'none';
  });

  /* Mettre à jour la description */
  const desc = document.getElementById('comiteNatDesc');
  if (desc) {
    desc.style.background = cfg.color;
    desc.innerHTML = `
      <i class="fas ${cfg.icon}" style="font-size:24px;flex-shrink:0"></i>
      <div>
        <div style="font-weight:700;font-size:15px">${cfg.label}</div>
        <div style="font-size:12px;opacity:.9;margin-top:3px">${cfg.desc}</div>
      </div>`;
  }

  /* Mettre à jour le tableau */
  const tbl = document.getElementById('comiteNatTable');
  if (tbl) tbl.innerHTML = _renderComiteNatTable(membres, egls);

  /* Reset recherche */
  const s = document.getElementById('cnatSearch');
  if (s) s.value = '';
}

/* ── Filtre recherche ────────────────────────────────────────── */
function filterComiteNat() {
  const q      = (document.getElementById('cnatSearch')?.value || '').toLowerCase();
  const statut = document.getElementById('cnatStatutFilter')?.value || '';
  document.querySelectorAll('.cnat-row').forEach(row => {
    const matchQ = !q || row.dataset.nom.includes(q);
    const matchS = !statut || row.dataset.statut === statut;
    row.style.display = (matchQ && matchS) ? '' : 'none';
  });
}

/* ══════════════════════════════════════════════════════════════════
   FORMULAIRE CRÉATION / ÉDITION
══════════════════════════════════════════════════════════════════ */
async function showComiteNatForm(id = null) {
  let egls = [], data = {};
  try {
    egls = (await API.getAll('eglises').catch(() => ({ data: [] }))).data || [];
  } catch (_) {}
  if (id) { try { data = await API.getById('membres_comite_nat', id); } catch (_) {} }

  const sexeActuel = data.sexe || 'homme';
  const grades     = sexeActuel === 'femme'
    ? (typeof GRADES_FEMME !== 'undefined' ? GRADES_FEMME : [])
    : (typeof GRADES_HOMME !== 'undefined' ? GRADES_HOMME : []);

  const html = `
    <div class="form-row">
      <div class="form-group">
        <label>Comité <span style="color:var(--danger)">*</span></label>
        <select class="form-control" id="fcnatType">
          ${Object.entries(COMITES_CONFIG).map(([k, c]) =>
            `<option value="${k}" ${(data.type_comite || _comiteNatActif) === k ? 'selected' : ''}>${k} — ${c.label.split('—')[1]?.trim() || k}</option>`
          ).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Sexe <span style="color:var(--danger)">*</span></label>
        <select class="form-control" id="fcnatSexe"
          onchange="_updateComiteNatGrades()">
          <option value="homme" ${sexeActuel === 'homme' ? 'selected' : ''}>♂ Homme</option>
          <option value="femme" ${sexeActuel === 'femme' ? 'selected' : ''}>♀ Femme</option>
        </select>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Prénom <span style="color:var(--danger)">*</span></label>
        <input class="form-control" id="fcnatPrenom"
          value="${(data.prenom || '').replace(/"/g,'&quot;')}" placeholder="Prénom" />
      </div>
      <div class="form-group">
        <label>Nom <span style="color:var(--danger)">*</span></label>
        <input class="form-control" id="fcnatNom"
          value="${(data.nom || '').replace(/"/g,'&quot;')}" placeholder="Nom de famille" />
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Grade</label>
        <select class="form-control" id="fcnatGrade">
          <option value="">— Choisir le grade —</option>
          ${grades.map(g =>
            `<option value="${g}" ${data.grade === g ? 'selected' : ''}>${g}</option>`
          ).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Rôle dans le comité <span style="color:var(--danger)">*</span>
          <small style="color:var(--text-muted)">(saisie libre)</small></label>
        <input class="form-control" id="fcnatRole"
          value="${(data.role || '').replace(/"/g,'&quot;')}"
          placeholder="Ex: Président, Vice-président, Rapporteur..." />
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Téléphone</label>
        <input class="form-control" id="fcnatTel"
          value="${(data.telephone || '').replace(/"/g,'&quot;')}"
          placeholder="+229 01 XX XX XX XX" />
      </div>
      <div class="form-group">
        <label>Email</label>
        <input class="form-control" id="fcnatEmail"
          value="${(data.email || '').replace(/"/g,'&quot;')}" placeholder="email@exemple.com" />
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Église d'appartenance</label>
        <select class="form-control" id="fcnatEgl">
          <option value="">— Choisir une église —</option>
          ${egls.map(e =>
            `<option value="${e.id}" ${data.eglise_id === e.id ? 'selected' : ''}>${e.nom}</option>`
          ).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Date de nomination</label>
        <input class="form-control" type="date" id="fcnatDate"
          value="${data.date_nomination || new Date().toISOString().slice(0,10)}" />
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Statut</label>
        <select class="form-control" id="fcnatStatut">
          <option value="actif"   ${(data.statut || 'actif') === 'actif'  ? 'selected' : ''}>Actif</option>
          <option value="inactif" ${data.statut === 'inactif' ? 'selected' : ''}>Inactif</option>
        </select>
      </div>
    </div>

    <div class="form-group">
      <label>Notes</label>
      <textarea class="form-control" id="fcnatNotes" rows="3">${data.notes || ''}</textarea>
    </div>`;

  openModal(
    id ? 'Modifier le membre' : 'Nouveau membre — Comité national',
    html,
    id ? 'Enregistrer' : 'Ajouter',
    async () => {
      const type_comite    = document.getElementById('fcnatType')?.value;
      const prenom         = document.getElementById('fcnatPrenom')?.value.trim();
      const nom            = document.getElementById('fcnatNom')?.value.trim();
      const sexe           = document.getElementById('fcnatSexe')?.value || 'homme';
      const grade          = document.getElementById('fcnatGrade')?.value || '';
      const role           = document.getElementById('fcnatRole')?.value.trim();
      const telephone      = document.getElementById('fcnatTel')?.value.trim() || '';
      const email          = document.getElementById('fcnatEmail')?.value.trim() || '';
      const eglise_id      = document.getElementById('fcnatEgl')?.value || '';
      const date_nomination= document.getElementById('fcnatDate')?.value || '';
      const statut         = document.getElementById('fcnatStatut')?.value || 'actif';
      const notes          = document.getElementById('fcnatNotes')?.value.trim() || '';

      if (!prenom || !nom) { showToast('Prénom et Nom requis', 'warning'); return; }
      if (!role)           { showToast('Le rôle est requis', 'warning'); return; }

      const payload = {
        type_comite, prenom, nom, sexe, grade, role,
        telephone, email, eglise_id, date_nomination, statut, notes
      };

      try {
        if (id) {
          await API.update('membres_comite_nat', id, payload);
          showToast('Membre mis à jour', 'success');
        } else {
          await API.create('membres_comite_nat', {
            id: generateId('cnat'), ...payload
          });
          showToast('Membre ajouté au comité !', 'success');
        }
        closeModal();
        renderComitesNationaux();
      } catch (err) {
        showToast('Erreur : ' + err.message, 'error');
      }
    },
    'large'
  );
}

/* Mise à jour grades selon sexe dans le formulaire */
function _updateComiteNatGrades() {
  const sexe   = document.getElementById('fcnatSexe')?.value || 'homme';
  const sel    = document.getElementById('fcnatGrade');
  if (!sel) return;
  const grades = sexe === 'femme'
    ? (typeof GRADES_FEMME !== 'undefined' ? GRADES_FEMME : [])
    : (typeof GRADES_HOMME !== 'undefined' ? GRADES_HOMME : []);
  sel.innerHTML = `<option value="">— Choisir le grade —</option>
    ${grades.map(g => `<option value="${g}">${g}</option>`).join('')}`;
}

/* Suppression */
async function deleteComiteNatMembre(id, nom) {
  confirmDelete(nom, async () => {
    try {
      await API.remove('membres_comite_nat', id);
      showToast('Membre supprimé', 'success');
      closeModal();
      renderComitesNationaux();
    } catch (err) {
      showToast('Erreur : ' + err.message, 'error');
    }
  });
}
