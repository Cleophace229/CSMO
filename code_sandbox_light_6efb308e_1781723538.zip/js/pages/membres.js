/**
 * Membres Page — Recensement Paroissial
 * - Comité paroissial : hommes ET femmes, grades respectifs, postes libres
 * - Compte église : voit uniquement ses propres membres
 * - Format téléphone : +229 01 XX XX XX XX
 * - Chargés paroissiaux / Secrétaires : hommes uniquement
 * - Maître de Chœurs / Adjoint Chœurs : mixte
 */
App.registerAddHandler('membres', () => showMembreForm());

/* Rôles fixes avec contrainte de sexe */
const ROLES_MEMBRES = [
  { label: 'Chargé paroissial',  sexe: 'homme' },
  { label: 'Secrétaire',         sexe: 'homme' },
  { label: 'Secrétaire adjoint', sexe: 'homme' },
  { label: 'Maître de chœurs',   sexe: 'mixte' },
  { label: 'Adjoint chœurs',     sexe: 'mixte' },
  { label: 'Choriste',           sexe: 'mixte' },
  { label: 'Fidèle',             sexe: 'mixte' }
];

let membresPage     = 1;
const MEMS_PER_PAGE = 20;
let allMembres      = [];
let filteredMembres = [];

/* ─── Render principal ──────────────────────────────────────── */
async function renderMembres(params = {}) {
  setBreadcrumb([{ label: I18n.t('membres.title') }]);
  const content = document.getElementById('pageContent');
  const user = Auth.getCurrentUser();
  const isEglise = user && user.eglise_id &&
                   user.role !== 'super_admin' && user.role !== 'admin';

  try {
    const [mems, egls] = await Promise.all([
      API.getAll('membres'),
      API.getAll('eglises')
    ]);

    allMembres = mems.data;

    if (isEglise) {
      filteredMembres = allMembres.filter(m => m.eglise_id === user.eglise_id);
    } else if (params.eglise_id) {
      filteredMembres = allMembres.filter(m => m.eglise_id === params.eglise_id);
    } else {
      filteredMembres = [...allMembres];
    }

    membresPage = 1;

    const eglFilterHTML = !isEglise ? `
      <select class="form-control" id="memEglFilter" style="width:180px"
        onchange="applyMembreFilters()">
        <option value="">${I18n.t('membres.all_churches')}</option>
        ${egls.data.map(e =>
          `<option value="${e.id}" ${params.eglise_id === e.id ? 'selected' : ''}>
            ${e.nom}
          </option>`).join('')}
      </select>` : '';

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-users" style="margin-right:10px"></i>${I18n.t('membres.title')}
          </h2>
          <p id="membresCount">${filteredMembres.length} ${I18n.lang==='en'?'member(s)':'membre(s)'}</p>
        </div>
        <div class="page-header-actions">
          ${Auth.canWrite()
            ? `<button class="btn btn-primary" onclick="showMembreForm()">
                 <i class="fas fa-user-plus"></i> ${I18n.t('membres.new')}
               </button>`
            : ''}
          ${!isEglise
            ? `<button class="btn btn-gold" onclick="App.navigate('export')">
                 <i class="fas fa-file-export"></i> ${I18n.t('membres.export')}
               </button>`
            : ''}
        </div>
      </div>

      <div class="page-search" style="flex-wrap:wrap;gap:8px">
        <div class="search-input-wrapper" style="flex:1;min-width:200px">
          <i class="fas fa-search"></i>
          <input type="text" id="memSearch"
            placeholder="${I18n.t('membres.search')}"
            oninput="applyMembreFilters()" />
        </div>
        ${eglFilterHTML}
        <select class="form-control" id="memGradeFilter" style="width:180px"
          onchange="applyMembreFilters()">
          <option value="">${I18n.t('membres.all_grades')}</option>
          <optgroup label="♂ Hommes">
            ${GRADES_HOMME.map(g => `<option value="${g}">${g}</option>`).join('')}
          </optgroup>
          <optgroup label="♀ Femmes">
            ${GRADES_FEMME.map(g => `<option value="${g}">${g}</option>`).join('')}
          </optgroup>
        </select>
        <select class="form-control" id="memRoleFilter" style="width:160px"
          onchange="applyMembreFilters()">
          <option value="">${I18n.t('membres.all_roles')}</option>
          ${ROLES_MEMBRES.map(r =>
            `<option value="${r.label}">${r.label}</option>`).join('')}
        </select>
        <select class="form-control" id="memSexeFilter" style="width:120px"
          onchange="applyMembreFilters()">
          <option value="">${I18n.t('membres.all')}</option>
          <option value="homme">${I18n.t('membres.men')}</option>
          <option value="femme">${I18n.t('membres.women')}</option>
        </select>
        <select class="form-control" id="memStatutFilter" style="width:130px"
          onchange="applyMembreFilters()">
          <option value="">${I18n.t('membres.all_statuts')}</option>
          <option value="actif">${I18n.t('membres.active')}</option>
          <option value="inactif">${I18n.t('membres.inactive')}</option>
          <option value="suspendu">${I18n.t('membres.suspended')}</option>
        </select>
      </div>

      <!-- Toggle vue -->
      <div style="display:flex;gap:8px;margin-bottom:16px;align-items:center">
        <button class="btn btn-sm btn-primary" id="viewTable"
          onclick="switchMemView('table')">
          <i class="fas fa-table"></i> ${I18n.t('membres.view_table')}
        </button>
        <button class="btn btn-sm btn-secondary" id="viewCards"
          onclick="switchMemView('cards')">
          <i class="fas fa-th-large"></i> ${I18n.t('membres.view_cards')}
        </button>
        <span style="flex:1"></span>
        <span id="membresCount2" style="font-size:12px;color:var(--text-muted)"></span>
      </div>

      <div id="membresContent"></div>
      <div id="memPagination"></div>
    `;

    window._egls          = egls.data;
    window._memView       = 'table';
    window._isEglise      = isEglise;
    window._userEgliseId  = user?.eglise_id || '';

    if (!isEglise && params.eglise_id) {
      const el = document.getElementById('memEglFilter');
      if (el) el.value = params.eglise_id;
    }

    applyMembreFilters();

  } catch (err) {
    content.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-exclamation-triangle"></i>
        <h3>${I18n.t('err.loading')}</h3><p>${err.message}</p>
        <button class="btn btn-primary" onclick="renderMembres()">
          <i class="fas fa-redo"></i> ${I18n.t('btn.retry')}
        </button>
      </div>`;
  }
}

/* ─── Changer la vue ────────────────────────────────────────── */
function switchMemView(type) {
  window._memView = type;
  document.getElementById('viewTable').className =
    `btn btn-sm ${type === 'table' ? 'btn-primary' : 'btn-secondary'}`;
  document.getElementById('viewCards').className =
    `btn btn-sm ${type === 'cards' ? 'btn-primary' : 'btn-secondary'}`;
  renderMembresPage();
}

/* ─── Appliquer les filtres ─────────────────────────────────── */
function applyMembreFilters() {
  const q      = (document.getElementById('memSearch')?.value     || '').toLowerCase();
  const eglId  = document.getElementById('memEglFilter')?.value   || window._userEgliseId || '';
  const grade  = document.getElementById('memGradeFilter')?.value || '';
  const role   = document.getElementById('memRoleFilter')?.value  || '';
  const sexe   = document.getElementById('memSexeFilter')?.value  || '';
  const statut = document.getElementById('memStatutFilter')?.value|| '';

  filteredMembres = allMembres.filter(m => {
    const matchQ      = !q      || `${m.prenom} ${m.nom}`.toLowerCase().includes(q)
                                || (m.telephone || '').includes(q);
    const matchEgl    = !eglId  || m.eglise_id === eglId;
    const matchGrade  = !grade  || m.grade === grade;
    const matchRole   = !role   || m.role === role;
    const matchSexe   = !sexe   || m.sexe === sexe;
    const matchStatut = !statut || m.statut === statut;
    return matchQ && matchEgl && matchGrade && matchRole && matchSexe && matchStatut;
  });

  membresPage = 1;
  const el = document.getElementById('membresCount');
  if (el) el.textContent = `${filteredMembres.length} membre(s)`;
  renderMembresPage();
}

/* ─── Rendu de la page courante ─────────────────────────────── */
function renderMembresPage() {
  const start      = (membresPage - 1) * MEMS_PER_PAGE;
  const pageMems   = filteredMembres.slice(start, start + MEMS_PER_PAGE);
  const totalPages = Math.ceil(filteredMembres.length / MEMS_PER_PAGE);
  const container  = document.getElementById('membresContent');
  const paginEl    = document.getElementById('memPagination');

  const cntEl = document.getElementById('membresCount2');
  if (cntEl) cntEl.textContent = filteredMembres.length > 0
    ? `${start + 1}–${Math.min(start + MEMS_PER_PAGE, filteredMembres.length)} sur ${filteredMembres.length}`
    : '';

  if (filteredMembres.length === 0) {
    container.innerHTML = emptyState(
      'fa-users', 'Aucun membre',
      'Aucun résultat pour les filtres appliqués.',
      Auth.canWrite() ? 'Ajouter un membre' : null,
      'showMembreForm()'
    );
    if (paginEl) paginEl.innerHTML = '';
    return;
  }

  if (window._memView === 'cards') {
    container.innerHTML = `<div class="grid-auto">${pageMems.map(m => {
      const egl = (window._egls || []).find(e => e.id === m.eglise_id);
      const sexeIcon = m.sexe === 'femme' ? '♀' : '♂';
      return `
        <div class="entity-card" onclick="viewMembre('${m.id}')">
          <div class="entity-card-header eglise" style="text-align:center;padding:20px">
            ${memberAvatar(m, 60).replace('display:flex', 'display:flex;margin:0 auto 10px')}
            <h4 style="font-size:15px">
              ${m.prenom} ${m.nom}
              <span style="opacity:.6;font-size:13px">${sexeIcon}</span>
            </h4>
            <p>${egl ? egl.nom : '—'}</p>
          </div>
          <div class="entity-card-body">
            <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin-bottom:8px">
              ${gradeBadge(m.grade)}${roleBadge(m.role)}${statutBadge(m.statut)}
            </div>
            <div class="meta" style="justify-content:center">
              <i class="fas fa-phone"></i>${m.telephone || '—'}
            </div>
          </div>
          <div class="entity-card-footer" style="justify-content:center">
            <button class="btn btn-sm btn-primary"
              onclick="viewMembre('${m.id}');event.stopPropagation()">
              <i class="fas fa-eye"></i>
            </button>
            ${Auth.canWrite()
              ? `<button class="btn btn-sm btn-outline"
                   onclick="showMembreForm('${m.id}');event.stopPropagation()">
                   <i class="fas fa-edit"></i>
                 </button>`
              : ''}
            ${Auth.canDelete()
              ? `<button class="btn btn-sm btn-danger"
                   onclick="deleteMembre('${m.id}','${m.prenom} ${m.nom}');event.stopPropagation()">
                   <i class="fas fa-trash"></i>
                 </button>`
              : ''}
          </div>
        </div>`;
    }).join('')}</div>`;

  } else {
    container.innerHTML = `
      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>Membre</th><th>Sexe</th><th>Église</th>
            <th>Grade</th><th>Rôle</th><th>Téléphone</th>
            <th>Adhésion</th><th>Statut</th><th>Actions</th>
          </tr></thead>
          <tbody>
            ${pageMems.map(m => {
              const egl = (window._egls || []).find(e => e.id === m.eglise_id);
              const sexeLabel = m.sexe === 'femme'
                ? '<span style="color:#e91e8c">♀ Femme</span>'
                : '<span style="color:#2196f3">♂ Homme</span>';
              return `
                <tr>
                  <td>
                    <div class="member-row">
                      ${memberAvatar(m, 36)}
                      <div class="member-info">
                        <h4>${m.prenom} ${m.nom}</h4>
                        <p>${m.email || ''}</p>
                      </div>
                    </div>
                  </td>
                  <td style="font-size:12px">${sexeLabel}</td>
                  <td style="font-size:12px">${egl ? egl.nom : '—'}</td>
                  <td>${gradeBadge(m.grade)}</td>
                  <td>${roleBadge(m.role)}</td>
                  <td>${m.telephone || '—'}</td>
                  <td>${formatDateShort(m.date_adhesion)}</td>
                  <td>${statutBadge(m.statut)}</td>
                  <td>
                    <div class="td-actions">
                      <button class="btn btn-xs btn-primary"
                        onclick="viewMembre('${m.id}')">
                        <i class="fas fa-eye"></i>
                      </button>
                      ${Auth.canWrite()
                        ? `<button class="btn btn-xs btn-outline"
                             onclick="showMembreForm('${m.id}')">
                             <i class="fas fa-edit"></i>
                           </button>`
                        : ''}
                      ${Auth.canDelete()
                        ? `<button class="btn btn-xs btn-danger"
                             onclick="deleteMembre('${m.id}','${m.prenom} ${m.nom}')">
                             <i class="fas fa-trash"></i>
                           </button>`
                        : ''}
                    </div>
                  </td>
                </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>`;
  }

  renderPagination(paginEl, membresPage, totalPages, 'goMemPage');
}

function goMemPage(p) {
  membresPage = p;
  renderMembresPage();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* ─── Vue détail membre ─────────────────────────────────────── */
async function viewMembre(id) {
  try {
    const [m, egls, hist] = await Promise.all([
      API.getById('membres', id),
      API.getAll('eglises'),
      API.getAll('historique').catch(() => ({ data: [] }))
    ]);
    const egl   = egls.data.find(e => e.id === m.eglise_id);
    const mHist = hist.data
      .filter(h => h.membre_id === id)
      .sort((a, b) =>
        new Date(b.date_action || 0) - new Date(a.date_action || 0));

    const html = `
      <div class="profile-banner">
        <div class="profile-avatar-lg">
          ${m.photo_url
            ? `<img src="${m.photo_url}" alt="${m.prenom}">`
            : `${(m.prenom || '?')[0]}${(m.nom || '?')[0]}`}
        </div>
        <h2>${m.prenom} ${m.nom}</h2>
        <p>${egl ? egl.nom : 'Église non définie'} · ${m.grade || '—'}</p>
        <div style="display:flex;gap:8px;justify-content:center;margin-top:10px;flex-wrap:wrap">
          ${roleBadge(m.role)}${statutBadge(m.statut)}
          <span class="badge ${m.sexe === 'femme' ? 'badge-info' : 'badge-primary'}">
            ${m.sexe === 'femme' ? '♀ Femme' : '♂ Homme'}
          </span>
        </div>
      </div>

      <div class="profile-tabs" style="padding:0 22px">
        <div class="profile-tab active" onclick="switchMemTab(this,'mtab-info')">
          Informations
        </div>
        <div class="profile-tab" onclick="switchMemTab(this,'mtab-hist')">
          Historique (${mHist.length})
        </div>
      </div>

      <div class="profile-body">
        <div id="mtab-info" class="tab-content active" style="display:block">
          <div class="detail-grid">
            <div class="detail-item"><label>Prénom</label><p>${m.prenom || '—'}</p></div>
            <div class="detail-item"><label>Nom</label><p>${m.nom || '—'}</p></div>
            <div class="detail-item"><label>Sexe</label>
              <p>${m.sexe === 'femme' ? '♀ Femme' : '♂ Homme'}</p></div>
            <div class="detail-item"><label>Téléphone</label><p>${m.telephone || '—'}</p></div>
            <div class="detail-item"><label>Email</label><p>${m.email || '—'}</p></div>
            <div class="detail-item"><label>Date de naissance</label>
              <p>${formatDate(m.date_naissance)}</p></div>
            <div class="detail-item"><label>Date d'adhésion</label>
              <p>${formatDate(m.date_adhesion)}</p></div>
            <div class="detail-item"><label>Grade</label><p>${gradeBadge(m.grade)}</p></div>
            <div class="detail-item"><label>Rôle</label><p>${roleBadge(m.role)}</p></div>
            <div class="detail-item"><label>Statut</label><p>${statutBadge(m.statut)}</p></div>
            <div class="detail-item"><label>Église</label><p>${egl ? egl.nom : '—'}</p></div>
          </div>
          ${m.notes ? `
            <div class="mt-2">
              <label style="font-size:11px;text-transform:uppercase;
                color:var(--text-muted);font-weight:600">Notes</label>
              <p style="font-size:13px;margin-top:4px">${m.notes}</p>
            </div>` : ''}
          ${Auth.canWrite() ? `
            <div class="mt-2" style="display:flex;gap:8px;flex-wrap:wrap">
              <button class="btn btn-sm btn-primary"
                onclick="closeModal();showMembreForm('${m.id}')">
                <i class="fas fa-edit"></i> Modifier
              </button>
              <button class="btn btn-sm btn-warning"
                onclick="changeStatutMembre('${m.id}','${m.statut || 'actif'}')">
                <i class="fas fa-exchange-alt"></i> Changer statut
              </button>
            </div>` : ''}
        </div>

        <div id="mtab-hist" class="tab-content" style="display:none">
          ${mHist.length === 0
            ? '<p class="text-center text-muted" style="padding:20px">Aucun historique disponible</p>'
            : mHist.map(h => `
              <div style="padding:10px 0;border-bottom:1px solid var(--border);
                          display:flex;gap:12px;align-items:flex-start">
                <div style="width:36px;height:36px;border-radius:50%;
                  background:var(--accent);display:flex;align-items:center;
                  justify-content:center;flex-shrink:0">
                  <i class="fas fa-history" style="color:var(--primary);font-size:14px"></i>
                </div>
                <div>
                  <div style="font-weight:600;font-size:13px">${h.type_action || '—'}</div>
                  <div style="font-size:12px;color:var(--text-muted)">
                    ${h.ancienne_valeur
                      ? `${h.ancienne_valeur} → ${h.nouvelle_valeur}`
                      : (h.nouvelle_valeur || '')}
                  </div>
                  <div style="font-size:11px;color:var(--text-light)">
                    ${formatDateShort(h.date_action)}
                  </div>
                </div>
              </div>`).join('')}
          ${Auth.canWrite() ? `
            <button class="btn btn-sm btn-primary mt-2"
              onclick="ajouterHistorique('${m.id}')">
              <i class="fas fa-plus"></i> Ajouter entrée
            </button>` : ''}
        </div>
      </div>
    `;

    openModal(`${m.prenom} ${m.nom}`, html, '', null, 'large');
  } catch (err) {
    showToast('Erreur lors du chargement : ' + err.message, 'error');
  }
}

function switchMemTab(el, tabId) {
  const wrapper = el.closest('.modal-body') || document;
  wrapper.querySelectorAll('.profile-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  ['mtab-info', 'mtab-hist'].forEach(id => {
    const t = document.getElementById(id);
    if (t) t.style.display = 'none';
  });
  const tc = document.getElementById(tabId);
  if (tc) tc.style.display = 'block';
}

/* ─── Formulaire membre ─────────────────────────────────────── */
async function showMembreForm(id = null) {
  let egls, data = {};
  try {
    egls = await API.getAll('eglises');
  } catch (err) {
    showToast('Impossible de charger les données : ' + err.message, 'error');
    return;
  }
  if (id) { try { data = await API.getById('membres', id); } catch {} }

  const user    = Auth.getCurrentUser();
  const isEglise = user && user.eglise_id &&
                   user.role !== 'super_admin' && user.role !== 'admin';
  const preselEgl   = isEglise ? user.eglise_id : (data.eglise_id || '');
  const sexeActuel  = data.sexe || 'homme';
  const gradesActuels = sexeActuel === 'femme' ? GRADES_FEMME : GRADES_HOMME;

  /* Filtrer les rôles selon le sexe actuel */
  const rolesFiltres = ROLES_MEMBRES.filter(r =>
    r.sexe === 'mixte' || r.sexe === sexeActuel
  );

  const html = `
    <div class="form-row">
      <div class="form-group">
        <label>Prénom <span style="color:var(--danger)">*</span></label>
        <input class="form-control" id="fMemPrenom"
          value="${(data.prenom || '').replace(/"/g,'&quot;')}"
          placeholder="Prénom" />
      </div>
      <div class="form-group">
        <label>Nom <span style="color:var(--danger)">*</span></label>
        <input class="form-control" id="fMemNom"
          value="${(data.nom || '').replace(/"/g,'&quot;')}"
          placeholder="Nom de famille" />
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Sexe <span style="color:var(--danger)">*</span></label>
        <select class="form-control" id="fMemSexe"
          onchange="updateGradeOptions();updateRoleOptions()">
          <option value="homme" ${sexeActuel === 'homme' ? 'selected' : ''}>♂ Homme</option>
          <option value="femme" ${sexeActuel === 'femme' ? 'selected' : ''}>♀ Femme</option>
        </select>
      </div>
      <div class="form-group">
        <label>Grade</label>
        <select class="form-control" id="fMemGrade">
          <option value="">— Choisir le grade —</option>
          ${gradesActuels.map(g =>
            `<option value="${g}" ${data.grade === g ? 'selected' : ''}>${g}</option>`
          ).join('')}
        </select>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Rôle dans la paroisse</label>
        <select class="form-control" id="fMemRole">
          <option value="">— Choisir —</option>
          ${rolesFiltres.map(r =>
            `<option value="${r.label}"
               ${data.role === r.label ? 'selected' : ''}
               ${r.sexe !== 'mixte'
                 ? `data-sexe="${r.sexe}" style="color:var(--text-muted)"`
                 : ''}
             >${r.label}${r.sexe === 'homme' ? ' (♂)' : ''}</option>`
          ).join('')}
        </select>
        <p class="form-hint" id="roleHint" style="display:none;color:var(--danger)"></p>
      </div>
      <div class="form-group">
        <label>Église <span style="color:var(--danger)">*</span></label>
        <select class="form-control" id="fMemEgl" ${isEglise ? 'disabled' : ''}>
          <option value="">— Choisir —</option>
          ${egls.data.map(e =>
            `<option value="${e.id}" ${preselEgl === e.id ? 'selected' : ''}>${e.nom}</option>`
          ).join('')}
        </select>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Téléphone <small style="color:var(--text-muted)">(+229 01 XX XX XX XX)</small></label>
        <input class="form-control" id="fMemTel"
          value="${(data.telephone || '').replace(/"/g,'&quot;')}"
          placeholder="+229 01 XX XX XX XX" />
      </div>
      <div class="form-group">
        <label>Email</label>
        <input class="form-control" id="fMemEmail"
          value="${(data.email || '').replace(/"/g,'&quot;')}"
          placeholder="email@exemple.com" />
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Date de naissance</label>
        <input class="form-control" type="date" id="fMemDN"
          value="${data.date_naissance || ''}" />
      </div>
      <div class="form-group">
        <label>Date d'adhésion</label>
        <input class="form-control" type="date" id="fMemDA"
          value="${data.date_adhesion || new Date().toISOString().slice(0,10)}" />
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Statut</label>
        <select class="form-control" id="fMemStatut">
          <option value="actif"    ${(data.statut||'actif')==='actif'   ?'selected':''}>Actif</option>
          <option value="inactif"  ${data.statut==='inactif' ?'selected':''}>Inactif</option>
          <option value="suspendu" ${data.statut==='suspendu'?'selected':''}>Suspendu</option>
        </select>
      </div>
    </div>

    <div class="form-group">
      <label>Notes</label>
      <textarea class="form-control" id="fMemNotes">${data.notes || ''}</textarea>
    </div>
  `;

  openModal(
    id ? 'Modifier le membre' : 'Nouveau membre',
    html,
    id ? 'Enregistrer' : 'Inscrire',
    async () => {
      const prenom    = document.getElementById('fMemPrenom')?.value.trim();
      const nom       = document.getElementById('fMemNom')?.value.trim();
      const sexe      = document.getElementById('fMemSexe')?.value;
      const roleVal   = document.getElementById('fMemRole')?.value;
      const eglise_id = isEglise
        ? user.eglise_id
        : document.getElementById('fMemEgl')?.value;

      if (!prenom || !nom) {
        showToast('Prénom et Nom sont requis', 'warning'); return;
      }
      if (!eglise_id) {
        showToast('Veuillez choisir une église', 'warning'); return;
      }

      /* Validation rôle selon sexe */
      if (roleVal) {
        const roleInfo = ROLES_MEMBRES.find(r => r.label === roleVal);
        if (roleInfo && roleInfo.sexe !== 'mixte' && roleInfo.sexe !== sexe) {
          showToast(`Le rôle "${roleVal}" est réservé aux ${roleInfo.sexe === 'homme' ? 'hommes' : 'femmes'}`, 'warning');
          return;
        }
      }

      const gradeOld = data.grade || '';
      const gradeNew = document.getElementById('fMemGrade')?.value || '';

      const payload = {
        prenom, nom, sexe, eglise_id,
        grade:          gradeNew,
        role:           roleVal,
        telephone:      document.getElementById('fMemTel')?.value.trim()  || '',
        email:          document.getElementById('fMemEmail')?.value.trim()|| '',
        date_naissance: document.getElementById('fMemDN')?.value          || '',
        date_adhesion:  document.getElementById('fMemDA')?.value          || '',
        statut:         document.getElementById('fMemStatut')?.value      || 'actif',
        notes:          document.getElementById('fMemNotes')?.value.trim()|| ''
      };

      try {
        if (id) {
          await API.update('membres', id, payload);
          if (gradeOld !== gradeNew) {
            await logHistory(id, eglise_id, 'Changement de grade', gradeOld, gradeNew);
          }
          /* Si le rôle est Choriste → s'assurer qu'il est dans la table choristes */
          if (roleVal === 'Choriste') {
            await _autoRegisterChoriste(id, prenom, nom, sexe, gradeNew, eglise_id, payload);
          }
          showToast('Membre mis à jour', 'success');
        } else {
          const newId = generateId('mem');
          await API.create('membres', { id: newId, ...payload });
          await logHistory(newId, eglise_id, 'Admission', '',
            `${prenom} ${nom} inscrit(e)`);
          /* Si le rôle est Choriste → créer l'entrée dans choristes */
          if (roleVal === 'Choriste') {
            await _autoRegisterChoriste(newId, prenom, nom, sexe, gradeNew, eglise_id, payload);
          }
          showToast('Membre inscrit avec succès', 'success');
        }
        closeModal();
        renderMembres();
      } catch (err) {
        showToast('Erreur : ' + err.message, 'error');
      }
    },
    'large'
  );
}

/* Met à jour les grades selon le sexe */
function updateGradeOptions() {
  const sexe   = document.getElementById('fMemSexe')?.value || 'homme';
  const grades = sexe === 'femme' ? GRADES_FEMME : GRADES_HOMME;
  const sel    = document.getElementById('fMemGrade');
  if (!sel) return;
  sel.innerHTML = `<option value="">— Choisir le grade —</option>
    ${grades.map(g => `<option value="${g}">${g}</option>`).join('')}`;
}

/* Met à jour les rôles disponibles selon le sexe */
function updateRoleOptions() {
  const sexe = document.getElementById('fMemSexe')?.value || 'homme';
  const sel  = document.getElementById('fMemRole');
  if (!sel) return;
  const currentVal = sel.value;
  const filtres = ROLES_MEMBRES.filter(r => r.sexe === 'mixte' || r.sexe === sexe);
  sel.innerHTML = `<option value="">— Choisir —</option>
    ${filtres.map(r =>
      `<option value="${r.label}"
         ${currentVal === r.label ? 'selected' : ''}
       >${r.label}${r.sexe === 'homme' ? ' (♂)' : ''}</option>`
    ).join('')}`;
}

/* ─── Helpers ────────────────────────────────────────────────── */
async function logHistory(memId, egliseId, type, ancien, nouveau) {
  try {
    await API.create('historique', {
      id:              generateId('hist'),
      membre_id:       memId,
      eglise_id:       egliseId || '',
      type_action:     type,
      ancienne_valeur: ancien || '',
      nouvelle_valeur: nouveau || '',
      date_action:     new Date().toISOString().slice(0, 10),
      notes:           ''
    });
  } catch (_) { /* non bloquant */ }
}

async function deleteMembre(id, nom) {
  confirmDelete(nom, async () => {
    try {
      await API.remove('membres', id);
      showToast('Membre supprimé', 'success');
      closeModal();
      renderMembres();
    } catch (err) {
      showToast('Erreur : ' + err.message, 'error');
    }
  });
}

async function changeStatutMembre(id, statutActuel) {
  const statuts = ['actif', 'inactif', 'suspendu'];
  const html = `
    <div class="form-group">
      <label>Nouveau statut</label>
      <select class="form-control" id="newStatutSel">
        ${statuts.map(s =>
          `<option value="${s}" ${s === statutActuel ? 'selected' : ''}>
            ${s.charAt(0).toUpperCase() + s.slice(1)}
          </option>`
        ).join('')}
      </select>
    </div>
    <div class="form-group">
      <label>Motif (optionnel)</label>
      <input class="form-control" id="newStatutNote"
        placeholder="Raison du changement" />
    </div>`;

  openModal('Changer le statut', html, 'Confirmer', async () => {
    const nouveau = document.getElementById('newStatutSel')?.value;
    const note    = document.getElementById('newStatutNote')?.value.trim() || '';
    try {
      const m = await API.getById('membres', id);
      await API.update('membres', id, { ...m, statut: nouveau });
      await logHistory(id, m.eglise_id, 'Changement de statut',
        statutActuel, nouveau + (note ? ` — ${note}` : ''));
      showToast('Statut mis à jour', 'success');
      closeModal();
      renderMembres();
    } catch (err) {
      showToast('Erreur : ' + err.message, 'error');
    }
  }, 'small');
}

async function ajouterHistorique(memId) {
  const html = `
    <div class="form-group">
      <label>Type d'action</label>
      <input class="form-control" id="histType"
        placeholder="Ex: Promotion, Formation..." />
    </div>
    <div class="form-group">
      <label>Ancienne valeur</label>
      <input class="form-control" id="histAnc" placeholder="Valeur précédente" />
    </div>
    <div class="form-group">
      <label>Nouvelle valeur</label>
      <input class="form-control" id="histNouv" placeholder="Nouvelle valeur" />
    </div>
    <div class="form-group">
      <label>Date</label>
      <input class="form-control" type="date" id="histDate"
        value="${new Date().toISOString().slice(0,10)}" />
    </div>
    <div class="form-group">
      <label>Notes</label>
      <textarea class="form-control" id="histNotes"></textarea>
    </div>`;

  openModal('Ajouter une entrée historique', html, 'Ajouter', async () => {
    const type = document.getElementById('histType')?.value.trim();
    if (!type) { showToast('Le type est requis', 'warning'); return; }
    try {
      const m = await API.getById('membres', memId);
      await API.create('historique', {
        id:              generateId('hist'),
        membre_id:       memId,
        eglise_id:       m.eglise_id || '',
        type_action:     type,
        ancienne_valeur: document.getElementById('histAnc')?.value.trim()   || '',
        nouvelle_valeur: document.getElementById('histNouv')?.value.trim()  || '',
        date_action:     document.getElementById('histDate')?.value         || '',
        notes:           document.getElementById('histNotes')?.value.trim() || ''
      });
      showToast('Entrée ajoutée', 'success');
      closeModal();
    } catch (err) {
      showToast('Erreur : ' + err.message, 'error');
    }
  });
}

/* ═══════════════════════════════════════════════════════════
   AUTO-ENREGISTREMENT CHORISTE
   Quand un membre a le rôle "Choriste", il est automatiquement
   enregistré dans la table "choristes" s'il n'y est pas déjà.
═══════════════════════════════════════════════════════════ */
async function _autoRegisterChoriste(memId, prenom, nom, sexe, grade, eglise_id, payload) {
  try {
    /* Vérifier s'il est déjà dans choristes (par membre_id ou par nom+eglise) */
    const existing = await API.getAll('choristes', { limit: 1000 });
    const alreadyIn = existing.data.find(c =>
      c.membre_id === memId ||
      (c.nom === nom && c.prenom === prenom && c.eglise_id === eglise_id)
    );

    if (alreadyIn) {
      /* Mettre à jour son grade si nécessaire */
      if (grade && alreadyIn.grade !== grade) {
        const updated = { ...alreadyIn, grade };
        await API.update('choristes', alreadyIn.id, updated);
      }
      return; /* Déjà enregistré — pas de doublon */
    }

    /* Créer l'entrée choriste */
    await API.create('choristes', {
      id:            generateId('chor'),
      membre_id:     memId,
      nom:           nom || '',
      prenom:        prenom || '',
      sexe:          sexe || 'homme',
      grade:         grade || '',
      voix:          '',                /* À renseigner ultérieurement */
      telephone:     payload.telephone || '',
      email:         payload.email || '',
      eglise_id:     eglise_id || '',
      date_adhesion: payload.date_adhesion || new Date().toISOString().slice(0, 10),
      statut:        payload.statut || 'actif',
      notes:         'Enregistré automatiquement depuis la fiche membre'
    });

    showToast(`🎵 ${prenom} ${nom} automatiquement ajouté(e) à la liste des choristes`, 'info', 4000);
  } catch (err) {
    /* Non bloquant — loguer silencieusement */
    console.warn('[AutoChoriste] Erreur:', err.message);
  }
}
