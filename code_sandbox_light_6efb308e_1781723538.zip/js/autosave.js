/**
 * autosave.js — Sauvegarde automatique & Synchronisation
 * - Indicateur de statut de connexion
 * - File d'attente pour les opérations offline
 * - Indicateur visuel de synchronisation dans la topbar
 */

const AutoSave = {
  queue: JSON.parse(localStorage.getItem('autosave_queue') || '[]'),
  syncing: false,
  online: navigator.onLine,
  lastSync: localStorage.getItem('autosave_last_sync') || null,

  init() {
    // Surveiller la connectivité
    window.addEventListener('online', () => {
      this.online = true;
      this.updateIndicator();
      this.processQueue();
      showToast('Connexion rétablie. Synchronisation en cours...', 'success');
    });

    window.addEventListener('offline', () => {
      this.online = false;
      this.updateIndicator();
      showToast('Mode hors ligne activé. Les modifications seront synchronisées à la reconnexion.', 'warning');
    });

    // Sync toutes les 60 secondes
    setInterval(() => { if (this.online && this.queue.length > 0) this.processQueue(); }, 60000);

    // Sync initiale
    if (this.online && this.queue.length > 0) {
      setTimeout(() => this.processQueue(), 2000);
    }

    this.updateIndicator();
  },

  // ── Ajouter à la file ─────────────────────────────────────
  enqueue(operation) {
    operation.id = `op_${Date.now()}_${Math.random().toString(36).slice(2,6)}`;
    operation.timestamp = Date.now();
    this.queue.push(operation);
    this.saveQueue();
    this.updateIndicator();
    if (this.online) this.processQueue();
  },

  saveQueue() {
    localStorage.setItem('autosave_queue', JSON.stringify(this.queue));
  },

  // ── Traiter la file ───────────────────────────────────────
  async processQueue() {
    if (this.syncing || this.queue.length === 0 || !this.online) return;
    this.syncing = true;
    this.setSyncState('syncing');

    const processed = [];
    for (const op of this.queue) {
      try {
        switch (op.type) {
          case 'create': await API.create(op.table, op.data); break;
          case 'update': await API.update(op.table, op.id, op.data); break;
          case 'patch':  { const full = await API.getById(op.table, op.id); await API.update(op.table, op.id, { ...full, ...op.data }); break; }
          case 'delete': await API.remove(op.table, op.id); break;
        }
        processed.push(op.id);
      } catch (e) {
        console.warn('[AutoSave] Erreur sync:', e.message);
      }
    }

    this.queue = this.queue.filter(op => !processed.includes(op.id));
    this.saveQueue();
    this.syncing = false;
    this.lastSync = new Date().toISOString();
    localStorage.setItem('autosave_last_sync', this.lastSync);
    this.setSyncState(this.queue.length > 0 ? 'pending' : 'synced');
  },

  // ── Mise à jour de l'indicateur topbar ───────────────────
  updateIndicator() {
    const btn = document.getElementById('syncIndicator');
    if (!btn) return;
    if (!this.online) {
      btn.innerHTML = '<i class="fas fa-wifi-slash"></i>';
      btn.title = 'Hors ligne';
      btn.style.color = '#C0392B';
    } else if (this.queue.length > 0) {
      btn.innerHTML = `<i class="fas fa-sync-alt fa-spin"></i> <span style="font-size:10px">${this.queue.length}</span>`;
      btn.title = `${this.queue.length} opération(s) en attente`;
      btn.style.color = '#D68910';
    } else {
      const t = this.lastSync ? new Date(this.lastSync).toLocaleTimeString('fr-FR') : '—';
      btn.innerHTML = '<i class="fas fa-cloud-upload-alt"></i>';
      btn.title = `Synchronisé · Dernière sync : ${t}`;
      btn.style.color = '#1E8449';
    }
  },

  setSyncState(state) {
    const btn = document.getElementById('syncIndicator');
    if (!btn) return;
    if (state === 'syncing') {
      btn.innerHTML = '<i class="fas fa-sync-alt fa-spin"></i>';
      btn.title = 'Synchronisation...';
      btn.style.color = '#1A5276';
    } else {
      this.updateIndicator();
    }
  },

  // ── Afficher le détail de la file ─────────────────────────
  showQueuePanel() {
    const html = `
      <div style="margin-bottom:12px;display:flex;justify-content:space-between;align-items:center">
        <div>
          <span class="badge ${this.online ? 'badge-success' : 'badge-danger'}">
            <i class="fas fa-${this.online ? 'wifi' : 'wifi-slash'}"></i> ${this.online ? 'En ligne' : 'Hors ligne'}
          </span>
        </div>
        <div style="font-size:12px;color:var(--text-muted)">
          Dernière sync : ${this.lastSync ? new Date(this.lastSync).toLocaleString('fr-FR') : 'Jamais'}
        </div>
      </div>

      ${this.queue.length === 0
        ? `<div class="empty-state" style="padding:30px"><i class="fas fa-check-circle" style="color:var(--success);font-size:40px;margin-bottom:10px"></i><h3>Tout est synchronisé</h3><p>Aucune opération en attente.</p></div>`
        : `<div style="font-size:13px;font-weight:600;margin-bottom:8px;color:var(--warning)">${this.queue.length} opération(s) en attente de synchronisation :</div>
          <div style="max-height:300px;overflow-y:auto">
            ${this.queue.map(op => `
              <div style="padding:8px 12px;background:var(--bg);border-radius:8px;margin-bottom:6px;font-size:12px">
                <span class="badge badge-warning">${op.type.toUpperCase()}</span>
                <span style="margin-left:8px;font-weight:500">${op.table}</span>
                ${op.id ? `<span style="color:var(--text-muted);margin-left:4px">#${op.id.slice(-6)}</span>` : ''}
                <span style="float:right;color:var(--text-muted)">${new Date(op.timestamp).toLocaleTimeString('fr-FR')}</span>
              </div>`).join('')}
          </div>
          ${this.online ? `<button class="btn btn-primary btn-sm mt-2" onclick="AutoSave.processQueue();closeModal()"><i class="fas fa-sync-alt"></i> Synchroniser maintenant</button>` : ''}
        `}
    `;
    openModal('Statut de synchronisation', html, '', null, 'small');
  }
};
