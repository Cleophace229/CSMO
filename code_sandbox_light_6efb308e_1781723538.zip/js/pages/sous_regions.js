/**
 * Sous-Régions Page — Recensement Paroissial
 * Responsable régional : homme avec grade masculin
 * Format contact : +229 01 XX XX XX XX
 */
App.registerAddHandler('sous_regions', () => showSousRegionForm());

async function renderSousRegions(params = {}) {
  setBreadcrumb([
    { label: I18n.t('regions.title'), onclick: "App.navigate('regions')" },
    { label: I18n.t('srs.title') }
  ]);
  const content = document.getElementById('pageContent');
  try {
    const [regs, srs, egls, mems] = await Promise.all([
      API.getAll('regions'),
      API.getAll('sous_regions'),
      API.getAll('eglises'),
      API.getAll('membres')
    ]);

    let filteredSrs  = srs.data;
    let activeRegion = null;

    if (params.region_id) {
      filteredSrs  = srs.data.filter(s => s.region_id === params.region_id);
      activeRegion = regs.data.find(r => r.id === params.region_id);
    }

    const chips = `
      <div class="filter-chips" style="flex-wrap:wrap;margin-bottom:12px">
        <span class="chip ${!params.region_id ? 'active' : ''}"
          onclick="App.navigate('sous_regions')">${I18n.t('eglises.all_regions')}</span>
        ${regs.data.map(r =>
          `<span class="chip ${params.region_id === r.id ? 'active' : ''}"
            onclick="App.navigate('sous_regions',{region_id:'${r.id}'})">${r.nom}</span>`
        ).join('')}
      </div>`;

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-map-marked-alt" style="margin-right:10px"></i>
            ${I18n.t('srs.title')}${activeRegion ? ' · ' + activeRegion.nom : ''}
          </h2>
          <p>${filteredSrs.length} ${I18n.lang==='en'?'sub-region(s)':'sous-région(s)'}</p>
        </div>
        <div class="page-header-actions">
          ${Auth.canWrite()
            ? `<button class="btn btn-primary" onclick="showSousRegionForm()">
                 <i class="fas fa-plus"></i> ${I18n.t('srs.new')}
               </button>`
            : ''}
        </div>
      </div>

      ${chips}

      <div class="page-search">
        <div class="search-input-wrapper">
          <i class="fas fa-search"></i>
          <input type="text" id="srSearch" placeholder="${I18n.t('srs.search')}"
            oninput="filterSousRegions()" />
        </div>
      </div>

      <div class="grid-auto" id="srsGrid">
        ${filteredSrs.length === 0
          ? emptyState('fa-map-marked-alt', 'Aucune sous-région',
              'Créez votre première sous-région.',
              Auth.canWrite() ? 'Créer' : null, 'showSousRegionForm()')
          : ''}
        ${filteredSrs.map(sr => {
          const reg    = regs.data.find(r => r.id === sr.region_id);
          const srEgls = egls.data.filter(e => e.sous_region_id === sr.id);
          const srMems = mems.data.filter(m => srEgls.some(e => e.id === m.eglise_id));
          const grade  = sr.responsable_grade || '';
          return `
          <div class="entity-card" data-name="${(sr.nom || '').toLowerCase()}" data-id="${sr.id}">
            <div class="entity-card-header sous-region">
              <div class="entity-card-icon"><i class="fas fa-map-marked-alt"></i></div>
              <h4>${sr.nom}</h4>
              <p>
                <i class="fas fa-globe-africa" style="margin-right:4px"></i>
                ${reg ? reg.nom : 'Région inconnue'}
              </p>
            </div>
            <div class="entity-card-body">
              <div class="meta">
                <i class="fas fa-user-tie"></i>
                ${sr.responsable || '<em style="opacity:.6">Non défini</em>'}
                ${grade
                  ? `<span class="badge badge-gold" style="margin-left:6px;font-size:10px">${grade}</span>`
                  : ''}
              </div>
              <div class="meta"><i class="fas fa-phone"></i>${sr.contact || '—'}</div>
              <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
                <span class="badge badge-success">
                  <i class="fas fa-church"></i> ${srEgls.length} église(s)
                </span>
                <span class="badge badge-primary">
                  <i class="fas fa-users"></i> ${srMems.length} membre(s)
                </span>
              </div>
            </div>
            <div class="entity-card-footer">
              <button class="btn btn-sm btn-primary"
                onclick="App.navigate('eglises',{sous_region_id:'${sr.id}'})">
                <i class="fas fa-eye"></i> Voir
              </button>
              ${Auth.canWrite()
                ? `<button class="btn btn-sm btn-outline" onclick="showSousRegionForm('${sr.id}')">
                     <i class="fas fa-edit"></i> Modifier
                   </button>`
                : ''}
              ${Auth.canDelete()
                ? `<button class="btn btn-sm btn-danger"
                     onclick="deleteSousRegion('${sr.id}','${(sr.nom || '').replace(/'/g,"\\'")}')">
                     <i class="fas fa-trash"></i>
                   </button>`
                : ''}
            </div>
          </div>`;
        }).join('')}
      </div>`;

  } catch (err) {
    document.getElementById('pageContent').innerHTML =
      `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i>
       <h3>Erreur</h3><p>${err.message}</p></div>`;
  }
}

function filterSousRegions() {
  const q = (document.getElementById('srSearch')?.value || '').toLowerCase();
  document.querySelectorAll('#srsGrid .entity-card').forEach(card => {
    card.style.display = card.dataset.name.includes(q) ? '' : 'none';
  });
}

async function showSousRegionForm(id = null) {
  const regs = await API.getAll('regions');
  let data = {};
  if (id) { try { data = await API.getById('sous_regions', id); } catch {} }

  const grades = typeof GRADES_HOMME !== 'undefined' ? GRADES_HOMME : [];

  const html = `
    <div class="form-group">
      <label>Nom de la sous-région <span style="color:var(--danger)">*</span></label>
      <input class="form-control" id="fSrNom"
        value="${(data.nom || '').replace(/"/g,'&quot;')}"
        placeholder="Ex: Sous-région Nord-Est" />
    </div>

    <div class="form-group">
      <label>Région parente <span style="color:var(--danger)">*</span></label>
      <select class="form-control" id="fSrRegion">
        <option value="">— Choisir une région —</option>
        ${regs.data.map(r =>
          `<option value="${r.id}" ${data.region_id === r.id ? 'selected' : ''}>${r.nom}</option>`
        ).join('')}
      </select>
    </div>

    <div style="background:linear-gradient(135deg,#fafbff,#f3e9ff);
      border:1px solid rgba(108,52,131,0.15);border-radius:10px;padding:14px;margin-bottom:12px">
      <div style="font-size:12px;font-weight:700;color:var(--primary-dark);
        text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">
        <i class="fas fa-user-tie" style="margin-right:6px;color:var(--gold)"></i>
        Responsable de Sous-région
        <span style="font-size:10px;background:#f0e6ff;color:var(--primary);
          padding:1px 6px;border-radius:10px;margin-left:6px;font-weight:600">♂ Homme</span>
      </div>
      <div class="form-row" style="margin:0;gap:12px">
        <div class="form-group" style="margin-bottom:0;flex:1">
          <label style="font-size:11px">Nom complet</label>
          <input class="form-control" id="fSrResp"
            value="${(data.responsable || '').replace(/"/g,'&quot;')}"
            placeholder="Prénom Nom du responsable" />
        </div>
        <div class="form-group" style="margin-bottom:0;flex:1">
          <label style="font-size:11px">Grade <small style="color:var(--text-muted)">(masculin)</small></label>
          <select class="form-control" id="fSrGrade">
            <option value="">— Choisir le grade —</option>
            ${grades.map(g =>
              `<option value="${g}" ${(data.responsable_grade || '') === g ? 'selected' : ''}>${g}</option>`
            ).join('')}
          </select>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label>Contact <small style="color:var(--text-muted)">(+229 01 XX XX XX XX)</small></label>
      <input class="form-control" id="fSrContact"
        value="${(data.contact || '').replace(/"/g,'&quot;')}"
        placeholder="+229 01 XX XX XX XX" />
    </div>

    <div class="form-group">
      <label>Description</label>
      <textarea class="form-control" id="fSrDesc">${data.description || ''}</textarea>
    </div>
  `;

  openModal(
    id ? 'Modifier la sous-région' : 'Nouvelle sous-région',
    html,
    id ? 'Enregistrer' : 'Créer',
    async () => {
      const nom       = document.getElementById('fSrNom').value.trim();
      const region_id = document.getElementById('fSrRegion').value;
      if (!nom)       { showToast('Le nom est requis', 'warning'); return; }
      if (!region_id) { showToast('La région est requise', 'warning'); return; }

      const payload = {
        nom, region_id,
        responsable:       document.getElementById('fSrResp').value.trim(),
        responsable_grade: document.getElementById('fSrGrade').value,
        contact:           document.getElementById('fSrContact').value.trim(),
        description:       document.getElementById('fSrDesc').value.trim()
      };

      try {
        if (id) {
          await API.update('sous_regions', id, payload);
          showToast('Sous-région mise à jour', 'success');
        } else {
          await API.create('sous_regions', { id: generateId('sr'), ...payload });
          showToast('Sous-région créée', 'success');
        }
        closeModal();
        renderSousRegions();
      } catch (err) {
        showToast('Erreur : ' + err.message, 'error');
      }
    }
  );
}

async function deleteSousRegion(id, nom) {
  confirmDelete(nom, async () => {
    try {
      await API.remove('sous_regions', id);
      showToast('Sous-région supprimée', 'success');
      closeModal();
      renderSousRegions();
    } catch (err) {
      showToast('Erreur : ' + err.message, 'error');
    }
  });
}
