/**
 * API Helper — Recensement Paroissial
 * Gestion robuste des erreurs 500, retry automatique, normalisation réponses
 */
const API = {
  BASE: 'tables',
  _retryDelay: 800,   // ms entre deux essais
  _maxRetries: 2,     // nombre de retry max sur erreur 5xx

  /* ── Requête générique avec retry sur erreurs 5xx ────────────── */
  async _req(url, options = {}, attempt = 0) {
    try {
      const res = await fetch(url, options);

      /* 204 No Content (DELETE) → succès sans corps */
      if (res.status === 204) return true;

      /* Parser le corps — toujours via text() puis JSON.parse()
         Le Content-Type peut être absent, text/plain, ou autre */
      let body;
      const text = await res.text().catch(() => '');
      if (!text || !text.trim()) {
        body = {};
      } else {
        try { body = JSON.parse(text); }
        catch { body = { message: text.slice(0, 200) }; }
      }

      /* Retry automatique sur erreur serveur 5xx */
      if (res.status >= 500 && res.status < 600) {
        if (attempt < this._maxRetries) {
          await new Promise(r => setTimeout(r, this._retryDelay * (attempt + 1)));
          return this._req(url, options, attempt + 1);
        }
        const msg = body?.message || body?.error || `Erreur serveur (${res.status})`;
        throw new Error(msg);
      }

      /* Autres erreurs HTTP (4xx, etc.) */
      if (!res.ok) {
        const msg = body?.message || body?.error || `Erreur (${res.status})`;
        throw new Error(msg);
      }

      return body;

    } catch (err) {
      /* Erreur réseau / fetch elle-même */
      if (err.name === 'TypeError' && err.message.toLowerCase().includes('fetch')) {
        if (attempt < this._maxRetries) {
          await new Promise(r => setTimeout(r, this._retryDelay * (attempt + 1)));
          return this._req(url, options, attempt + 1);
        }
        throw new Error('Impossible de joindre le serveur. Vérifiez votre connexion.');
      }
      /* Re-lancer les erreurs déjà formatées */
      throw err;
    }
  },

  /* ── GET tous les enregistrements (avec pagination et recherche) ── */
  async getAll(table, params = {}) {
    const qs = new URLSearchParams({ page: 1, limit: 300, ...params }).toString();
    const data = await this._req(`${this.BASE}/${table}?${qs}`);
    /* Normaliser : toujours { data: [], total: n } */
    if (Array.isArray(data))               return { data, total: data.length };
    if (data && Array.isArray(data.data))  return { data: data.data, total: data.total ?? data.data.length };
    return { data: [], total: 0 };
  },

  /* ── GET un enregistrement par ID ────────────────────────────── */
  async getById(table, id) {
    if (!id) throw new Error(`ID manquant pour la table "${table}"`);
    return await this._req(`${this.BASE}/${table}/${id}`);
  },

  /* ── POST — créer un enregistrement ─────────────────────────── */
  async create(table, payload) {
    /* Nettoyer les champs undefined pour éviter les erreurs 500 */
    const clean = this._cleanPayload(payload);
    return await this._req(`${this.BASE}/${table}`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(clean)
    });
  },

  /* ── PUT — mise à jour complète ──────────────────────────────── */
  async update(table, id, payload) {
    if (!id) throw new Error(`ID manquant pour la mise à jour dans "${table}"`);
    const clean = this._cleanPayload(payload);
    return await this._req(`${this.BASE}/${table}/${id}`, {
      method:  'PUT',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(clean)
    });
  },

  /* ── PATCH — mise à jour partielle ───────────────────────────── */
  async patch(table, id, payload) {
    if (!id) throw new Error(`ID manquant pour le patch dans "${table}"`);
    const clean = this._cleanPayload(payload);
    return await this._req(`${this.BASE}/${table}/${id}`, {
      method:  'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(clean)
    });
  },

  /* ── DELETE ──────────────────────────────────────────────────── */
  async remove(table, id) {
    if (!id) throw new Error(`ID manquant pour la suppression dans "${table}"`);
    await this._req(`${this.BASE}/${table}/${id}`, { method: 'DELETE' });
    return true;
  },

  /* ── Nettoyage payload : retire undefined, convertit null en '' ── */
  _cleanPayload(obj) {
    if (!obj || typeof obj !== 'object') return obj;
    const out = {};
    for (const [k, v] of Object.entries(obj)) {
      if (v === undefined) continue;         // ignorer les undefined
      out[k] = v === null ? '' : v;          // null → chaîne vide
    }
    return out;
  }
};
