/**
 * app.js — Contrôleur principal
 * Registre Mondial des Paroisses ECC
 */

const App = {
  currentPage: 'dashboard',
  addNewHandlers: {},

  /* ── Initialisation ────────────────────────────────────────── */
  init() {
    if (!Auth.isLoggedIn()) {
      showLoginScreen();
      return;
    }
    this.setupUserInfo();
    this.setDate();
    this.setupSidebar();
    this.setupNavigation();
    this.setupGlobalSearch();

    window.addEventListener('offline', () => {
      const b = document.getElementById('offlineBanner');
      if (b) b.style.display = 'flex';
    });
    window.addEventListener('online', () => {
      const b = document.getElementById('offlineBanner');
      if (b) b.style.display = 'none';
    });
    if (!navigator.onLine) {
      const b = document.getElementById('offlineBanner');
      if (b) b.style.display = 'flex';
    }

    if (typeof AutoSave !== 'undefined') AutoSave.init();

    setTimeout(() => {
      if (typeof Notifications !== 'undefined') {
        Notifications.refresh().then(() => {
          const sb  = document.getElementById('sidebarNotifBadge');
          const cnt = Notifications.unreadCount || 0;
          if (sb) { sb.textContent = cnt > 9 ? '9+' : cnt; sb.style.display = cnt > 0 ? '' : 'none'; }
        }).catch(() => {});
      }
    }, 1500);

    /* Onboarding : afficher le guide de démarrage si nécessaire */
    setTimeout(() => {
      if (typeof Onboarding !== 'undefined') Onboarding.checkAndShow();
    }, 2000);

    this.navigate('dashboard');
  },

  /* ── Affichage utilisateur + sidebar ──────────────────────── */
  setupUserInfo() {
    const user = Auth.getCurrentUser();
    if (!user) return;
    const roleInfo = Auth.ROLES[user.role] || Auth.ROLES.lecteur;
    const initials = (user.nom || user.username || '?')
      .split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase();

    const av = document.getElementById('sidebarUserAvatar');
    const nm = document.getElementById('sidebarUserName');
    const rl = document.getElementById('sidebarUserRole');
    if (av) av.textContent = initials;
    if (nm) nm.textContent = user.nom || user.username;
    if (rl) rl.textContent = roleInfo.label;

    this._adaptSidebarToRole(user);
  },

  /**
   * Adapte la sidebar selon le rôle :
   * - super_admin / admin : accès complet (toutes sections)
   * - secretaire / lecteur lié à une église : vue restreinte
   */
  _adaptSidebarToRole(user) {
    const WOLI_ROLES = ['regional_woli','subregional_woli','church_woli'];
    const isAdmin   = user.role === 'super_admin' || user.role === 'admin';
    const isWoli    = WOLI_ROLES.includes(user.role);

    /* ── Helpers show/hide directs (sans chercher *Group) ─────── */
    const $show = id => { const el = document.getElementById(id); if (el) el.style.display = ''; };
    const $hide = id => { const el = document.getElementById(id); if (el) el.style.display = 'none'; };

    /* Masquer TOUT au départ, puis montrer ce qu'il faut */
    const allSections = [
      'navSectionPrincipalGroup','navSectionHierarchieGroup',
      'navSectionEgliseGroup','navSectionMembresGroup',
      'navSectionMessagesGroup','navSectionEvenementsGroup',
      'navSectionImportGroup','navSectionWoliGroup',
      'navSectionAProposGroup','navAdminGroup',
      'navSectionCommuniquesGroup'
    ];
    allSections.forEach($hide);

    if (isAdmin) {
      /* ── ADMIN GLOBAL ──────────────────────────────────────────
         Accès complet : dashboard, hiérarchie, membres, messages,
         activités, outils, administration. Pas les Enfants AJ.
      ── */
      $show('navSectionPrincipalGroup');
      $show('navSectionHierarchieGroup');
      $show('navSectionMembresGroup');
      $show('navSectionMessagesGroup');
      $show('navSectionEvenementsGroup');
      $show('navSectionImportGroup');
      $show('navSectionAProposGroup');
      $show('navAdminGroup');
      /* Communiqués : super_admin → menu dédié ; admin simple → lecteur */
      if (user.role === 'super_admin') {
        $show('navSectionCommuniquesGroup');
        $hide('navItemCommuniquesLecteur');
      } else {
        $hide('navSectionCommuniquesGroup');
        $show('navItemCommuniquesLecteur');
      }

      /* Items visibles */
      $show('navItemStats');
      $show('navItemCarte');
      $show('navItemEglises');
      $show('navItemComitesNat');
      $show('navItemChoristes');
      $show('navItemPromotions');
      $show('navItemFideles');
      $show('navSectionHistorique');
      $show('navSectionCalendrier');
      $show('navItemCotisations');

      /* Items masqués */
      $hide('navItemEnfantsAJ');

      /* Libellé Administration */
      const lbl = document.getElementById('navUsersLabel');
      if (lbl) lbl.textContent = user.role === 'super_admin' ? 'Utilisateurs' : 'Comptes Paroisses';

      const t = document.getElementById('sidebarAppTitle');
      if (t) t.textContent = 'Paroisses ECC';
      const s = document.getElementById('sidebarAppSubtitle');
      if (s) s.textContent = 'Registre Mondial';

    } else if (isWoli) {
      /* ── COMPTE WOLI ──────────────────────────────────────────
         Accès : section Woli dédiée (fidèles woli, hiérarchie), à propos.
      ── */
      $show('navSectionWoliGroup');
      $show('navSectionAProposGroup');
      $show('navItemCommuniquesLecteur');

      /* Items Woli */
      $show('navItemFidelesWoli');
      if (user.role !== 'church_woli') {
        $show('navItemWoliAccounts');
      } else {
        $hide('navItemWoliAccounts');
      }

      const t = document.getElementById('sidebarAppTitle');
      if (t) t.textContent = 'Espace Woli';
      const s = document.getElementById('sidebarAppSubtitle');
      const roleInfo = Auth.ROLES[user.role] || {};
      if (s) s.textContent = roleInfo.label || 'Woli';

    } else {
      /* ── COMPTE ÉGLISE ─────────────────────────────────────────
         Accès : section Église, membres, messages, activités, à propos.
         Pas : hiérarchie, outils, administration, comités.
      ── */
      $show('navSectionEgliseGroup');
      $show('navSectionMembresGroup');
      $show('navItemCommuniquesLecteur');
      $show('navSectionMessagesGroup');
      $show('navSectionEvenementsGroup');
      $show('navSectionAProposGroup');

      /* Items visibles */
      $show('navItemEnfantsAJ');
      $show('navItemChoristes');
      $show('navItemFideles');
      $show('navSectionHistorique');
      $show('navSectionCalendrier');

      /* Items masqués */
      $hide('navItemComitesNat');
      $hide('navItemPromotions');
      $hide('navItemCotisations');
      $hide('navItemStats');
      $hide('navItemCarte');
      $hide('navItemEglises');
      $hide('navItemWoliAccounts');

      const t = document.getElementById('sidebarAppTitle');
      if (t) t.textContent = 'Ma Paroisse';
      const s = document.getElementById('sidebarAppSubtitle');
      if (s) s.textContent = 'Espace Paroissial';
    }
  },

  /* ── Date dans la topbar ───────────────────────────────────── */
  setDate() {
    const now  = new Date();
    const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const el   = document.getElementById('currentDate');
    if (el) el.textContent = now.toLocaleDateString('fr-FR', opts);
  },

  /* ── Toggle sidebar ────────────────────────────────────────── */
  setupSidebar() {
    const sidebar     = document.getElementById('sidebar');
    const mainWrapper = document.getElementById('mainWrapper');
    const toggleBtn   = document.getElementById('sidebarToggle');
    const mobileBtn   = document.getElementById('topbarMenuBtn');

    toggleBtn?.addEventListener('click', () => {
      const collapsed = sidebar.classList.toggle('collapsed');
      mainWrapper.classList.toggle('sidebar-collapsed', collapsed);
      localStorage.setItem('sidebar_collapsed', collapsed);
      /* Mettre à jour aria-expanded sur le bouton toggle */
      toggleBtn.setAttribute('aria-expanded', !collapsed);
    });

    mobileBtn?.addEventListener('click', () => {
      const opened = sidebar.classList.toggle('mobile-open');
      mobileBtn.setAttribute('aria-expanded', opened);
    });

    if (localStorage.getItem('sidebar_collapsed') === 'true') {
      sidebar.classList.add('collapsed');
      mainWrapper.classList.add('sidebar-collapsed');
      toggleBtn?.setAttribute('aria-expanded', 'false');
    }

    document.addEventListener('click', (e) => {
      if (window.innerWidth <= 900 &&
          !sidebar.contains(e.target) &&
          !mobileBtn?.contains(e.target)) {
        sidebar.classList.remove('mobile-open');
        mobileBtn?.setAttribute('aria-expanded', 'false');
      }
    });

    /* ── Accordion sidebar ──────────────────────────────────────
       Chaque bouton .accordion-toggle bascule la section
       en ajoutant/retirant la classe .collapsed sur la <ul> suivante
    ─────────────────────────────────────────────────────────── */
    this._initAccordion();
  },

  _initAccordion() {
    document.querySelectorAll('.accordion-toggle').forEach(btn => {
      btn.addEventListener('click', () => {
        /* Ne rien faire si sidebar réduite */
        if (document.getElementById('sidebar')?.classList.contains('collapsed')) return;

        const targetId = btn.getAttribute('aria-controls');
        const items    = document.getElementById(targetId);
        if (!items) return;

        const isExpanded = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', !isExpanded);
        items.classList.toggle('collapsed', isExpanded);

        /* Sauvegarder l'état dans localStorage */
        const key = 'cc_accordion_' + targetId;
        localStorage.setItem(key, isExpanded ? 'closed' : 'open');
      });

      /* Restaurer l'état sauvegardé */
      const targetId = btn.getAttribute('aria-controls');
      const key      = 'cc_accordion_' + targetId;
      const saved    = localStorage.getItem(key);
      if (saved === 'closed') {
        btn.setAttribute('aria-expanded', 'false');
        const items = document.getElementById(targetId);
        if (items) items.classList.add('collapsed');
      }
    });
  },

  /* ── Navigation par liens ──────────────────────────────────── */
  setupNavigation() {
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = link.dataset.page;
        if (page) this.navigate(page);
        if (window.innerWidth <= 900) {
          document.getElementById('sidebar')?.classList.remove('mobile-open');
        }
      });
    });
  },

  /* ── Navigate vers une page ────────────────────────────────── */
  navigate(page, params = {}) {
    const user = Auth.getCurrentUser();
    if (!user) return;

    const WOLI_ROLES = ['regional_woli','subregional_woli','church_woli'];
    const isAdmin  = user.role === 'super_admin' || user.role === 'admin';
    const isWoli   = WOLI_ROLES.includes(user.role);
    const isEglise = !isAdmin && !isWoli && !!user.eglise_id;

    /* Pages super_admin seulement */
    const superAdminPages = [];
    /* Pages inaccessibles aux comptes église & woli */
    const globalOnly = ['regions', 'sous_regions', 'statistiques', 'carte',
                        'import', 'export', 'cotisations', 'eglises',
                        'comites_nationaux', 'promotions', 'users'];
    /* Pages réservées aux comptes église uniquement */
    const egliseOnly = ['enfants_aj'];
    /* Pages réservées aux Woli */
    const woliOnly   = ['woli_accounts'];
    /* Pages accessibles à tous */
    const openPages  = ['fideles', 'dashboard'];

    if (superAdminPages.includes(page) && !Auth.isSuperAdmin()) {
      showToast('Accès réservé aux super-administrateurs', 'warning');
      return;
    }
    if ((isEglise || isWoli) && globalOnly.includes(page)) {
      showToast('Accès non autorisé pour ce compte', 'warning');
      return;
    }
    if (isAdmin && egliseOnly.includes(page)) {
      showToast('Cette section est réservée aux comptes paroisses', 'warning');
      return;
    }
    if (!isWoli && !isAdmin && woliOnly.includes(page)) {
      showToast('Accès réservé aux comptes Woli', 'warning');
      return;
    }

    this.currentPage = page;

    /* Marquer le lien actif */
    document.querySelectorAll('.nav-link').forEach(l => {
      l.classList.toggle('active', l.dataset.page === page);
    });

    /* Bouton "Ajouter" */
    const addLabels = {
      messages:          'Nouveau message',
      eglises:           'Nouvelle église',
      membres:           'Nouveau membre',
      evenements:        'Nouvel événement',
      cotisations:       'Nouvelle cotisation',
      calendrier:        'Nouvel événement',
      regions:           'Nouvelle région',
      sous_regions:      'Nouvelle sous-région',
      comites_nationaux: 'Nouveau membre',
      enfants_aj:        'Nouvel enfant AJ',
      choristes:         'Nouveau choriste',
      promotions:        'Nouvelle promotion',
      fideles:           'Nouveau fidèle',
    };
    const btnAdd   = document.getElementById('btnAddNew');
    const btnLabel = document.getElementById('btnAddLabel');
    if (addLabels[page] && Auth.canWrite()) {
      if (btnAdd) btnAdd.style.display = '';
      if (btnLabel) btnLabel.textContent = addLabels[page];
    } else {
      if (btnAdd) btnAdd.style.display = 'none';
    }

    /* Loader */
    const content = document.getElementById('pageContent');
    if (content) {
      content.innerHTML = `<div class="loading-spinner">
        <i class="fas fa-circle-notch fa-spin"></i><p>Chargement...</p></div>`;
    }

    setTimeout(() => {
      this._renderPage(page, params, user, isEglise);
      /* Retraduire les éléments data-i18n statiques après navigation */
      if (typeof I18n !== 'undefined') I18n._applyToDOM();
    }, 60);
  },

  _renderPage(page, params, user, isEglise) {
    /* Dashboard : différent selon le rôle */
    const dashFn = isEglise
      ? () => renderDashboardEglise()
      : () => renderDashboard();

    const renderers = {
      dashboard:          dashFn,
      regions:            () => renderRegions(),
      sous_regions:       () => renderSousRegions(params),
      eglises:            () => renderEglises(params),
      membres:            () => renderMembres(params),
      evenements:         () => renderEvenements(params),
      cotisations:        () => renderCotisations(params),
      statistiques:       () => renderStatistiques(),
      calendrier:         () => renderCalendrier(params),
      historique:         () => renderHistorique(params),
      carte:              () => renderCarte(),
      import:             () => renderImport(),
      export:             () => renderExport(),
      notifications:      () => renderNotifications(),
      users:              () => renderUsers(),
      messages:           () => renderMessages(params),
      comites_nationaux:  () => renderComitesNationaux(params),
      enfants_aj:         () => renderEnfantsAJ(params),
      contributeurs:      () => renderContributeurs(),
      choristes:          () => renderChoristes(params),
      promotions:         () => renderPromotions(),
      fideles:            () => renderFideles(params),
      woli_accounts:      () => renderWoliAccounts(),
      communiques:        () => renderCommuniques()
    };

    const fn = renderers[page];
    if (fn) {
      try { fn(); }
      catch (err) {
        console.error('[App] Erreur rendu page', page, err);
        const c = document.getElementById('pageContent');
        if (c) c.innerHTML = `
          <div class="empty-state">
            <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
            <h3>Erreur de chargement</h3>
            <p>${err.message}</p>
            <button class="btn btn-primary" onclick="App.navigate('${page}')">
              <i class="fas fa-redo"></i> Réessayer
            </button>
          </div>`;
      }
    } else {
      const c = document.getElementById('pageContent');
      if (c) c.innerHTML = `
        <div class="empty-state">
          <i class="fas fa-question-circle"></i>
          <h3>Page non trouvée</h3>
          <p>La page "<strong>${page}</strong>" n'existe pas.</p>
        </div>`;
    }
  },

  registerAddHandler(page, fn) {
    this.addNewHandlers[page] = fn;
  }
};

function handleAddNew() {
  const handler = App.addNewHandlers[App.currentPage];
  if (handler) handler();
}

/* ═══════════════════════════════════════════════════════════════
   DASHBOARD ÉGLISE
   ═══════════════════════════════════════════════════════════════ */
async function renderDashboardEglise() {
  setBreadcrumb([{ label: I18n.t('nav.dashboard') }]);
  const content = document.getElementById('pageContent');
  const user = Auth.getCurrentUser();

  try {
    const [egl, mems, evs, msgs] = await Promise.all([
      API.getById('eglises', user.eglise_id),
      API.getAll('membres'),
      API.getAll('evenements'),
      API.getAll('messages', { limit: 300 }).catch(() => ({ data: [] }))
    ]);

    const eglMems = mems.data.filter(m => m.eglise_id === user.eglise_id);
    const eglEvs  = evs.data.filter(e => e.eglise_id === user.eglise_id);

    /* Messages reçus par cette église (direct + broadcast non lus) */
    const eglMsgs = (msgs.data || []).filter(m =>
      (m.eglise_id === user.eglise_id || m.destinataire_id === 'all') &&
      m.direction === 'admin_to_eglise' && !m.message_parent_id
    ).sort((a, b) =>
      (b.date_envoi || b.created_at || 0) > (a.date_envoi || a.created_at || 0) ? 1 : -1
    );
    const msgsNonLus = eglMsgs.filter(m => !m.lu).length;

    const actifs = eglMems.filter(m => m.statut === 'actif').length;
    const hommes = eglMems.filter(m => m.sexe === 'homme').length;
    const femmes = eglMems.filter(m => m.sexe === 'femme').length;

    const now      = new Date();
    const prochains = eglEvs
      .filter(e => e.date_debut && new Date(e.date_debut) >= now)
      .sort((a, b) => new Date(a.date_debut) - new Date(b.date_debut))
      .slice(0, 5);

    /* Mettre à jour le titre sidebar avec le nom de l'église */
    const t = document.getElementById('sidebarAppTitle');
    if (t && egl.nom) t.textContent = egl.nom;

    /* Rafraîchir badge messagerie */
    const msgBadge = document.getElementById('msgNavBadge');
    if (msgBadge) {
      msgBadge.textContent = msgsNonLus > 9 ? '9+' : msgsNonLus;
      msgBadge.style.display = msgsNonLus > 0 ? '' : 'none';
    }

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-church" style="margin-right:10px"></i>${egl.nom}
          </h2>
          <p style="color:var(--text-muted)">${egl.ville || ''} — Tableau de bord</p>
        </div>
      </div>

      ${msgsNonLus > 0 ? `
      <!-- Bannière messages non lus -->
      <div onclick="App.navigate('messages')" style="cursor:pointer;
        background:linear-gradient(135deg,#fef3c7,#fff7ed);
        border:1.5px solid #f59e0b;border-radius:12px;padding:14px 18px;
        margin-bottom:20px;display:flex;align-items:center;gap:14px">
        <div style="width:42px;height:42px;border-radius:10px;flex-shrink:0;
          background:linear-gradient(135deg,#f59e0b,#ef4444);
          display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px">
          <i class="fas fa-envelope"></i>
        </div>
        <div style="flex:1">
          <div style="font-weight:700;font-size:14px;color:#92400e">
            ${msgsNonLus} nouveau${msgsNonLus > 1 ? 'x' : ''} message${msgsNonLus > 1 ? 's' : ''} de l'administration
          </div>
          <div style="font-size:12px;color:#b45309;margin-top:2px">
            Cliquez pour consulter vos messages
          </div>
        </div>
        <i class="fas fa-chevron-right" style="color:#f59e0b;font-size:14px"></i>
      </div>` : ''}

      <!-- Statistiques rapides -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
                  gap:16px;margin-bottom:24px">
        <div class="stat-card primary" style="cursor:pointer" onclick="App.navigate('membres')">
          <div class="stat-icon"><i class="fas fa-users"></i></div>
          <div class="stat-info"><h3>${eglMems.length}</h3><p>Total membres</p></div>
        </div>
        <div class="stat-card success">
          <div class="stat-icon"><i class="fas fa-user-check"></i></div>
          <div class="stat-info"><h3>${actifs}</h3><p>Membres actifs</p></div>
        </div>
        <div class="stat-card gold">
          <div class="stat-icon"><i class="fas fa-mars"></i></div>
          <div class="stat-info"><h3>${hommes}</h3><p>Hommes</p></div>
        </div>
        <div class="stat-card info">
          <div class="stat-icon"><i class="fas fa-venus"></i></div>
          <div class="stat-info"><h3>${femmes}</h3><p>Femmes</p></div>
        </div>
        <div class="stat-card warning" style="cursor:pointer" onclick="App.navigate('evenements')">
          <div class="stat-icon"><i class="fas fa-calendar-alt"></i></div>
          <div class="stat-info"><h3>${eglEvs.length}</h3><p>Événements</p></div>
        </div>
        <div class="stat-card ${msgsNonLus > 0 ? 'danger' : 'info'}" style="cursor:pointer"
          onclick="App.navigate('messages')">
          <div class="stat-icon"><i class="fas fa-envelope"></i></div>
          <div class="stat-info">
            <h3>${msgsNonLus > 0 ? msgsNonLus : eglMsgs.length}</h3>
            <p>${msgsNonLus > 0 ? 'Non lus' : 'Messages'}</p>
          </div>
        </div>
      </div>

      <!-- Accès rapides -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
                  gap:14px;margin-bottom:24px">
        <button class="btn btn-primary"
          style="padding:16px;font-size:13px;border-radius:12px;flex-direction:column"
          onclick="App.navigate('membres');showMembreForm()">
          <i class="fas fa-user-plus" style="font-size:18px;margin-bottom:6px;display:block"></i>
          Inscrire un membre
        </button>
        <button class="btn btn-gold"
          style="padding:16px;font-size:13px;border-radius:12px;flex-direction:column"
          onclick="App.navigate('evenements');showEvenementForm()">
          <i class="fas fa-calendar-plus" style="font-size:18px;margin-bottom:6px;display:block"></i>
          Nouvel événement
        </button>
        <button class="btn btn-outline"
          style="padding:16px;font-size:13px;border-radius:12px;flex-direction:column"
          onclick="App.navigate('messages')">
          <i class="fas fa-envelope" style="font-size:18px;margin-bottom:6px;display:block"></i>
          Messagerie${msgsNonLus > 0
            ? ` <span class="badge badge-danger" style="font-size:10px;margin-left:4px">${msgsNonLus}</span>`
            : ''}
        </button>
        <button class="btn btn-outline"
          style="padding:16px;font-size:13px;border-radius:12px;flex-direction:column"
          onclick="App.navigate('calendrier')">
          <i class="fas fa-calendar-week" style="font-size:18px;margin-bottom:6px;display:block"></i>
          Calendrier
        </button>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;flex-wrap:wrap">

        <!-- Messages récents de l'admin -->
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-envelope" style="color:var(--primary);margin-right:8px"></i>
              Messages Admin
              ${msgsNonLus > 0
                ? `<span class="badge badge-danger" style="font-size:10px;margin-left:6px">${msgsNonLus} non lu${msgsNonLus>1?'s':''}</span>`
                : ''}
            </h3>
            <button class="btn btn-sm btn-outline" onclick="App.navigate('messages')">Voir tout</button>
          </div>
          <div class="card-body" style="padding:0">
            ${eglMsgs.length === 0
              ? '<p class="text-center text-muted" style="padding:20px">Aucun message reçu</p>'
              : eglMsgs.slice(0, 4).map(m => `
                <div onclick="viewMessage('${m.id}')" style="cursor:pointer;
                  padding:12px 16px;border-bottom:1px solid var(--border);
                  background:${!m.lu ? 'rgba(124,58,237,.04)' : ''};
                  transition:background .15s">
                  <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                    <i class="fas fa-${m.destinataire_id==='all'?'broadcast-tower':'envelope'}"
                      style="color:${m.destinataire_id==='all'?'var(--warning)':'var(--primary)'};
                             font-size:12px;flex-shrink:0"></i>
                    <span style="font-weight:${!m.lu?'700':'600'};font-size:13px;
                      color:${!m.lu?'var(--primary)':'var(--text)'};
                      white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px">
                      ${m.sujet || '(Sans objet)'}
                    </span>
                    ${!m.lu ? '<span class="badge badge-primary" style="font-size:9px;margin-left:auto">Nouveau</span>' : ''}
                  </div>
                  <div style="font-size:11px;color:var(--text-muted)">
                    ${m.date_envoi
                      ? new Date(m.date_envoi).toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'})
                      : ''}
                  </div>
                </div>`).join('')}
          </div>
        </div>

        <!-- Prochains événements -->
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-calendar-alt" style="color:var(--warning);margin-right:8px"></i>Prochains événements</h3>
            <button class="btn btn-sm btn-outline" onclick="App.navigate('evenements')">Voir tout</button>
          </div>
          <div class="card-body" style="padding:0">
            ${prochains.length === 0
              ? '<p class="text-center text-muted" style="padding:20px">Aucun événement à venir</p>'
              : prochains.map(ev => `
                <div style="display:flex;align-items:center;gap:12px;
                            padding:12px 16px;border-bottom:1px solid var(--border)">
                  <div style="width:6px;height:36px;border-radius:3px;
                              background:var(--primary);flex-shrink:0"></div>
                  <div style="flex:1;min-width:0">
                    <div style="font-weight:600;font-size:13px;
                      white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${ev.titre}</div>
                    <div style="font-size:11px;color:var(--text-muted)">
                      ${ev.type_evenement || '—'} · ${ev.lieu || ''}
                    </div>
                  </div>
                  <div style="font-size:12px;font-weight:600;color:var(--primary);flex-shrink:0">
                    ${formatDateShort(ev.date_debut)}
                  </div>
                </div>`).join('')}
          </div>
        </div>

        <!-- Derniers membres inscrits -->
        <div class="card" style="grid-column:1/-1">
          <div class="card-header">
            <h3><i class="fas fa-users" style="color:var(--gold);margin-right:8px"></i>Derniers membres inscrits</h3>
            <button class="btn btn-sm btn-outline" onclick="App.navigate('membres')">Voir tout</button>
          </div>
          <div class="card-body" style="padding:0">
            ${eglMems.length === 0
              ? '<p class="text-center text-muted" style="padding:20px">Aucun membre enregistré</p>'
              : [...eglMems]
                  .sort((a, b) => (b.created_at || 0) - (a.created_at || 0))
                  .slice(0, 6)
                  .map(m => `
                <div style="display:flex;align-items:center;gap:12px;
                            padding:10px 16px;border-bottom:1px solid var(--border)">
                  ${memberAvatar(m, 36)}
                  <div style="flex:1">
                    <div style="font-weight:600;font-size:13px">${m.prenom} ${m.nom}</div>
                    <div style="font-size:11px;color:var(--text-muted)">
                      ${m.sexe === 'femme' ? '♀' : '♂'} · ${m.grade || '—'}
                    </div>
                  </div>
                  ${statutBadge(m.statut)}
                </div>`).join('')}
          </div>
        </div>
      </div>
    `;
  } catch (err) {
    content.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
        <h3>Erreur de chargement</h3>
        <p>${err.message}</p>
        <button class="btn btn-primary" onclick="App.navigate('dashboard')">
          <i class="fas fa-redo"></i> Réessayer
        </button>
      </div>`;
  }
}

/* ═══════════════════════════════════════════════════════════════
   RECHERCHE GLOBALE
   ═══════════════════════════════════════════════════════════════ */
App.setupGlobalSearch = function () {
  const input   = document.getElementById('globalSearch');
  const results = document.getElementById('searchResults');
  if (!input || !results) return;

  const user = Auth.getCurrentUser();
  const isEglise = user && !!user.eglise_id &&
                   user.role !== 'super_admin' && user.role !== 'admin';

  const doSearch = debounce(async (q) => {
    if (!q || q.length < 2) { results.classList.remove('active'); return; }
    results.classList.add('active');
    results.innerHTML = `<div style="padding:16px;color:var(--text-muted);font-size:13px">
      <i class="fas fa-spinner fa-spin"></i> Recherche...</div>`;

    try {
      let html = '';
      let count = 0;

      if (isEglise) {
        const [mems, evs] = await Promise.all([
          API.getAll('membres',     { search: q }),
          API.getAll('evenements',  { search: q })
        ]);
        mems.data.filter(m => m.eglise_id === user.eglise_id).forEach(m => {
          if (count++ >= 12) return;
          html += `<div class="search-result-item" onclick="viewMembre('${m.id}');closeSearch()">
            <div class="icon" style="background:var(--gold-light);color:var(--gold)">
              <i class="fas fa-user"></i></div>
            <div class="info"><h4>${m.prenom} ${m.nom}</h4>
              <p>Membre · ${m.grade || ''}</p></div></div>`;
        });
        evs.data.filter(e => e.eglise_id === user.eglise_id).forEach(ev => {
          if (count++ >= 12) return;
          html += `<div class="search-result-item" onclick="App.navigate('evenements');closeSearch()">
            <div class="icon" style="background:var(--warning-light);color:var(--warning)">
              <i class="fas fa-calendar"></i></div>
            <div class="info"><h4>${ev.titre}</h4>
              <p>Événement · ${ev.type_evenement || ''}</p></div></div>`;
        });
      } else {
        const [regs, srs, egls, mems] = await Promise.all([
          API.getAll('regions',      { search: q }),
          API.getAll('sous_regions', { search: q }),
          API.getAll('eglises',      { search: q }),
          API.getAll('membres',      { search: q })
        ]);
        regs.data.forEach(r => {
          if (count++ >= 12) return;
          html += `<div class="search-result-item" onclick="App.navigate('regions');closeSearch()">
            <div class="icon"><i class="fas fa-globe-africa"></i></div>
            <div class="info"><h4>${r.nom}</h4><p>Région</p></div></div>`;
        });
        srs.data.forEach(sr => {
          if (count++ >= 12) return;
          html += `<div class="search-result-item" onclick="App.navigate('sous_regions');closeSearch()">
            <div class="icon" style="background:var(--success-light);color:var(--success)">
              <i class="fas fa-map-marked-alt"></i></div>
            <div class="info"><h4>${sr.nom}</h4><p>Sous-région</p></div></div>`;
        });
        egls.data.forEach(e => {
          if (count++ >= 12) return;
          html += `<div class="search-result-item" onclick="viewEglise('${e.id}');closeSearch()">
            <div class="icon" style="background:var(--accent);color:var(--primary)">
              <i class="fas fa-church"></i></div>
            <div class="info"><h4>${e.nom}</h4><p>Église · ${e.ville || ''}</p></div></div>`;
        });
        mems.data.forEach(m => {
          if (count++ >= 12) return;
          html += `<div class="search-result-item" onclick="viewMembre('${m.id}');closeSearch()">
            <div class="icon" style="background:var(--gold-light);color:var(--gold)">
              <i class="fas fa-user"></i></div>
            <div class="info"><h4>${m.prenom} ${m.nom}</h4>
              <p>Membre · ${m.grade || ''}</p></div></div>`;
        });
      }

      if (!html) html = `<div class="search-no-result">
        <i class="fas fa-search" style="font-size:30px;opacity:.3;display:block;margin-bottom:8px"></i>
        Aucun résultat pour "<strong>${q}</strong>"</div>`;

      results.innerHTML = html;
    } catch {
      results.innerHTML = '<div class="search-no-result">Erreur lors de la recherche</div>';
    }
  }, 350);

  input.addEventListener('input',  e => doSearch(e.target.value.trim()));
  input.addEventListener('focus',  e => { if (e.target.value.length >= 2) results.classList.add('active'); });
  document.addEventListener('click', e => {
    if (!results.contains(e.target) && e.target !== input) closeSearch();
  });
};

function closeSearch() {
  document.getElementById('searchResults')?.classList.remove('active');
  const gi = document.getElementById('globalSearch');
  if (gi) gi.value = '';
}

function updateNotifBadge(count) {
  const badge = document.getElementById('notifBadge');
  const sb    = document.getElementById('sidebarNotifBadge');
  if (badge) {
    badge.textContent = count > 9 ? '9+' : count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  }
  if (sb) {
    sb.textContent = count > 9 ? '9+' : count;
    sb.style.display = count > 0 ? '' : 'none';
  }
}

/* ═══════════════════════════════════════════════════════════════
   MODE SOMBRE / CLAIR
   ═══════════════════════════════════════════════════════════════ */
function toggleDarkMode() {
  const isDark = document.body.classList.toggle('dark-mode');
  localStorage.setItem('dark_mode', isDark ? '1' : '0');
  _updateDarkModeIcon(isDark);
}

function _updateDarkModeIcon(isDark) {
  const icon = document.getElementById('darkModeIcon');
  const btn  = document.getElementById('darkModeBtn');
  if (icon) {
    icon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
  }
  if (btn) {
    btn.title = isDark ? 'Passer en mode clair' : 'Passer en mode sombre';
  }
}

/* Appliquer le mode sauvegardé au démarrage */
(function _applyStoredDarkMode() {
  if (localStorage.getItem('dark_mode') === '1') {
    document.body.classList.add('dark-mode');
    /* L'icône sera mise à jour après le chargement du DOM */
    document.addEventListener('DOMContentLoaded', () => _updateDarkModeIcon(true));
  }
})();

/* ── Démarrage ─────────────────────────────────────────────── */
window.addEventListener('load', () => {
  _updateDarkModeIcon(document.body.classList.contains('dark-mode'));
  /* Initialiser i18n AVANT App.init() pour que les data-i18n soient traduits */
  if (typeof I18n !== 'undefined') I18n.init();
  App.init();
});
