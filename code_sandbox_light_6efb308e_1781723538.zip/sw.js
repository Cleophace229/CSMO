/**
 * Service Worker — Paroisses PWA
 * Cache stratégique pour fonctionnement offline
 */
const CACHE_NAME = 'paroisses-v1';
const STATIC_ASSETS = [
  './',
  './index.html',
  './css/style.css',
  './js/api.js',
  './js/utils.js',
  './js/auth.js',
  './js/app.js',
  './js/notifications.js',
  './js/pages/dashboard.js',
  './js/pages/regions.js',
  './js/pages/sous_regions.js',
  './js/pages/eglises.js',
  './js/pages/membres.js',
  './js/pages/evenements.js',
  './js/pages/cotisations.js',
  './js/pages/statistiques.js',
  './js/pages/calendrier.js',
  './js/pages/historique.js',
  './js/pages/carte.js',
  './js/pages/import_export.js'
];

// Installation : mise en cache des ressources statiques
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('[SW] Mise en cache des ressources statiques');
      return cache.addAll(STATIC_ASSETS);
    }).then(() => self.skipWaiting())
  );
});

// Activation : nettoyage des anciens caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch : stratégie Network First pour l'API, Cache First pour les statiques
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // API calls : Network first, fallback cache
  if (url.pathname.startsWith('/tables/') || url.pathname.includes('tables/')) {
    event.respondWith(
      fetch(event.request).catch(() =>
        caches.match(event.request).then(r => r || new Response('{"error":"Offline"}', {
          headers: { 'Content-Type': 'application/json' }
        }))
      )
    );
    return;
  }

  // CDN resources : Cache first
  if (url.hostname !== location.hostname) {
    event.respondWith(
      caches.match(event.request).then(cached => {
        if (cached) return cached;
        return fetch(event.request).then(response => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          }
          return response;
        }).catch(() => cached || new Response('Offline', { status: 503 }));
      })
    );
    return;
  }

  // Ressources locales : Cache first, fallback network
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      });
    })
  );
});

// Message pour forcer la mise à jour
self.addEventListener('message', event => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});
