/**
 * woli_accounts.js — Gestion des comptes Woli (hiérarchie)
 * Fetch 100% robustes : vérification resp.ok + content-type avant .json()
 *
 * Hiérarchie de création :
 *   super_admin / admin  → regional_woli
 *   regional_woli        → subregional_woli (sa région)
 *   subregional_woli     → church_woli (sa sous-région)
 *   church_woli          → aucune création
 */

/* ─── Helper fetch robuste ────────────────────────────────── */
/* Lit comme texte puis JSON.parse() — insensible au Content-Type manquant */
async function _woliApiFetch(url) {
  const r = await fetch(url);
  const txt = await r.text().catch(() => '');
  if (!r.ok) {
    throw new Error(`Erreur API ${r.status}${txt ? ' : ' + txt.slice(0, 100) : ''}`);
  }
  if (!txt || !txt.trim()) return {};
  try {
    return JSON.parse(txt);
  } catch {
    throw new Error(`Réponse invalide du serveur (URL: ${url})`);
  }
}

async function _woliApiPost(url, body) {
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const txt = await r.text().catch(() => '');
  if (!r.ok) {
    throw new Error(`Erreur création ${r.status}${txt ? ' : ' + txt.slice(0, 100) : ''}`);
  }
  if (!txt || !txt.trim()) return {};
  try { return JSON.parse(txt); } catch { return {}; }
}

async function _woliApiPut(url, body) {
  const r = await fetch(url, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const txt = await r.text().catch(() => '');
  if (!r.ok) {
    throw new Error(`Erreur mise à jour ${r.status}${txt ? ' : ' + txt.slice(0, 100) : ''}`);
  }
  if (!txt || !txt.trim()) return {};
  try { return JSON.parse(txt); } catch { return {}; }
}

async function _woliApiDelete(url) {
  const r = await fetch(url, { method: 'DELETE' });
  if (!r.ok && r.status !== 204) {
    throw new Error(`Erreur suppression (${r.status})`);
  }
  return true;
}

/* ════════════════════════════════════════════════════════════
   RENDER PRINCIPAL
════════════════════════════════════════════════════════════ */
async function renderWoliAccounts() {
  const user = Auth.getCurrentUser();
  const isSA = user?.role === 'super_admin' || user?.role === 'admin';
  const isRW = user?.role === 'regional_woli';
  const isSW = user?.role === 'subregional_woli';
  const isCW = user?.role === 'church_woli';

  setBreadcrumb([{ label: 'Hiérarchie Woli' }]);
  const content = document.getElementById('pageContent');

  if (isCW) {
    content.innerHTML = `<div class="empty-state">
      <i class="fas fa-lock"></i>
      <h3>Accès non autorisé</h3>
      <p>Le Woli Paroissial ne peut pas gérer d'autres comptes.</p>
    </div>`;
    return;
  }

  content.innerHTML = `<div class="loading-spinner">
    <i class="fas fa-circle-notch fa-spin"></i><p>Chargement…</p></div>`;

  try {
    const [usersJson, regsJson, srsJson, eglsJson] = await Promise.all([
      _woliApiFetch('tables/utilisateurs?limit=500'),
      _woliApiFetch('tables/regions?limit=200'),
      _woliApiFetch('tables/sous_regions?limit=200'),
      _woliApiFetch('tables/eglises?limit=300')
    ]);

    const allUsers = usersJson.data || [];
    const regs     = regsJson.data  || [];
    const srs      = srsJson.data   || [];
    const egls     = eglsJson.data  || [];

    /* Filtrer les comptes Woli selon la hiérarchie */
    let woliAccounts = allUsers.filter(u =>
      ['regional_woli','subregional_woli','church_woli'].includes(u.role)
    );

    if (isRW) {
      const myRegId = user.region_id;
      const mySrsIds = srs.filter(s => s.region_id === myRegId).map(s => s.id);
      const myEglIds = egls.filter(e =>
        e.region_id === myRegId || mySrsIds.includes(e.sous_region_id)
      ).map(e => e.id);
      woliAccounts = woliAccounts.filter(u =>
        u.region_id === myRegId ||
        mySrsIds.includes(u.sous_region_id) ||
        myEglIds.includes(u.eglise_id)
      );
    } else if (isSW) {
      const mySrId   = user.sous_region_id;
      const myEglIds = egls.filter(e => e.sous_region_id === mySrId).map(e => e.id);
      woliAccounts = woliAccounts.filter(u =>
        u.sous_region_id === mySrId || myEglIds.includes(u.eglise_id)
      );
    }

    const canCreate       = isSA || isRW || isSW;
    const createRoleTarget = isSA ? 'regional_woli' : isRW ? 'subregional_woli' : 'church_woli';
    const createLabel = {
      regional_woli:    '+ Woli Régional',
      subregional_woli: '+ Woli Sous-Régional',
      church_woli:      '+ Woli Paroissial'
    }[createRoleTarget];

    const groups = [
      { role:'regional_woli',    label:'Woli Régionaux',      icon:'fa-globe-africa',   color:'#784212' },
      { role:'subregional_woli', label:'Woli Sous-Régionaux', icon:'fa-map-marked-alt', color:'#6E2F1A' },
      { role:'church_woli',      label:'Woli Paroissiaux',    icon:'fa-hands-praying',  color:'#922B21' }
    ];

    const groupsHTML = groups.map(g => {
      const members = woliAccounts.filter(u => u.role === g.role);
      if (!members.length) return '';
      return `
        <div class="card" style="margin-bottom:20px">
          <div class="card-header" style="background:${g.color}18;border-left:4px solid ${g.color}">
            <h3 style="color:${g.color}">
              <i class="fas ${g.icon}" style="margin-right:8px"></i>
              ${g.label}
              <span class="badge" style="background:${g.color}22;color:${g.color};margin-left:8px">${members.length}</span>
            </h3>
          </div>
          <div class="table-wrapper">
            <table>
              <thead><tr>
                <th>Nom / Identifiant</th>
                <th>Périmètre</th>
                <th>Créé par</th>
                <th>Statut</th>
                <th>Actions</th>
              </tr></thead>
              <tbody>
                ${members.map(u => _woliRow(u, regs, srs, egls, allUsers, user)).join('')}
              </tbody>
            </table>
          </div>
        </div>`;
    }).join('');

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-eye" style="margin-right:10px;color:#922B21"></i>Hiérarchie Woli
          </h2>
          <p style="color:var(--text-muted);margin:4px 0 0">${woliAccounts.length} compte(s) dans votre périmètre</p>
        </div>
        <div class="page-header-actions">
          ${canCreate ? `
            <button class="btn" onclick="showWoliForm('${createRoleTarget}')"
              style="background:linear-gradient(135deg,#922B21,#CB4335);color:#fff">
              <i class="fas fa-user-plus"></i> ${createLabel}
            </button>` : ''}
        </div>
      </div>

      <div style="background:linear-gradient(135deg,#fff5f5,#fef2f2);border:1px solid #fca5a5;
        border-radius:12px;padding:14px 18px;margin-bottom:20px;font-size:13px;color:#7f1d1d;
        display:flex;align-items:flex-start;gap:12px">
        <i class="fas fa-info-circle" style="font-size:18px;flex-shrink:0;color:#ef4444"></i>
        <div>
          <strong>Hiérarchie Woli :</strong>
          <span style="margin-left:6px">
            <span style="background:#784212;color:#fff;border-radius:4px;padding:2px 8px;font-size:11px">Saint-Siège</span>
            → <span style="background:#784212;color:#fff;border-radius:4px;padding:2px 8px;font-size:11px">Woli Régional</span>
            → <span style="background:#6E2F1A;color:#fff;border-radius:4px;padding:2px 8px;font-size:11px">Woli Sous-Régional</span>
            → <span style="background:#922B21;color:#fff;border-radius:4px;padding:2px 8px;font-size:11px">Woli Paroissial</span>
          </span>
          <div style="font-size:11px;opacity:.8;margin-top:5px">
            Chaque niveau crée et gère les comptes du niveau directement inférieur dans son périmètre.</div>
        </div>
      </div>

      ${groupsHTML || `
        <div class="empty-state">
          <i class="fas fa-eye" style="color:var(--text-muted)"></i>
          <h3>Aucun compte Woli</h3>
          <p>Créez le premier compte Woli pour votre périmètre.</p>
        </div>`}`;

  } catch (err) {
    console.error('[WoliAccounts] Erreur:', err);
    content.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
        <h3>Erreur de chargement</h3>
        <p style="color:var(--text-muted);max-width:400px">${err.message}</p>
        <button class="btn btn-primary" onclick="renderWoliAccounts()">
          <i class="fas fa-redo"></i> Réessayer
        </button>
      </div>`;
  }
}

/* ─── Ligne de tableau ─────────────────────────────────────── */
function _woliRow(u, regs, srs, egls, allUsers, me) {
  const act    = u.actif !== false && u.actif !== 'false';
  const parent = allUsers.find(x => x.id === u.parent_id);
  const ri     = Auth.ROLES[u.role] || {};

  let perimetre = '—';
  if      (u.role === 'regional_woli'    && u.region_id)      perimetre = regs.find(r => r.id === u.region_id)?.nom      || u.region_id;
  else if (u.role === 'subregional_woli' && u.sous_region_id) perimetre = srs.find(s => s.id === u.sous_region_id)?.nom   || u.sous_region_id;
  else if (u.role === 'church_woli'      && u.eglise_id)      perimetre = egls.find(e => e.id === u.eglise_id)?.nom       || u.eglise_id;

  const canEdit = me.role === 'super_admin' || me.role === 'admin' || u.parent_id === me.id;
  const safeId  = (u.id  || '').replace(/'/g, "\\'");
  const safeName = (u.nom || u.username || '').replace(/'/g, "\\'");

  return `<tr>
    <td>
      <div style="display:flex;align-items:center;gap:10px">
        <div style="width:36px;height:36px;border-radius:50%;flex-shrink:0;
          background:${ri.color||'#666'}22;display:flex;align-items:center;justify-content:center">
          <i class="fas ${ri.icon||'fa-user'}" style="color:${ri.color||'#666'}"></i>
        </div>
        <div>
          <div style="font-weight:600">${u.nom || u.username || '—'}</div>
          <code style="font-size:11px;background:var(--accent);padding:1px 6px;border-radius:4px">${u.username||'—'}</code>
        </div>
      </div>
    </td>
    <td><span style="font-size:13px">
      <i class="fas fa-map-pin" style="color:var(--primary);margin-right:4px"></i>${perimetre}
    </span></td>
    <td style="font-size:12px;color:var(--text-muted)">${parent ? (parent.nom || parent.username) : '—'}</td>
    <td>${act
      ? '<span class="badge badge-success"><i class="fas fa-circle" style="font-size:7px"></i> Actif</span>'
      : '<span class="badge badge-secondary">Désactivé</span>'}</td>
    <td><div class="td-actions">
      ${canEdit ? `
        <button class="btn btn-xs btn-outline" onclick="showWoliForm(null,'${safeId}')" title="Modifier">
          <i class="fas fa-edit"></i></button>
        <button class="btn btn-xs btn-warning" onclick="showWoliChangePass('${safeId}','${safeName}')" title="Mot de passe">
          <i class="fas fa-key"></i></button>
        <button class="btn btn-xs ${act ? 'btn-secondary' : 'btn-success'}"
          onclick="toggleWoliActif('${safeId}',${act})" title="${act ? 'Désactiver' : 'Activer'}">
          <i class="fas ${act ? 'fa-ban' : 'fa-check'}"></i></button>
        <button class="btn btn-xs btn-danger" onclick="deleteWoliAccount('${safeId}','${safeName}')">
          <i class="fas fa-trash"></i></button>
      ` : '<span style="font-size:11px;color:var(--text-muted)">Lecture seule</span>'}
    </div></td>
  </tr>`;
}

/* ════════════════════════════════════════════════════════════
   FORMULAIRE CRÉATION / MODIFICATION
════════════════════════════════════════════════════════════ */
async function showWoliForm(roleTarget = null, editId = null) {
  const me   = Auth.getCurrentUser();
  const isSA = me.role === 'super_admin' || me.role === 'admin';
  const isRW = me.role === 'regional_woli';
  const isSW = me.role === 'subregional_woli';

  let data = {};

  try {
    const [usersJson, regsJson, srsJson, eglsJson] = await Promise.all([
      editId ? _woliApiFetch('tables/utilisateurs?limit=500') : Promise.resolve({ data: [] }),
      _woliApiFetch('tables/regions?limit=200'),
      _woliApiFetch('tables/sous_regions?limit=200'),
      _woliApiFetch('tables/eglises?limit=300')
    ]);

    const allUsers = usersJson.data || [];
    const regs     = regsJson.data  || [];
    const srs      = srsJson.data   || [];
    const egls     = eglsJson.data  || [];

    if (editId) {
      data = allUsers.find(u => u.id === editId) || {};
      roleTarget = roleTarget || data.role;
    }

    /* Sélecteur de périmètre selon rôle cible */
    let perimetreHTML = '';
    if (roleTarget === 'regional_woli') {
      perimetreHTML = `
        <div class="form-group">
          <label>Région assignée <span style="color:var(--danger)">*</span></label>
          <select class="form-control" id="wfRegion">
            <option value="">— Choisir une région —</option>
            ${regs.map(r => `<option value="${r.id}" ${data.region_id===r.id?'selected':''}>${r.nom}</option>`).join('')}
          </select>
        </div>`;
    } else if (roleTarget === 'subregional_woli') {
      const filteredSrs = isRW ? srs.filter(s => s.region_id === me.region_id) : srs;
      perimetreHTML = `
        <div class="form-group">
          <label>Sous-région assignée <span style="color:var(--danger)">*</span></label>
          <select class="form-control" id="wfSr">
            <option value="">— Choisir une sous-région —</option>
            ${filteredSrs.map(s => `<option value="${s.id}" ${data.sous_region_id===s.id?'selected':''}>${s.nom}</option>`).join('')}
          </select>
        </div>`;
    } else if (roleTarget === 'church_woli') {
      const filteredEgls = isSW ? egls.filter(e => e.sous_region_id === me.sous_region_id) : egls;
      perimetreHTML = `
        <div class="form-group">
          <label>Église assignée <span style="color:var(--danger)">*</span></label>
          <select class="form-control" id="wfEglise">
            <option value="">— Choisir une église —</option>
            ${filteredEgls.map(e => `<option value="${e.id}" ${data.eglise_id===e.id?'selected':''}>${e.nom}</option>`).join('')}
          </select>
        </div>`;
    }

    const roleInfo = Auth.ROLES[roleTarget] || {};
    const pwd = _genWoliPwd();

    openModal(editId ? 'Modifier le compte Woli' : `Nouveau — ${roleInfo.label || roleTarget}`, `
      <div style="background:${roleInfo.color||'#922B21'}12;border:1px solid ${roleInfo.color||'#922B21'}30;
        border-radius:10px;padding:10px 16px;margin-bottom:18px;font-size:13px;color:${roleInfo.color||'#922B21'}">
        <i class="fas ${roleInfo.icon||'fa-eye'}" style="margin-right:8px"></i>
        <strong>${roleInfo.label || roleTarget}</strong>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Nom complet <span style="color:var(--danger)">*</span></label>
          <input class="form-control" id="wfNom" value="${data.nom||''}" placeholder="Prénom Nom" />
        </div>
        <div class="form-group">
          <label>Identifiant <span style="color:var(--danger)">*</span></label>
          <input class="form-control" id="wfUsername" value="${data.username||''}" placeholder="ex: woli.region1"
            ${editId ? 'readonly style="background:var(--accent);cursor:not-allowed"' : ''} />
        </div>
      </div>
      ${!editId ? `
      <div class="form-group">
        <label>Mot de passe initial <span style="color:var(--danger)">*</span></label>
        <div style="display:flex;gap:8px">
          <input class="form-control" id="wfPass" value="${pwd}"
            style="flex:1;font-family:monospace;font-weight:700;font-size:14px;letter-spacing:1px" />
          <button type="button" class="btn btn-outline" title="Générer"
            onclick="document.getElementById('wfPass').value=_genWoliPwd()">
            <i class="fas fa-sync-alt"></i></button>
        </div>
        <p style="font-size:11px;color:var(--warning);margin-top:4px">
          <i class="fas fa-exclamation-circle"></i> Transmettez ces identifiants de façon sécurisée.</p>
      </div>` : ''}
      <div class="form-group">
        <label>Email</label>
        <input class="form-control" id="wfEmail" type="email" value="${data.email||''}" placeholder="email@exemple.com" />
      </div>
      ${perimetreHTML}
      <div class="form-group">
        <label>Notes</label>
        <input class="form-control" id="wfNotes" value="${data.notes||''}" placeholder="Remarques…" />
      </div>
    `, editId ? 'Enregistrer' : 'Créer le compte', async () => {
      const nom      = (document.getElementById('wfNom')?.value     || '').trim();
      const username = (document.getElementById('wfUsername')?.value || '').trim();
      const pass     = document.getElementById('wfPass')?.value      || '';
      const email    = document.getElementById('wfEmail')?.value     || '';
      const notes    = document.getElementById('wfNotes')?.value     || '';

      if (!nom)               { showToast('Le nom est obligatoire.', 'error');        return; }
      if (!username)          { showToast("L'identifiant est obligatoire.", 'error'); return; }
      if (!editId && !pass)   { showToast('Le mot de passe est obligatoire.', 'error'); return; }

      let region_id      = data.region_id      || '';
      let sous_region_id = data.sous_region_id || '';
      let eglise_id      = data.eglise_id      || '';

      if (roleTarget === 'regional_woli')    region_id      = document.getElementById('wfRegion')?.value  || '';
      if (roleTarget === 'subregional_woli') sous_region_id = document.getElementById('wfSr')?.value      || '';
      if (roleTarget === 'church_woli')      eglise_id      = document.getElementById('wfEglise')?.value  || '';

      if (roleTarget === 'regional_woli'    && !region_id)      { showToast('Assignez une région.', 'error');       return; }
      if (roleTarget === 'subregional_woli' && !sous_region_id) { showToast('Assignez une sous-région.', 'error');  return; }
      if (roleTarget === 'church_woli'      && !eglise_id)      { showToast("Assignez une église.", 'error');        return; }

      const body = { nom, email, notes, role: roleTarget, region_id, sous_region_id, eglise_id, parent_id: me.id, actif: true };

      try {
        if (editId) {
          const full = await _woliApiFetch(`tables/utilisateurs/${editId}`);
          await _woliApiPut(`tables/utilisateurs/${editId}`, { ...full, ...body });
          showToast('Compte Woli modifié avec succès.', 'success');
        } else {
          /* Vérifier unicité username */
          const existJson = await _woliApiFetch('tables/utilisateurs?limit=500');
          if ((existJson.data || []).find(u => u.username === username)) {
            showToast("Identifiant déjà utilisé. Choisissez-en un autre.", 'error'); return;
          }
          body.id = 'w_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
          body.username      = username;
          body.password_hash = pass;
          await _woliApiPost('tables/utilisateurs', body);
          showToast(`✅ Compte créé ! Identifiant : ${username} | Mot de passe : ${pass}`, 'success');
        }
        closeModal();
        renderWoliAccounts();
      } catch (err) {
        showToast('Erreur : ' + err.message, 'error');
      }
    });

  } catch (err) {
    showToast('Impossible de charger les données : ' + err.message, 'error');
  }
}

/* ─── Changer le mot de passe ──────────────────────────────── */
function showWoliChangePass(id, nom) {
  openModal(`Changer le mot de passe — ${nom}`, `
    <div class="form-group">
      <label>Nouveau mot de passe <span style="color:var(--danger)">*</span></label>
      <div style="display:flex;gap:8px">
        <input class="form-control" id="wcpPass" value="${_genWoliPwd()}"
          style="flex:1;font-family:monospace;font-weight:700;font-size:14px;letter-spacing:1px" />
        <button type="button" class="btn btn-outline" title="Générer"
          onclick="document.getElementById('wcpPass').value=_genWoliPwd()">
          <i class="fas fa-sync-alt"></i></button>
      </div>
      <p style="font-size:11px;color:var(--warning);margin-top:4px">
        <i class="fas fa-exclamation-circle"></i> Transmettez le nouveau mot de passe de façon sécurisée.</p>
    </div>
  `, 'Enregistrer', async () => {
    const newPass = (document.getElementById('wcpPass')?.value || '').trim();
    if (!newPass) { showToast('Entrez un nouveau mot de passe.', 'error'); return; }
    const result = await Auth.updateUser(id, { password_hash: newPass });
    if (result.success) {
      showToast(`✅ Mot de passe changé : ${newPass}`, 'success');
      closeModal();
    } else {
      showToast('Erreur : ' + result.message, 'error');
    }
  });
}

/* ─── Toggle actif / inactif ───────────────────────────────── */
async function toggleWoliActif(id, currentlyActif) {
  const result = await Auth.updateUser(id, { actif: !currentlyActif });
  if (result.success) {
    showToast(currentlyActif ? 'Compte désactivé.' : 'Compte réactivé.', 'success');
    renderWoliAccounts();
  } else {
    showToast('Erreur : ' + result.message, 'error');
  }
}

/* ─── Suppression ──────────────────────────────────────────── */
async function deleteWoliAccount(id, nom) {
  if (!confirm(`Supprimer le compte Woli "${nom}" ?\nCette action est irréversible.`)) return;
  try {
    await _woliApiDelete(`tables/utilisateurs/${id}`);
    showToast('Compte supprimé avec succès.', 'success');
    renderWoliAccounts();
  } catch (err) {
    showToast('Erreur suppression : ' + err.message, 'error');
  }
}

/* ─── Générateur de mot de passe sécurisé ─────────────────── */
function _genWoliPwd() {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789@#!';
  let pwd = '';
  for (let i = 0; i < 10; i++) pwd += chars[Math.floor(Math.random() * chars.length)];
  return pwd;
}
