/**
 * choristes.js — Gestion des Choristes par Paroisse
 *
 * RÈGLES D'ACCÈS :
 *  - Compte église : voit UNIQUEMENT ses propres choristes, peut AJOUTER / MODIFIER / SUPPRIMER
 *  - Admin / Super-admin : voit TOUS les choristes de toutes les paroisses (lecture + écriture)
 *
 * Table : choristes
 * Colonnes : id, nom, prenom, sexe, grade, voix, telephone, email,
 *            eglise_id, date_adhesion, statut, notes
 */

App.registerAddHandler('choristes', () => showChoristeForm());

let _chorEgliseId = '';   // église du compte connecté (vide si admin)
let _chorData     = [];   // liste courante affichée
let _chorEglises  = [];   // toutes les églises (pour admin)

/* ══════════════════════════════════════════════════════════════════
   RENDU PRINCIPAL
══════════════════════════════════════════════════════════════════ */
async function renderChoristes(params = {}) {
  setBreadcrumb([{ label: I18n.t('choristes.title') }]);
  const content = document.getElementById('pageContent');
  const user    = Auth.getCurrentUser();

  const isAdmin  = user && (user.role === 'super_admin' || user.role === 'admin');
  const isEglise = user && user.eglise_id && !isAdmin;
  _chorEgliseId  = isEglise ? user.eglise_id : '';

  content.innerHTML = `<div class="loading-spinner">
    <i class="fas fa-circle-notch fa-spin"></i><p>Chargement...</p></div>`;

  try {
    const [chorRes, eglRes] = await Promise.all([
      API.getAll('choristes', { limit: 500 }),
      API.getAll('eglises',   { limit: 300 })
    ]);

    _chorEglises = eglRes.data || [];

    /* Filtrage selon le rôle */
    let raw = chorRes.data || [];
    if (isEglise) {
      raw = raw.filter(c => c.eglise_id === _chorEgliseId);
    } else if (params.eglise_id) {
      raw = raw.filter(c => c.eglise_id === params.eglise_id);
    }
    _chorData = raw;

    /* Nom de l'église courante */
    let titreParoisse = '';
    if (isEglise) {
      const egl = _chorEglises.find(e => e.id === _chorEgliseId);
      titreParoisse = egl ? egl.nom : '';
    }

    /* Filtre église (admin) */
    const eglFilterHTML = isAdmin ? `
      <select class="form-control" id="chorEglFilter" style="width:200px" onchange="filterChoristes()">
        <option value="">Toutes les paroisses</option>
        ${_chorEglises.map(e =>
          `<option value="${e.id}" ${params.eglise_id === e.id ? 'selected' : ''}>${e.nom}</option>`
        ).join('')}
      </select>` : '';

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-music" style="margin-right:10px"></i>${I18n.t('choristes.title')}
          </h2>
          <p style="color:var(--text-muted)">
            ${isEglise && titreParoisse
              ? `${I18n.lang==='en'?'Parish':'Paroisse'} : <strong>${titreParoisse}</strong> · ${_chorData.length} ${I18n.lang==='en'?'choir member(s)':'choriste(s)'}`
              : `${_chorData.length} ${I18n.lang==='en'?'choir member(s) total':'choriste(s) au total'}`}
          </p>
        </div>
        <div class="page-header-actions">
          ${Auth.canWrite() ? `
          <button class="btn btn-primary" onclick="showChoristeForm()">
            <i class="fas fa-plus"></i> ${I18n.t('choristes.new')}
          </button>` : ''}
          <button class="btn btn-outline" onclick="imprimerChoristesPDF()"
            title="Exporter la liste en PDF">
            <i class="fas fa-file-pdf" style="color:#E74C3C"></i> PDF
          </button>
        </div>
      </div>

      <!-- Bannière -->
      <div style="background:linear-gradient(135deg,#1a1a2e,#16213e,#0f3460);
        border-radius:16px;padding:20px 24px;margin-bottom:24px;color:#fff;
        display:flex;align-items:center;gap:16px">
        <div style="font-size:44px;flex-shrink:0">🎵</div>
        <div style="flex:1">
          <div style="font-weight:800;font-size:17px;letter-spacing:.3px">
            Chorale Paroissiale
          </div>
          <div style="font-size:12px;opacity:.88;margin-top:4px">
            Gestion des choristes · Communauté Céleste
          </div>
          <div style="display:flex;gap:10px;margin-top:12px;flex-wrap:wrap">
            ${_buildChoristeStats(_chorData)}
          </div>
        </div>
      </div>

      <!-- Recherche & filtres -->
      <div class="page-search" style="margin-bottom:18px;flex-wrap:wrap;gap:8px">
        <div class="search-input-wrapper" style="flex:1;min-width:200px">
          <i class="fas fa-search"></i>
          <input type="text" id="chorSearch" placeholder="Rechercher un choriste..."
            oninput="filterChoristes()" />
        </div>
        ${eglFilterHTML}
        <select class="form-control" id="chorVoixFilter" style="width:150px" onchange="filterChoristes()">
          <option value="">Toutes les voix</option>
          <option value="Soprano">Soprano</option>
          <option value="Mezzo-soprano">Mezzo-soprano</option>
          <option value="Contralto">Contralto</option>
          <option value="Ténor">Ténor</option>
          <option value="Baryton">Baryton</option>
          <option value="Basse">Basse</option>
          <option value="Autre">Autre</option>
        </select>
        <select class="form-control" id="chorStatutFilter" style="width:140px" onchange="filterChoristes()">
          <option value="">Tous les statuts</option>
          <option value="actif">Actifs</option>
          <option value="inactif">Inactifs</option>
        </select>
      </div>

      <!-- Tableau -->
      <div id="chorTable">
        ${_renderChorTable(_chorData, isAdmin)}
      </div>

      <!-- Données cachées -->
      <div id="chorDataStore"
        data-is-admin="${isAdmin}"
        data-eglise-id="${_chorEgliseId}"
        style="display:none"></div>
    `;

    /* Stocker pour filtrage */
    window._chorAllData = _chorData;

    if (!isAdmin && params.eglise_id) {
      const sel = document.getElementById('chorEglFilter');
      if (sel) sel.value = params.eglise_id;
    }

  } catch (err) {
    content.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
        <h3>Erreur de chargement</h3>
        <p>${err.message}</p>
        <button class="btn btn-primary" onclick="renderChoristes()">
          <i class="fas fa-redo"></i> Réessayer
        </button>
      </div>`;
  }
}

/* ── Badges stats bannière ─────────────────────────────────────── */
function _buildChoristeStats(data) {
  const total  = data.length;
  const actifs = data.filter(c => (c.statut || 'actif') === 'actif').length;
  const hommes = data.filter(c => c.sexe === 'homme').length;
  const femmes = data.filter(c => c.sexe === 'femme').length;
  const badge  = (ico, val, lbl) =>
    `<span style="background:rgba(255,255,255,0.18);padding:4px 14px;
      border-radius:20px;font-size:12px;font-weight:600">
      <i class="fas ${ico}"></i> ${val} ${lbl}
     </span>`;
  return badge('fa-music', total, 'choriste(s)') +
         badge('fa-user-check', actifs, 'actif(s)') +
         badge('fa-mars', hommes, '♂') +
         badge('fa-venus', femmes, '♀');
}

/* ══════════════════════════════════════════════════════════════════
   TABLE HTML
══════════════════════════════════════════════════════════════════ */
function _renderChorTable(liste, isAdmin) {
  if (!liste || liste.length === 0) {
    return emptyState(
      'fa-music',
      'Aucun choriste enregistré',
      'Commencez par ajouter un choriste à votre paroisse.',
      Auth.canWrite() ? 'Ajouter un choriste' : null,
      'showChoristeForm()'
    );
  }

  return `
    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Nom &amp; Prénom</th>
            <th>Sexe</th>
            <th>Voix</th>
            <th>Grade</th>
            <th>Téléphone</th>
            ${isAdmin ? '<th>Paroisse</th>' : ''}
            <th>Date d'adhésion</th>
            <th>Statut</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${liste.map((c, i) => {
            const egl = _chorEglises.find(e => e.id === c.eglise_id);
            return `
            <tr data-nom="${(`${c.nom || ''} ${c.prenom || ''}`).toLowerCase()}"
                data-egl="${c.eglise_id || ''}"
                data-voix="${c.voix || ''}"
                data-statut="${c.statut || 'actif'}">
              <td style="font-weight:700;color:var(--text-muted)">${i + 1}</td>
              <td>
                <div style="font-weight:700">${c.nom || ''} ${c.prenom || ''}</div>
                ${c.email ? `<div style="font-size:11px;color:var(--text-muted)">${c.email}</div>` : ''}
                ${c.notes ? `<div style="font-size:11px;color:var(--text-muted);font-style:italic">${c.notes}</div>` : ''}
              </td>
              <td>
                ${c.sexe === 'femme'
                  ? '<span style="color:#db2777">♀ Femme</span>'
                  : '<span style="color:#2563eb">♂ Homme</span>'}
              </td>
              <td>
                ${c.voix ? `
                <span style="background:linear-gradient(135deg,#6C3483,#9B59B6);
                  color:#fff;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600">
                  <i class="fas fa-microphone" style="margin-right:3px"></i>${c.voix}
                </span>` : '<span style="color:var(--text-muted)">—</span>'}
              </td>
              <td>${c.grade ? gradeBadge(c.grade) : '—'}</td>
              <td>
                ${c.telephone
                  ? `<a href="tel:${c.telephone}" style="color:var(--primary)">${c.telephone}</a>`
                  : '—'}
              </td>
              ${isAdmin ? `<td style="font-size:12px">${egl ? egl.nom : '—'}</td>` : ''}
              <td>${formatDateShort(c.date_adhesion)}</td>
              <td>${statutBadge(c.statut || 'actif')}</td>
              <td>
                <div style="display:flex;gap:6px">
                  ${Auth.canWrite() ? `
                  <button class="btn btn-sm btn-outline"
                    onclick="showChoristeForm('${c.id}')"
                    title="Modifier">
                    <i class="fas fa-pen"></i>
                  </button>` : ''}
                  ${Auth.canDelete() ? `
                  <button class="btn btn-sm btn-danger"
                    onclick="supprimerChoriste('${c.id}','${(`${c.nom||''} ${c.prenom||''}`).replace(/'/g,"\\'")}')"
                    title="Supprimer">
                    <i class="fas fa-trash"></i>
                  </button>` : ''}
                </div>
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;
}

/* ══════════════════════════════════════════════════════════════════
   FILTRE CLIENT
══════════════════════════════════════════════════════════════════ */
function filterChoristes() {
  const q      = (document.getElementById('chorSearch')?.value      || '').toLowerCase();
  const eglId  = document.getElementById('chorEglFilter')?.value    || '';
  const voix   = document.getElementById('chorVoixFilter')?.value   || '';
  const statut = document.getElementById('chorStatutFilter')?.value || '';

  document.querySelectorAll('#chorTable tbody tr').forEach(tr => {
    const matchQ = !q      || tr.dataset.nom.includes(q);
    const matchE = !eglId  || tr.dataset.egl === eglId;
    const matchV = !voix   || tr.dataset.voix === voix;
    const matchS = !statut || tr.dataset.statut === statut;
    tr.style.display = (matchQ && matchE && matchV && matchS) ? '' : 'none';
  });
}

/* ══════════════════════════════════════════════════════════════════
   FORMULAIRE CHORISTE (Créer / Modifier)
══════════════════════════════════════════════════════════════════ */
async function showChoristeForm(id = null) {
  const user    = Auth.getCurrentUser();
  const isAdmin = user && (user.role === 'super_admin' || user.role === 'admin');
  let ex = {};
  if (id) {
    try { ex = await API.getById('choristes', id); }
    catch { ex = {}; }
  }

  const today    = new Date().toISOString().slice(0, 10);
  const sexeInit = ex.sexe || 'homme';
  const ghomme   = typeof GRADES_HOMME !== 'undefined' ? GRADES_HOMME : [];
  const gfemme   = typeof GRADES_FEMME !== 'undefined' ? GRADES_FEMME : [];
  const grades   = sexeInit === 'femme' ? gfemme : ghomme;

  const VOIX_OPTIONS = ['Soprano', 'Mezzo-soprano', 'Contralto', 'Ténor', 'Baryton', 'Basse', 'Autre'];

  /* Sélecteur église (admin uniquement) */
  const eglHtml = isAdmin ? `
    <div class="form-group" style="grid-column:1/-1">
      <label>Paroisse <span style="color:var(--danger)">*</span></label>
      <select class="form-control" id="chorFEgl">
        <option value="">— Choisir une paroisse —</option>
        ${_chorEglises.map(e =>
          `<option value="${e.id}" ${(ex.eglise_id || _chorEgliseId) === e.id ? 'selected' : ''}>${e.nom}</option>`
        ).join('')}
      </select>
    </div>` : '';

  openModal(
    id ? 'Modifier le choriste' : 'Ajouter un choriste',
    `<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

      <div class="form-group">
        <label>Nom <span style="color:var(--danger)">*</span></label>
        <input type="text" id="chorFNom" class="form-control"
          value="${(ex.nom || '').replace(/"/g,'&quot;')}"
          placeholder="Nom de famille" />
      </div>

      <div class="form-group">
        <label>Prénom <span style="color:var(--danger)">*</span></label>
        <input type="text" id="chorFPrenom" class="form-control"
          value="${(ex.prenom || '').replace(/"/g,'&quot;')}"
          placeholder="Prénom" />
      </div>

      <div class="form-group">
        <label>Sexe <span style="color:var(--danger)">*</span></label>
        <select id="chorFSexe" class="form-control"
          onchange="_chorMajGrades(this.value)">
          <option value="homme" ${sexeInit==='homme'?'selected':''}>♂ Homme</option>
          <option value="femme" ${sexeInit==='femme'?'selected':''}>♀ Femme</option>
        </select>
      </div>

      <div class="form-group">
        <label>Voix <span style="color:var(--danger)">*</span></label>
        <select id="chorFVoix" class="form-control">
          <option value="">— Choisir —</option>
          ${VOIX_OPTIONS.map(v =>
            `<option value="${v}" ${ex.voix===v?'selected':''}>${v}</option>`
          ).join('')}
        </select>
      </div>

      <div class="form-group">
        <label>Grade</label>
        <select id="chorFGrade" class="form-control">
          <option value="">— Grade —</option>
          ${grades.map(g =>
            `<option value="${g}" ${ex.grade===g?'selected':''}>${g}</option>`
          ).join('')}
        </select>
      </div>

      <div class="form-group">
        <label>Téléphone</label>
        <input type="tel" id="chorFTel" class="form-control"
          value="${(ex.telephone || '').replace(/"/g,'&quot;')}"
          placeholder="+229 01 XX XX XX XX" />
      </div>

      <div class="form-group" style="grid-column:1/-1">
        <label>Email</label>
        <input type="email" id="chorFEmail" class="form-control"
          value="${(ex.email || '').replace(/"/g,'&quot;')}"
          placeholder="email@exemple.com" />
      </div>

      <div class="form-group">
        <label>Date d'adhésion</label>
        <input type="date" id="chorFDate" class="form-control"
          value="${ex.date_adhesion || today}" />
      </div>

      <div class="form-group">
        <label>Statut</label>
        <select id="chorFStatut" class="form-control">
          <option value="actif"   ${(ex.statut||'actif')==='actif'?'selected':''}>Actif</option>
          <option value="inactif" ${ex.statut==='inactif'?'selected':''}>Inactif</option>
        </select>
      </div>

      <div class="form-group" style="grid-column:1/-1">
        <label>Notes</label>
        <textarea id="chorFNotes" class="form-control" rows="2"
          placeholder="Informations complémentaires…">${ex.notes || ''}</textarea>
      </div>

      ${eglHtml}

    </div>`,
    id ? 'Enregistrer' : 'Ajouter',
    async () => {
      const nom    = (document.getElementById('chorFNom')?.value    || '').trim();
      const prenom = (document.getElementById('chorFPrenom')?.value || '').trim();
      const voix   = document.getElementById('chorFVoix')?.value    || '';

      if (!nom || !prenom) {
        showToast('Nom et prénom requis', 'warning'); return;
      }
      if (!voix) {
        showToast('La voix est requise', 'warning'); return;
      }

      /* Déterminer l'eglise_id */
      let eglise_id = _chorEgliseId;
      if (isAdmin) {
        eglise_id = document.getElementById('chorFEgl')?.value || '';
        if (!eglise_id) {
          showToast('Veuillez choisir une paroisse', 'warning'); return;
        }
      }

      const payload = {
        nom,
        prenom,
        sexe:         document.getElementById('chorFSexe')?.value    || 'homme',
        grade:        document.getElementById('chorFGrade')?.value   || '',
        voix,
        telephone:    (document.getElementById('chorFTel')?.value    || '').trim(),
        email:        (document.getElementById('chorFEmail')?.value  || '').trim(),
        eglise_id,
        date_adhesion: document.getElementById('chorFDate')?.value   || today,
        statut:       document.getElementById('chorFStatut')?.value  || 'actif',
        notes:        (document.getElementById('chorFNotes')?.value  || '').trim()
      };

      try {
        if (id) {
          await API.update('choristes', id, payload);
          showToast('Choriste mis à jour avec succès', 'success');
        } else {
          payload.id = generateId('chr');
          await API.create('choristes', payload);
          showToast('Choriste ajouté avec succès', 'success');
        }
        closeModal();
        renderChoristes();
      } catch (err) {
        showToast('Erreur : ' + err.message, 'error');
      }
    },
    'medium'
  );
}

/* Mise à jour dynamique des grades selon le sexe */
function _chorMajGrades(sexe) {
  const sel = document.getElementById('chorFGrade');
  if (!sel) return;
  const grades = sexe === 'femme'
    ? (typeof GRADES_FEMME !== 'undefined' ? GRADES_FEMME : [])
    : (typeof GRADES_HOMME !== 'undefined' ? GRADES_HOMME : []);
  sel.innerHTML = `<option value="">— Grade —</option>` +
    grades.map(g => `<option value="${g}">${g}</option>`).join('');
}

/* ══════════════════════════════════════════════════════════════════
   SUPPRESSION
══════════════════════════════════════════════════════════════════ */
function supprimerChoriste(id, nom) {
  confirmDelete(nom, async () => {
    try {
      await API.remove('choristes', id);
      showToast('Choriste supprimé', 'success');
      closeModal();
      renderChoristes();
    } catch (err) {
      showToast('Erreur lors de la suppression : ' + err.message, 'error');
    }
  });
}

/* ══════════════════════════════════════════════════════════════════
   EXPORT PDF
══════════════════════════════════════════════════════════════════ */
function imprimerChoristesPDF() {
  /* Récupère les lignes visibles du tableau */
  const rows = [];
  document.querySelectorAll('#chorTable tbody tr').forEach(tr => {
    if (tr.style.display === 'none') return;
    const cells = tr.querySelectorAll('td');
    if (!cells.length) return;
    const rowData = Array.from(cells).map(td => td.innerText.trim());
    rows.push(rowData);
  });

  if (!rows.length) {
    showToast('Aucune donnée à exporter', 'warning');
    return;
  }

  /* Déterminer les en-têtes selon le nombre de colonnes */
  const isAdmin = document.getElementById('chorDataStore')?.dataset.isAdmin === 'true';
  const headers = isAdmin
    ? ['#', 'Nom & Prénom', 'Sexe', 'Voix', 'Grade', 'Téléphone', 'Paroisse', 'Date adhésion', 'Statut']
    : ['#', 'Nom & Prénom', 'Sexe', 'Voix', 'Grade', 'Téléphone', 'Date adhésion', 'Statut'];

  /* Nom de l'église (pour titre) */
  let titreParoisse = 'Toutes les paroisses';
  if (!isAdmin && _chorEgliseId) {
    const egl = _chorEglises.find(e => e.id === _chorEgliseId);
    if (egl) titreParoisse = egl.nom;
  }

  /* Filtre église admin */
  const eglFil = document.getElementById('chorEglFilter');
  if (isAdmin && eglFil && eglFil.value) {
    const egl = _chorEglises.find(e => e.id === eglFil.value);
    if (egl) titreParoisse = egl.nom;
  }

  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

    /* En-tête document */
    doc.setFillColor(108, 52, 131);
    doc.rect(0, 0, 297, 28, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text('🎵 Liste des Choristes', 14, 12);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.text(`Paroisse : ${titreParoisse}`, 14, 21);
    doc.text(`Date d'impression : ${new Date().toLocaleDateString('fr-FR')}`, 200, 21);

    /* Tableau */
    doc.autoTable({
      head: [headers],
      body: rows.map(r => r.slice(0, headers.length)),
      startY: 33,
      styles: {
        font: 'helvetica',
        fontSize: 9,
        cellPadding: 3,
        overflow: 'linebreak'
      },
      headStyles: {
        fillColor: [108, 52, 131],
        textColor: 255,
        fontStyle: 'bold',
        fontSize: 9
      },
      alternateRowStyles: { fillColor: [248, 244, 255] },
      columnStyles: { 0: { halign: 'center', cellWidth: 10 } }
    });

    /* Pied de page */
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setTextColor(150);
      doc.text(
        `Communauté Céleste — Recensement Paroissial · Page ${i} / ${pageCount}`,
        148, 205, { align: 'center' }
      );
    }

    doc.save(`choristes_${titreParoisse.replace(/\s+/g,'_')}_${new Date().toISOString().slice(0,10)}.pdf`);
    showToast('PDF généré avec succès', 'success');
  } catch (err) {
    showToast('Erreur génération PDF : ' + err.message, 'error');
  }
}
