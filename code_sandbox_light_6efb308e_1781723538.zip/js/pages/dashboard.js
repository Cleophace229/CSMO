/**
 * Dashboard Page — Admin global
 */
async function renderDashboard() {
  setBreadcrumb([{ label: I18n.t('nav.dashboard') }]);
  const content = document.getElementById('pageContent');

  try {
    const [regs, srs, egls, mems, evs, cots, msgs] = await Promise.all([
      API.getAll('regions'),
      API.getAll('sous_regions'),
      API.getAll('eglises'),
      API.getAll('membres'),
      API.getAll('evenements'),
      API.getAll('cotisations'),
      API.getAll('messages', { limit: 300 }).catch(() => ({ data: [] }))
    ]);

    /* Messages non lus (réponses des églises) */
    const msgsNonLus = (msgs.data || []).filter(m =>
      !m.lu && m.direction === 'eglise_to_admin'
    ).length;

    /* Rafraîchir badge messagerie */
    const msgBadge = document.getElementById('msgNavBadge');
    if (msgBadge) {
      msgBadge.textContent = msgsNonLus > 9 ? '9+' : msgsNonLus;
      msgBadge.style.display = msgsNonLus > 0 ? '' : 'none';
    }

    const actifMembres = mems.data.filter(m => m.statut === 'actif').length;
    const actifEglises = egls.data.filter(e => e.statut === 'actif').length;
    const totalCots = cots.data.filter(c => c.statut === 'payé').reduce((s, c) => s + Number(c.montant || 0), 0);
    const upcomingEvs = evs.data.filter(e => e.date_debut && new Date(e.date_debut) >= new Date()).length;

    // Role breakdown
    const roles = {};
    mems.data.forEach(m => { roles[m.role || 'Non défini'] = (roles[m.role || 'Non défini'] || 0) + 1; });

    // Grade breakdown
    const grades = {};
    mems.data.forEach(m => { grades[m.grade || 'Non défini'] = (grades[m.grade || 'Non défini'] || 0) + 1; });

    // Recent members
    const recentMems = [...mems.data].sort((a, b) => (b.created_at || 0) - (a.created_at || 0)).slice(0, 6);

    // Upcoming events
    const nextEvs = evs.data.filter(e => e.date_debut && new Date(e.date_debut) >= new Date()).sort((a, b) => new Date(a.date_debut) - new Date(b.date_debut)).slice(0, 5);

    // Fêtes religieuses à venir (30 jours)
    const fetes = _getFetesReligieuses();
    const prochainesFetes = fetes.filter(f => f.jours >= 0 && f.jours <= 30).slice(0, 3);

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title"><i class="fas fa-church" style="margin-right:10px"></i>${I18n.t('dash.title')}</h2>
          <p>${I18n.t('dash.subtitle')}</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-primary" onclick="showNouveauMessage()">
            <i class="fas fa-paper-plane"></i> ${I18n.t('dash.send_msg')}
          </button>
        </div>
      </div>

      ${msgsNonLus > 0 ? `
      <div onclick="App.navigate('messages')" style="cursor:pointer;
        background:linear-gradient(135deg,#fef3c7,#fff7ed);
        border:1.5px solid #f59e0b;border-radius:12px;padding:14px 18px;
        margin-bottom:20px;display:flex;align-items:center;gap:14px">
        <div style="width:42px;height:42px;border-radius:10px;flex-shrink:0;
          background:linear-gradient(135deg,#f59e0b,#ef4444);
          display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px">
          <i class="fas fa-reply"></i>
        </div>
        <div style="flex:1">
          <div style="font-weight:700;font-size:14px;color:#92400e">
            ${msgsNonLus} ${I18n.t('dash.unread_replies')}
          </div>
          <div style="font-size:12px;color:#b45309;margin-top:2px">${I18n.lang==='en'?'Click to open the messaging':'Cliquez pour consulter la messagerie'}</div>
        </div>
        <i class="fas fa-chevron-right" style="color:#f59e0b;font-size:14px"></i>
      </div>` : ''}

      ${prochainesFetes.length > 0 ? `
      <div style="background:linear-gradient(135deg,#f0f9ff,#e0f2fe);
        border:1px solid #bae6fd;border-radius:12px;padding:14px 18px;margin-bottom:20px">
        <div style="font-size:12px;font-weight:700;color:#075985;text-transform:uppercase;
          letter-spacing:.5px;margin-bottom:10px">
          <i class="fas fa-star" style="color:#f59e0b;margin-right:6px"></i>${I18n.t('dash.religious_feasts')}
        </div>
        <div style="display:flex;gap:12px;flex-wrap:wrap">
          ${prochainesFetes.map(f => `
          <div style="background:#fff;border-radius:10px;padding:10px 14px;border:1px solid #bae6fd;
            flex:1;min-width:140px">
            <div style="font-weight:700;font-size:13px;color:#0369a1">${f.nom}</div>
            <div style="font-size:11px;color:#64748b;margin-top:2px">
              ${f.jours === 0 ? `<span style="color:#ef4444;font-weight:700">${I18n.t('dash.today')}</span>`
                : I18n.t('dash.in_days', {n: f.jours})}
              &middot; ${f.date}
            </div>
          </div>`).join('')}
        </div>
      </div>` : ''}

      <!-- Stats -->
      <div class="stats-grid">
        <div class="stat-card info" style="cursor:pointer" onclick="App.navigate('regions')">
          <div class="stat-icon"><i class="fas fa-globe-africa"></i></div>
          <div class="stat-info"><h3>${regs.total}</h3><p>${I18n.t('dash.regions')}</p></div>
        </div>
        <div class="stat-card" style="cursor:pointer" onclick="App.navigate('sous_regions')">
          <div class="stat-icon"><i class="fas fa-map-marked-alt"></i></div>
          <div class="stat-info"><h3>${srs.total}</h3><p>${I18n.t('dash.sous_regions')}</p></div>
        </div>
        <div class="stat-card success" style="cursor:pointer" onclick="App.navigate('eglises')">
          <div class="stat-icon"><i class="fas fa-church"></i></div>
          <div class="stat-info"><h3>${actifEglises}</h3><p>${I18n.t('dash.active_churches')}</p></div>
        </div>
        <div class="stat-card gold" style="cursor:pointer" onclick="App.navigate('membres')">
          <div class="stat-icon"><i class="fas fa-users"></i></div>
          <div class="stat-info"><h3>${actifMembres}</h3><p>${I18n.t('dash.active_members')}</p></div>
        </div>
        <div class="stat-card warning" style="cursor:pointer" onclick="App.navigate('evenements')">
          <div class="stat-icon"><i class="fas fa-calendar-alt"></i></div>
          <div class="stat-info"><h3>${upcomingEvs}</h3><p>${I18n.t('dash.upcoming_events')}</p></div>
        </div>
        <div class="stat-card danger" style="cursor:pointer" onclick="App.navigate('cotisations')">
          <div class="stat-icon"><i class="fas fa-hand-holding-usd"></i></div>
          <div class="stat-info"><h3>${formatAmount(totalCots)}</h3><p>${I18n.t('dash.contributions')}</p></div>
        </div>
        <div class="stat-card ${msgsNonLus>0?'danger':'primary'}" style="cursor:pointer" onclick="App.navigate('messages')">
          <div class="stat-icon"><i class="fas fa-envelope"></i></div>
          <div class="stat-info"><h3>${msgsNonLus > 0 ? msgsNonLus : (msgs.data||[]).filter(m=>!m.message_parent_id).length}</h3>
            <p>${msgsNonLus>0?I18n.t('dash.unread_replies'):I18n.t('dash.sent_messages')}</p></div>
        </div>
      </div>

      <div class="grid-2">
        <!-- Hierarchy Overview -->
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-sitemap"></i> ${I18n.t('dash.hierarchy')}</h3>
            <button class="btn btn-sm btn-outline-primary" onclick="App.navigate('regions')">${I18n.t('dash.see_all')}</button>
          </div>
          <div class="card-body" style="padding:0">
            ${regs.data.map(reg => {
              const regSrs = srs.data.filter(s => s.region_id === reg.id);
              const regEgls = egls.data.filter(e => e.region_id === reg.id);
              const regMems = mems.data.filter(m => regEgls.some(e => e.id === m.eglise_id));
              return `
                <div style="padding:14px 20px;border-bottom:1px solid var(--border);cursor:pointer;transition:background 0.2s" onmouseover="this.style.background='#f8f0fd'" onmouseout="this.style.background=''" onclick="App.navigate('sous_regions',{region_id:'${reg.id}'})">
                  <div class="flex-between">
                    <div>
                      <div style="font-weight:600;color:var(--primary-dark)">${reg.nom}</div>
                      <div style="font-size:12px;color:var(--text-muted)">${regSrs.length} sous-région(s) · ${regEgls.length} église(s) · ${regMems.length} membre(s)</div>
                    </div>
                    <div style="display:flex;gap:6px">
                      <span class="badge badge-info">${regSrs.length} SR</span>
                      <span class="badge badge-success">${regEgls.length} EGL</span>
                    </div>
                  </div>
                </div>`;
            }).join('')}
          </div>
        </div>

        <!-- Recent Members -->
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-user-plus"></i> ${I18n.t('dash.recent_members')}</h3>
            <button class="btn btn-sm btn-outline-primary" onclick="App.navigate('membres')">${I18n.t('dash.see_all_members')}</button>
          </div>
          <div class="card-body" style="padding:0">
            ${recentMems.length === 0 ? `<div style="padding:20px;text-align:center;color:var(--text-muted)">${I18n.t('dash.no_members')}</div>` :
              recentMems.map(m => `
              <div style="display:flex;align-items:center;gap:12px;padding:12px 20px;border-bottom:1px solid var(--border);cursor:pointer" onclick="viewMembre('${m.id}')">
                ${memberAvatar(m, 38)}
                <div style="flex:1">
                  <div style="font-weight:600;font-size:13px">${m.prenom} ${m.nom}</div>
                  <div style="font-size:11px;color:var(--text-muted)">${m.grade || '—'} · ${m.role || '—'}</div>
                </div>
                ${statutBadge(m.statut)}
              </div>`).join('')
            }
          </div>
        </div>
      </div>

      <div class="grid-2">
        <!-- Upcoming Events -->
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-calendar-check"></i> ${I18n.t('dash.upcoming_events_title')}</h3>
            <button class="btn btn-sm btn-outline-primary" onclick="App.navigate('evenements')">${I18n.t('dash.see_all_members')}</button>
          </div>
          <div class="card-body" style="padding:0">
            ${nextEvs.length === 0 ? `<div style="padding:20px;text-align:center;color:var(--text-muted)">${I18n.t('dash.no_events')}</div>` :
              nextEvs.map(ev => {
                const typeColors = { 'Messe': 'badge-primary', 'Bapteme': 'badge-success', 'Mariage': 'badge-gold', 'Funérailles': 'badge-secondary', 'Réunion': 'badge-info', 'Fête liturgique': 'badge-warning', 'Autre': 'badge-secondary' };
                return `<div style="padding:12px 20px;border-bottom:1px solid var(--border)">
                  <div class="flex-between">
                    <div style="font-weight:600;font-size:13px">${ev.titre}</div>
                    <span class="badge ${typeColors[ev.type_evenement] || 'badge-secondary'}">${ev.type_evenement || '—'}</span>
                  </div>
                  <div style="font-size:12px;color:var(--text-muted);margin-top:3px"><i class="fas fa-calendar" style="margin-right:4px"></i>${formatDateShort(ev.date_debut)} · ${ev.lieu || ''}</div>
                </div>`;
              }).join('')
            }
          </div>
        </div>

        <!-- Members by Grade -->
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-layer-group"></i> ${I18n.lang==='en'?'Members by grade':'Membres par grade'}</h3>
          </div>
          <div class="card-body" style="padding:12px 20px">
            ${Object.entries(grades).sort((a,b) => b[1]-a[1]).map(([grade, count]) => `
              <div style="margin-bottom:12px">
                <div class="flex-between mb-1">
                  <span style="font-size:13px;font-weight:500">${grade}</span>
                  <span style="font-size:12px;color:var(--text-muted)">${count} ${I18n.lang==='en'?'member(s)':'membre(s)'}</span>
                </div>
                <div class="progress-bar-container">
                  <div class="progress-bar-fill" style="width:${Math.round(count / mems.total * 100)}%"></div>
                </div>
              </div>`).join('') || '<p class="text-muted text-center">Aucune donnée</p>'}
          </div>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="card mt-2">
        <div class="card-header"><h3><i class="fas fa-bolt"></i> ${I18n.lang==='en'?'Quick actions':'Actions rapides'}</h3></div>
        <div class="card-body">
          <div style="display:flex;gap:12px;flex-wrap:wrap">
            <button class="btn btn-primary" onclick="App.navigate('regions');setTimeout(handleAddNew,200)">
              <i class="fas fa-globe-africa"></i> ${I18n.lang==='en'?'Add a region':'Ajouter une région'}
            </button>
            <button class="btn btn-success" onclick="App.navigate('eglises');setTimeout(handleAddNew,200)">
              <i class="fas fa-church"></i> ${I18n.lang==='en'?'Add a church':'Ajouter une église'}
            </button>
            <button class="btn btn-gold" onclick="App.navigate('membres');setTimeout(handleAddNew,200)">
              <i class="fas fa-user-plus"></i> ${I18n.lang==='en'?'Add a member':'Ajouter un membre'}
            </button>
            <button class="btn btn-info" onclick="App.navigate('evenements');setTimeout(handleAddNew,200)">
              <i class="fas fa-calendar-plus"></i> ${I18n.lang==='en'?'Add an event':'Ajouter un événement'}
            </button>
            <button class="btn" style="background:linear-gradient(135deg,#7c3aed,#3b82f6);color:#fff"
              onclick="showNouveauMessage()">
              <i class="fas fa-envelope"></i> ${I18n.t('dash.send_msg')}
            </button>
            <button class="btn btn-warning" onclick="App.navigate('statistiques')">
              <i class="fas fa-chart-bar"></i> ${I18n.t('nav.stats')}
            </button>
            <button class="btn btn-outline" onclick="App.navigate('export')">
              <i class="fas fa-file-export"></i> ${I18n.lang==='en'?'Export':'Exporter'}
            </button>
          </div>
        </div>
      </div>
    `;
  } catch (err) {
    content.innerHTML = `<div class="empty-state">
      <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
      <h3>${I18n.t('err.loading')}</h3><p>${err.message}</p>
      <button class="btn btn-primary" onclick="App.navigate('dashboard')">
        <i class="fas fa-redo"></i> ${I18n.t('btn.retry')}
      </button></div>`;
  }
}

/* ═══════════════════════════════════════════════════════════════
   UTILITAIRE : FÊTES RELIGIEUSES DE L'ANNÉE EN COURS
   ═══════════════════════════════════════════════════════════════ */
function _getFetesReligieuses() {
  const now  = new Date();
  const year = now.getFullYear();

  /* Calcul de Pâques (algorithme de Butcher) */
  function getPaques(y) {
    const a = y % 19, b = Math.floor(y / 100), c = y % 100;
    const d = Math.floor(b / 4), e = b % 4;
    const f = Math.floor((b + 8) / 25);
    const g = Math.floor((b - f + 1) / 3);
    const h = (19 * a + b - d - g + 15) % 30;
    const i = Math.floor(c / 4), k = c % 4;
    const l = (32 + 2 * e + 2 * i - h - k) % 7;
    const m = Math.floor((a + 11 * h + 22 * l) / 451);
    const month = Math.floor((h + l - 7 * m + 114) / 31);
    const day   = ((h + l - 7 * m + 114) % 31) + 1;
    return new Date(y, month - 1, day);
  }

  const paques    = getPaques(year);
  const ascension = new Date(paques); ascension.setDate(paques.getDate() + 39);
  const pentecote = new Date(paques); pentecote.setDate(paques.getDate() + 49);

  const fetes = [
    { nom: 'Noël',                   date: new Date(year, 11, 25) },
    { nom: 'Pâques',                 date: paques                 },
    { nom: 'Ascension',              date: ascension               },
    { nom: 'Pentecôte',              date: pentecote               },
    { nom: 'Assomption',             date: new Date(year, 7, 15)  },
    { nom: 'Toussaint',              date: new Date(year, 10, 1)  },
    { nom: 'Immaculée Conception',   date: new Date(year, 11, 8)  },
    { nom: 'Epiphanie',              date: new Date(year, 0, 6)   },
    { nom: 'Fête-Dieu',              date: new Date(pentecote.getTime() + 11*86400000) }
  ];

  return fetes.map(f => {
    const diff = Math.ceil((f.date - now) / 86400000);
    /* Si déjà passé cette année, calculer pour l'an prochain */
    if (diff < -1) {
      f.date.setFullYear(year + 1);
    }
    const jours = Math.ceil((f.date - now) / 86400000);
    return {
      nom:  f.nom,
      date: f.date.toLocaleDateString('fr-FR', { day: '2-digit', month: 'long' }),
      jours: jours < 0 ? 999 : jours
    };
  }).sort((a, b) => a.jours - b.jours);
}

/* Note: formatAmount() est défini dans js/utils.js */
