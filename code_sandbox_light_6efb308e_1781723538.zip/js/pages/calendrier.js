/**
 * Calendrier Liturgique — Recensement Paroissial
 * Fêtes chrétiennes fixes + mobiles + fêtes civiles (non musulmanes)
 */
App.registerAddHandler('calendrier', () => showEvenementForm());

let calYear   = new Date().getFullYear();
let calMonth  = new Date().getMonth();
let calEvents  = [];
let calEglises = [];
let calEgliseFilter = '';

/* ═══════════════════════════════════════════════════════════════
   FÊTES FIXES CHRÉTIENNES ET CIVILES (hors fêtes musulmanes)
   mois en index 0-11
   ═══════════════════════════════════════════════════════════════ */
const FETES_FIXES = [
  /* ── Janvier ─────────────────────────────────── */
  /* ── Janvier ─────────────────────────────────── */
  { mois: 0,  jour: 1,  nom: 'Jour de l\'An',                               type: 'Fête ECC', civil: true },

  /* ── Avril ─────────────────────────────────────── */
  { mois: 3,  jour: 18, nom: 'Fête nationale du Bénin (1ère proclamation)', type: 'Fête ECC', civil: true },

  /* ── Mai ─────────────────────────────────────────── */
  { mois: 4,  jour: 1,  nom: 'Fête du Travail',                             type: 'Fête ECC', civil: true },

  /* ── Juillet ─────────────────────────────────────── */
  { mois: 6,  jour: 14, nom: 'Fête Nationale Française (Bastille)',         type: 'Fête ECC', civil: true },
  /* Note : Jour de la Vierge Marie — 1er vendredi de juillet → calculé dynamiquement */

  /* ── Août ───────────────────────────────────────── */
  { mois: 7,  jour: 1,  nom: 'Fête Nationale du Bénin (Indépendance)',      type: 'Fête ECC', civil: true },

  /* ── Septembre ──────────────────────────────────── */
  { mois: 8,  jour: 10, nom: '🍂 Commémoration du décès du Fondateur — Rév. Proph. Pasteur S.B.J. Oschoffa (1985)',
                                                                             type: 'Fête ECC', ecc: true },
  { mois: 8,  jour: 29, nom: '⭐ Anniversaire de la naissance de l\'ECC (1947)',
                                                                             type: 'Fête ECC', ecc: true },

  /* ── Octobre ────────────────────────────────────── */
  { mois: 9,  jour: 19, nom: '🪦 Anniversaire de l\'enterrement du Fondateur (1985)',
                                                                             type: 'Fête ECC', ecc: true },
  { mois: 9,  jour: 30, nom: 'Fête de la Nation (Bénin)',                   type: 'Fête ECC', civil: true },

  /* ── Décembre ───────────────────────────────────── */
  { mois: 11, jour: 25, nom: 'Noël — Nativité du Seigneur',                 type: 'Fête ECC', civil: true }
];

/* ═══════════════════════════════════════════════════════════════
   CALCUL DE PÂQUES (Algorithme de Butcher)
   ═══════════════════════════════════════════════════════════════ */
function _computeEaster(year) {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day   = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(year, month - 1, day);
}

/* ═══════════════════════════════════════════════════════════════
   FÊTES MOBILES (calculées depuis Pâques)
   ═══════════════════════════════════════════════════════════════ */
function _getMobileFeasts(year) {
  const easter  = _computeEaster(year);
  const add     = (d, n) => { const r = new Date(d); r.setDate(r.getDate() + n); return r; };

  return [
    /* ── Carême ── */
    /* Semaine Sainte ECC */
    { date: add(easter, -14), nom: 'Dimanche des Rameaux',                    type: 'Fête ECC' },
    { date: add(easter, -3),  nom: 'Jeudi Saint — Cène du Seigneur',          type: 'Fête ECC' },
    { date: add(easter, -2),  nom: 'Vendredi Saint — Passion du Christ',      type: 'Funérailles' },
    /* Pâques */
    { date: easter,             nom: 'Pâques — Résurrection du Christ',       type: 'Pâques' },
    { date: add(easter,  1),    nom: 'Lundi de Pâques',                       type: 'Pâques' },
    /* Ascension + Pentecôte ECC */
    { date: add(easter, 39),    nom: 'Ascension — Jésus élevé au Ciel',       type: 'Ascension' },
    { date: add(easter, 49),    nom: 'Pentecôte — Effusion du Saint-Esprit',  type: 'Pentecôte' },
    { date: add(easter, 50),    nom: 'Lundi de Pentecôte',                    type: 'Pentecôte' }
  ];
}

/* 1er dimanche d'un mois (Fête des Moissons ECC) */
function _getFirstSundayOfMonth(year, month) {
  const d   = new Date(year, month, 1);
  const dow = d.getDay();
  const diff = dow === 0 ? 0 : 7 - dow;
  return new Date(year, month, 1 + diff);
}
/* 1er vendredi d'un mois (Jour de la Vierge Marie ECC) */
function _getFirstFridayOfMonth(year, month) {
  const d   = new Date(year, month, 1);
  const dow = d.getDay();
  const diff = dow <= 5 ? 5 - dow : 12 - dow;
  return new Date(year, month, 1 + diff);
}

/* Retourne toutes les fêtes pour une année donnée (fixes ECC + mobiles + fêtes mobiles ECC) */
function _getAllFeastsForYear(year) {
  const feasts = [];

  // Fêtes fixes ECC
  FETES_FIXES.forEach(f => {
    feasts.push({
      date:  new Date(year, f.mois, f.jour),
      nom:   f.nom,
      type:  f.type,
      civil: f.civil || false,
      ecc:   f.ecc   || false,
      feast: true
    });
  });

  // Fêtes mobiles (Semaine Sainte, Pâques, Ascension, Pentecôte)
  _getMobileFeasts(year).forEach(f => {
    feasts.push({ ...f, feast: true });
  });

  // Fête des Moissons des Enfants ECC — 1er dimanche de juin
  feasts.push({
    date:  _getFirstSundayOfMonth(year, 5),
    nom:   '🌾 Fête des Moissons des Enfants ECC',
    type:  'Fête ECC', ecc: true, civil: false, feast: true
  });

  // Jour de la Vierge Marie ECC — 1er vendredi de juillet
  feasts.push({
    date:  _getFirstFridayOfMonth(year, 6),
    nom:   '🙏 Jour de la Vierge Marie — Apparition de 1977 (ECC)',
    type:  'Fête ECC', ecc: true, civil: false, feast: true
  });

  return feasts;
}

/* ═══════════════════════════════════════════════════════════════
   COULEURS PAR TYPE D'ÉVÉNEMENT
   ═══════════════════════════════════════════════════════════════ */
const TYPE_COLORS = {
  'Messe':                 { bg: '#E8D5F5', text: '#6C3483', css: 'cal-messe' },
  'Bapteme':               { bg: '#D5E8D4', text: '#117A65', css: 'cal-bapteme' },
  'Mariage':               { bg: '#FFF3CD', text: '#856404', css: 'cal-mariage' },
  'Funérailles':           { bg: '#E2E3E5', text: '#383D41', css: 'cal-funerailles' },
  'Sortie d\'enfant':      { bg: '#CCE5FF', text: '#004085', css: 'cal-sortie' },
  'Veillée de funéraille': { bg: '#D1D3E2', text: '#2D2D6B', css: 'cal-veillée' },
  'Messe du 8ème jour':    { bg: '#FFEEBA', text: '#856404', css: 'cal-messe8' },
  'Messe du 41ème jour':   { bg: '#FFEEBA', text: '#856404', css: 'cal-messe41' },
  'Pâques':                { bg: '#D4EDDA', text: '#155724', css: 'cal-paques' },
  'Pentecôte':             { bg: '#F8D7DA', text: '#721C24', css: 'cal-pentecote' },
  'Ascension':             { bg: '#CCE5FF', text: '#004085', css: 'cal-ascension' },
  'Réunion':               { bg: '#D1ECF1', text: '#0C5460', css: 'cal-reunion' },
  'Fête liturgique':       { bg: '#FFF9C4', text: '#795548', css: 'cal-fete' },
  'Fête ECC':              { bg: '#EDE7F6', text: '#4527A0', css: 'cal-ecc' },
  'Autre':                 { bg: '#F5F5F5', text: '#616161', css: 'cal-autre' }
};

function _typeColor(type) {
  return TYPE_COLORS[type] || TYPE_COLORS['Autre'];
}

/* ═══════════════════════════════════════════════════════════════
   RENDER PRINCIPAL
   ═══════════════════════════════════════════════════════════════ */
async function renderCalendrier(params = {}) {
  setBreadcrumb([{ label: I18n.t('calendar.title') }]);
  const content = document.getElementById('pageContent');
  const user    = Auth.getCurrentUser();
  const isEglise = user && user.eglise_id && user.role !== 'super_admin' && user.role !== 'admin';

  content.innerHTML = `<div class="loading-spinner"><i class="fas fa-circle-notch fa-spin"></i><p>Chargement...</p></div>`;

  try {
    const [evRes, eglRes] = await Promise.all([
      API.getAll('evenements'),
      API.getAll('eglises')
    ]);

    calEvents  = evRes.data;
    calEglises = eglRes.data;

    // Filtre automatique pour compte église
    if (isEglise) {
      calEgliseFilter = user.eglise_id;
    } else {
      calEgliseFilter = params.eglise_id || '';
    }

    const eglFilterHTML = !isEglise ? `
      <select class="form-control" id="calEglFilter"
        style="width:200px;font-size:13px"
        onchange="calEgliseFilter=this.value;renderCalMonth()">
        <option value="">Toutes les églises</option>
        ${calEglises.map(e =>
          `<option value="${e.id}" ${calEgliseFilter === e.id ? 'selected' : ''}>${e.nom}</option>`
        ).join('')}
      </select>` : '';

    const eglNom = isEglise
      ? (calEglises.find(e => e.id === user.eglise_id)?.nom || 'Mon Église')
      : '';

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-calendar-alt" style="margin-right:10px"></i>
            Calendrier Liturgique${eglNom ? ' — ' + eglNom : ''}
          </h2>
        </div>
        <div class="page-header-actions">
          ${Auth.canWrite() ? `<button class="btn btn-primary" onclick="showEvenementForm()"><i class="fas fa-plus"></i> Ajouter</button>` : ''}
        </div>
      </div>

      <!-- Contrôles navigation -->
      <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px">
        <button class="btn btn-outline btn-sm" onclick="calNavigate(-1)">
          <i class="fas fa-chevron-left"></i>
        </button>
        <h3 id="calMonthTitle" style="margin:0;font-family:'Playfair Display',serif;
          font-size:20px;min-width:200px;text-align:center;color:var(--primary-dark)"></h3>
        <button class="btn btn-outline btn-sm" onclick="calNavigate(1)">
          <i class="fas fa-chevron-right"></i>
        </button>
        <button class="btn btn-sm btn-primary" onclick="calGoToday()">
          <i class="fas fa-dot-circle"></i> Aujourd'hui
        </button>
        ${eglFilterHTML}
      </div>

      <!-- Légende -->
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px">
        ${Object.entries(TYPE_COLORS).slice(0, 8).map(([t, c]) =>
          `<span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;
            padding:3px 8px;border-radius:20px;background:${c.bg};color:${c.text};font-weight:600">
            <span style="width:8px;height:8px;border-radius:50%;background:${c.text};display:inline-block"></span>
            ${t}
          </span>`
        ).join('')}
        <span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;
          padding:3px 8px;border-radius:20px;background:#FFF9C4;color:#795548;font-weight:600">
          <span style="width:8px;height:8px;border-radius:50%;background:#795548;display:inline-block"></span>
          Fête liturgique / Civile
        </span>
      </div>

      <!-- Grille calendrier -->
      <div id="calContainer"></div>

      <!-- Fêtes du mois & prochains événements -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:20px" id="calBottom">
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-star" style="color:var(--gold);margin-right:8px"></i>Fêtes du mois</h3>
          </div>
          <div id="calFetesList" style="max-height:300px;overflow-y:auto"></div>
        </div>
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-clock" style="color:var(--primary);margin-right:8px"></i>Prochains événements</h3>
          </div>
          <div id="calUpcomingList" style="max-height:300px;overflow-y:auto"></div>
        </div>
      </div>
    `;

    renderCalMonth();

  } catch (err) {
    content.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i>
      <h3>Erreur</h3><p>${err.message}</p></div>`;
  }
}

/* ═══════════════════════════════════════════════════════════════
   RENDU DU MOIS
   ═══════════════════════════════════════════════════════════════ */
function renderCalMonth() {
  const titleEl = document.getElementById('calMonthTitle');
  const container = document.getElementById('calContainer');
  if (!titleEl || !container) return;

  const monthNames = ['Janvier','Février','Mars','Avril','Mai','Juin',
                      'Juillet','Août','Septembre','Octobre','Novembre','Décembre'];
  titleEl.textContent = `${monthNames[calMonth]} ${calYear}`;

  const today     = new Date();
  const firstDay  = new Date(calYear, calMonth, 1).getDay(); // 0=dim
  const daysInMonth = new Date(calYear, calMonth + 1, 0).getDate();
  const startOffset = (firstDay + 6) % 7; // lundi en premier

  // Fêtes liturgiques du mois courant
  const allFeasts  = _getAllFeastsForYear(calYear);
  const monthFeasts = allFeasts.filter(f => f.date.getMonth() === calMonth);

  // Événements paroissiaux du mois courant
  const monthEvents = calEvents.filter(ev => {
    if (!ev.date_debut) return false;
    if (calEgliseFilter && ev.eglise_id !== calEgliseFilter) return false;
    const d = new Date(ev.date_debut);
    return d.getFullYear() === calYear && d.getMonth() === calMonth;
  });

  // Jours de la semaine (lundi-dimanche)
  const dayHeaders = ['Lun','Mar','Mer','Jeu','Ven','Sam','<span style="color:var(--danger)">Dim</span>'];

  let html = `
    <div style="background:var(--bg-card);border-radius:12px;overflow:hidden;box-shadow:var(--shadow);border:1px solid var(--border)">
      <!-- En-têtes jours -->
      <div class="cal-grid" style="display:grid;grid-template-columns:repeat(7,1fr);
        background:linear-gradient(135deg,var(--primary-dark),var(--primary));padding:10px 0">
        ${dayHeaders.map(d =>
          `<div style="text-align:center;font-size:12px;font-weight:700;color:#fff;padding:6px">${d}</div>`
        ).join('')}
      </div>

      <!-- Cellules jours -->
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:1px;background:var(--border)">`;

  // Cases vides avant le 1er
  for (let i = 0; i < startOffset; i++) {
    html += `<div style="background:var(--bg-card);min-height:90px;opacity:.3"></div>`;
  }

  // Jours du mois
  for (let day = 1; day <= daysInMonth; day++) {
    const isToday = (today.getFullYear() === calYear && today.getMonth() === calMonth && today.getDate() === day);
    const dayDate = new Date(calYear, calMonth, day);

    // Fêtes du jour
    const dayFeasts = monthFeasts.filter(f => f.date.getDate() === day);
    // Événements du jour
    const dayEvs = monthEvents.filter(ev => new Date(ev.date_debut).getDate() === day);

    const allDayItems = [
      ...dayFeasts.map(f => ({ label: f.nom, type: f.type, feast: true })),
      ...dayEvs.map(ev => ({ label: ev.titre, type: ev.type_evenement, id: ev.id, feast: false }))
    ];

    const maxShow = 3;
    const extra   = allDayItems.length - maxShow;

    html += `
      <div style="background:var(--bg-card);min-height:90px;padding:6px;
        ${isToday ? 'border:2px solid var(--primary) !important;background:#f8f0fd;' : ''}
        position:relative;vertical-align:top;cursor:default">
        <div style="font-size:12px;font-weight:${isToday ? '800' : '600'};
          color:${isToday ? 'var(--primary)' : 'var(--text)'};
          ${isToday ? 'background:var(--primary);color:#fff;width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;' : ''}
          margin-bottom:4px">
          ${day}
        </div>
        ${allDayItems.slice(0, maxShow).map(item => {
          const c = _typeColor(item.type);
          const icon = item.feast ? '✦ ' : '';
          return `<div onclick="${item.id ? `showEventDetail('${item.id}')` : ''}"
            style="font-size:10px;padding:2px 5px;border-radius:4px;margin-bottom:2px;
              background:${c.bg};color:${c.text};white-space:nowrap;overflow:hidden;
              text-overflow:ellipsis;${item.id ? 'cursor:pointer' : ''}" title="${item.label}">
            ${icon}${item.label}
          </div>`;
        }).join('')}
        ${extra > 0 ? `<div style="font-size:10px;color:var(--text-muted);font-style:italic">+${extra} autre(s)</div>` : ''}
      </div>`;
  }

  // Cases vides après le dernier jour
  const totalCells = startOffset + daysInMonth;
  const remaining  = (7 - (totalCells % 7)) % 7;
  for (let i = 0; i < remaining; i++) {
    html += `<div style="background:var(--bg-card);min-height:90px;opacity:.3"></div>`;
  }

  html += `</div></div>`;
  container.innerHTML = html;

  // Mettre à jour les listes latérales
  _renderFetesList(monthFeasts);
  _renderUpcomingList();
}

/* ─── Liste des fêtes du mois ─────────────────────────────────── */
function _renderFetesList(feasts) {
  const el = document.getElementById('calFetesList');
  if (!el) return;

  if (!feasts.length) {
    el.innerHTML = '<p class="text-center text-muted" style="padding:16px">Aucune fête ce mois</p>';
    return;
  }

  el.innerHTML = feasts
    .sort((a, b) => a.date.getDate() - b.date.getDate())
    .map(f => {
      const c = _typeColor(f.type);
      const dayNames = ['dim','lun','mar','mer','jeu','ven','sam'];
      const dayName  = dayNames[f.date.getDay()];
      return `
        <div style="display:flex;align-items:flex-start;gap:10px;padding:10px 16px;
          border-bottom:1px solid var(--border)">
          <div style="width:36px;height:36px;border-radius:8px;background:${c.bg};
            display:flex;flex-direction:column;align-items:center;justify-content:center;
            flex-shrink:0;font-weight:700">
            <span style="font-size:14px;color:${c.text}">${f.date.getDate()}</span>
            <span style="font-size:9px;color:${c.text};text-transform:uppercase">${dayName}</span>
          </div>
          <div style="flex:1">
            <div style="font-size:12px;font-weight:600;color:var(--text)">${f.nom}</div>
            <div style="font-size:11px;margin-top:2px">
              <span style="padding:2px 6px;border-radius:10px;background:${c.bg};color:${c.text};font-size:10px">
                ${f.civil ? '🏛 Civile · ' : '✦ '}${f.type}
              </span>
            </div>
          </div>
        </div>`;
    }).join('');
}

/* ─── Prochains événements paroissiaux ───────────────────────── */
function _renderUpcomingList() {
  const el  = document.getElementById('calUpcomingList');
  if (!el) return;

  const now = new Date();
  const upcoming = calEvents
    .filter(ev => {
      if (!ev.date_debut) return false;
      if (calEgliseFilter && ev.eglise_id !== calEgliseFilter) return false;
      return new Date(ev.date_debut) >= now;
    })
    .sort((a, b) => new Date(a.date_debut) - new Date(b.date_debut))
    .slice(0, 8);

  if (!upcoming.length) {
    el.innerHTML = '<p class="text-center text-muted" style="padding:16px">Aucun événement à venir</p>';
    return;
  }

  el.innerHTML = upcoming.map(ev => {
    const c   = _typeColor(ev.type_evenement);
    const egl = calEglises.find(e => e.id === ev.eglise_id);
    return `
      <div onclick="showEventDetail('${ev.id}')"
        style="display:flex;align-items:center;gap:10px;padding:10px 16px;
          border-bottom:1px solid var(--border);cursor:pointer;
          transition:background .15s" onmouseover="this.style.background='#f8f0fd'"
          onmouseout="this.style.background=''">
        <div style="width:6px;height:40px;border-radius:3px;background:${c.text};flex-shrink:0"></div>
        <div style="flex:1;overflow:hidden">
          <div style="font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            ${ev.titre}
          </div>
          <div style="font-size:11px;color:var(--text-muted)">
            ${egl ? egl.nom : ''} · ${ev.lieu || ''}
          </div>
        </div>
        <div style="font-size:11px;font-weight:700;color:${c.text};text-align:right;flex-shrink:0">
          ${formatDateShort(ev.date_debut)}
        </div>
      </div>`;
  }).join('');
}

/* ─── Navigation ─────────────────────────────────────────────── */
function calNavigate(dir) {
  calMonth += dir;
  if (calMonth > 11) { calMonth = 0;  calYear++; }
  if (calMonth < 0)  { calMonth = 11; calYear--; }
  renderCalMonth();
}

function calGoToday() {
  calYear  = new Date().getFullYear();
  calMonth = new Date().getMonth();
  renderCalMonth();
}

/* ─── Détail événement ───────────────────────────────────────── */
async function showEventDetail(id) {
  try {
    const [ev, egls] = await Promise.all([
      API.getById('evenements', id),
      API.getAll('eglises')
    ]);
    const egl = egls.data.find(e => e.id === ev.eglise_id);
    const c   = _typeColor(ev.type_evenement);

    let specificHTML = '';
    if (ev.nom_bebe || ev.nom_pere || ev.nom_mere) {
      specificHTML += `
        <div style="background:#e3f2fd;border-radius:8px;padding:12px;margin-top:12px">
          <div style="font-weight:700;font-size:12px;margin-bottom:8px;color:#1565C0">
            <i class="fas fa-baby"></i> Informations Sortie d'enfant
          </div>
          ${ev.nom_bebe    ? `<p>👶 Bébé : <strong>${ev.nom_bebe}</strong></p>` : ''}
          ${ev.nom_pere    ? `<p>👨 Père : ${ev.nom_pere}</p>` : ''}
          ${ev.nom_mere    ? `<p>👩 Mère : ${ev.nom_mere}</p>` : ''}
        </div>`;
    }
    if (ev.nom_defunt || ev.nom_famille) {
      specificHTML += `
        <div style="background:#f3e5f5;border-radius:8px;padding:12px;margin-top:12px">
          <div style="font-weight:700;font-size:12px;margin-bottom:8px;color:#6A1B9A">
            <i class="fas fa-cross"></i> Informations Funèbres
          </div>
          ${ev.nom_defunt  ? `<p>✝ Défunt(e) : <strong>${ev.nom_defunt}</strong></p>` : ''}
          ${ev.nom_famille ? `<p>👨‍👩‍👧‍👦 Famille : ${ev.nom_famille}</p>` : ''}
        </div>`;
    }

    const html = `
      <div style="padding:6px 0">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
          <div style="width:48px;height:48px;border-radius:12px;
            background:${c.bg};display:flex;align-items:center;justify-content:center">
            <i class="fas fa-calendar" style="font-size:20px;color:${c.text}"></i>
          </div>
          <div>
            <h3 style="margin:0;font-size:18px">${ev.titre}</h3>
            <span style="padding:3px 10px;border-radius:20px;font-size:11px;
              background:${c.bg};color:${c.text};font-weight:700">${ev.type_evenement || '—'}</span>
          </div>
        </div>
        <div class="detail-grid">
          <div class="detail-item"><label>Église</label><p>${egl ? egl.nom : '—'}</p></div>
          <div class="detail-item"><label>Lieu</label><p>${ev.lieu || '—'}</p></div>
          <div class="detail-item"><label>Date de début</label><p>${formatDate(ev.date_debut)}</p></div>
          <div class="detail-item"><label>Date de fin</label><p>${formatDate(ev.date_fin)}</p></div>
          <div class="detail-item"><label>Responsable</label><p>${ev.responsable || '—'}</p></div>
        </div>
        ${ev.description ? `<div class="mt-2" style="font-size:13px;color:var(--text)">${ev.description}</div>` : ''}
        ${specificHTML}
        ${Auth.canWrite() ? `
          <div style="margin-top:16px;display:flex;gap:8px">
            <button class="btn btn-sm btn-primary" onclick="closeModal();showEvenementForm('${ev.id}')">
              <i class="fas fa-edit"></i> Modifier
            </button>
          </div>` : ''}
      </div>`;

    openModal(ev.titre, html, '', null, 'large');
  } catch (err) {
    showToast('Erreur : ' + err.message, 'error');
  }
}
