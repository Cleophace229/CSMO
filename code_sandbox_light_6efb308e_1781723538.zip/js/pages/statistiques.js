/**
 * Statistiques Page - Graphiques avancés avec Chart.js
 */
let chartsInstances = {};

async function renderStatistiques() {
  setBreadcrumb([{ label: I18n.t('stats.title') }]);
  const content = document.getElementById('pageContent');

  content.innerHTML = `
    <div class="page-header">
      <div class="page-header-left">
        <h2><i class="fas fa-chart-bar" style="color:var(--primary);margin-right:10px"></i>${I18n.t('stats.title')}</h2>
        <p>${I18n.lang==='en'?'Complete parish census analysis':'Analyse complète du recensement paroissial'}</p>
      </div>
    </div>
    <div class="loading-spinner"><i class="fas fa-circle-notch fa-spin"></i><p>${I18n.t('msg.loading')}</p></div>
  `;

  try {
    const [regs, srs, egls, mems, evs, cots, enfantsRes, encadreursRes, promosRes] = await Promise.all([
      API.getAll('regions'),
      API.getAll('sous_regions'),
      API.getAll('eglises'),
      API.getAll('membres'),
      API.getAll('evenements'),
      API.getAll('cotisations'),
      API.getAll('enfants_aj',    { limit: 1000 }).catch(() => ({ data: [] })),
      API.getAll('encadreurs_aj', { limit: 500  }).catch(() => ({ data: [] })),
      API.getAll('promotions',    { limit: 2000 }).catch(() => ({ data: [] }))
    ]);

    // Grades
    const grades = {};
    mems.data.forEach(m => { const g = m.grade || 'Non défini'; grades[g] = (grades[g] || 0) + 1; });

    // Rôles
    const roles = {};
    mems.data.forEach(m => { const r = m.role || 'Non défini'; roles[r] = (roles[r] || 0) + 1; });

    // Membres par église
    const memsByEgl = {};
    egls.data.forEach(e => { memsByEgl[e.nom] = mems.data.filter(m => m.eglise_id === e.id).length; });

    // Membres par région
    const memsByReg = {};
    regs.data.forEach(r => {
      const regEgls = egls.data.filter(e => e.region_id === r.id);
      memsByReg[r.nom] = mems.data.filter(m => regEgls.some(e => e.id === m.eglise_id)).length;
    });

    // Cotisations par statut
    const cotStatuts = { 'Payé': 0, 'En retard': 0 };
    cots.data.forEach(c => {
      if (c.statut === 'payé') cotStatuts['Payé'] += Number(c.montant || 0);
      else if (c.statut === 'en retard') cotStatuts['En retard'] += Number(c.montant || 0);
    });

    // Événements par type
    const evTypes = {};
    evs.data.forEach(e => { const t = e.type_evenement || 'Autre'; evTypes[t] = (evTypes[t] || 0) + 1; });

    // Statuts membres
    const memStatuts = { 'Actif': 0, 'Inactif': 0, 'Suspendu': 0 };
    mems.data.forEach(m => {
      if (m.statut === 'actif') memStatuts['Actif']++;
      else if (m.statut === 'inactif') memStatuts['Inactif']++;
      else if (m.statut === 'suspendu') memStatuts['Suspendu']++;
    });

    /* ── Calculs AJ ── */
    const enfantsData    = enfantsRes.data    || [];
    const encadreursData = encadreursRes.data || [];
    const totalEnfants    = enfantsData.length;
    const totalEncadreurs = encadreursData.length;
    const garcons = enfantsData.filter(x => x.sexe === 'garcon').length;
    const filles  = enfantsData.filter(x => x.sexe === 'fille').length;
    const enfantsByEgl   = {};
    const encadreursByEgl = {};
    egls.data.forEach(e => {
      enfantsByEgl[e.nom]    = enfantsData.filter(x => x.eglise_id === e.id).length;
      encadreursByEgl[e.nom] = encadreursData.filter(x => x.eglise_id === e.id).length;
    });

    const palettePurple  = ['#6C3483', '#9B59B6', '#D7BDE2', '#E8DAEF', '#A569BD', '#76448A', '#5B2C6F', '#4A235A', '#C39BD3', '#7D3C98'];
    const paletteMulti  = ['#6C3483', '#1A5276', '#117A65', '#D68910', '#C0392B', '#2471A3', '#1E8449', '#D4AC0D', '#7F8C8D', '#884EA0'];
    const paletteCont   = ['#10B981', '#3B82F6', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4', '#EC4899'];

    /* ── Stats par continent ── */
    const eglsByCont = {};
    const memsByCont = {};
    egls.data.forEach(e => {
      const cont = e.continent || 'Non défini';
      eglsByCont[cont] = (eglsByCont[cont] || 0) + 1;
      const eglMems = mems.data.filter(m => m.eglise_id === e.id).length;
      memsByCont[cont] = (memsByCont[cont] || 0) + eglMems;
    });
    const continentsSorted = Object.keys(eglsByCont).sort((a, b) => eglsByCont[b] - eglsByCont[a]);
    const totalContinents = continentsSorted.length;

    /* ── Stats par pays ── */
    const memsByPays = {};
    const eglsByPays = {};
    egls.data.forEach(e => {
      const pays = e.pays || 'Non défini';
      eglsByPays[pays] = (eglsByPays[pays] || 0) + 1;
      const eglMems = mems.data.filter(m => m.eglise_id === e.id).length;
      memsByPays[pays] = (memsByPays[pays] || 0) + eglMems;
    });
    const paysSorted = Object.keys(memsByPays).sort((a, b) => memsByPays[b] - memsByPays[a]).slice(0, 15);
    const totalPays  = Object.keys(memsByPays).length;

    /* ── Stats par sous-région ── */
    const memsBySR = {};
    const eglsBySR = {};
    srs.data.forEach(sr => {
      const srEgls = egls.data.filter(e => e.sous_region_id === sr.id);
      eglsBySR[sr.nom] = srEgls.length;
      memsBySR[sr.nom] = mems.data.filter(m => srEgls.some(e => e.id === m.eglise_id)).length;
    });
    const srSorted = Object.keys(memsBySR).sort((a, b) => memsBySR[b] - memsBySR[a]).slice(0, 12);

    /* ── Stats promotions ── */
    const promosData = promosRes.data || [];
    const promosByGrade = {};
    promosData.forEach(p => {
      const g = p.nouveau_grade || 'N/D';
      promosByGrade[g] = (promosByGrade[g] || 0) + 1;
    });
    const promoGradesSorted = Object.keys(promosByGrade).sort((a, b) => promosByGrade[b] - promosByGrade[a]).slice(0, 10);
    /* Promotions par mois (12 derniers mois) */
    const promoByMonth = {};
    const now12 = new Date();
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now12.getFullYear(), now12.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      promoByMonth[key] = 0;
    }
    promosData.forEach(p => {
      if (p.date_promotion) {
        const key = p.date_promotion.slice(0, 7);
        if (key in promoByMonth) promoByMonth[key]++;
      }
    });

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2><i class="fas fa-chart-bar" style="color:var(--primary);margin-right:10px"></i>Statistiques Avancées</h2>
          <p>Analyse complète du recensement paroissial</p>
        </div>
      </div>

      <!-- Summary cards — enrichies avec continents/pays -->
      <div class="stats-grid" style="margin-bottom:28px">
        <div class="stat-card" style="border-left:4px solid #10B981">
          <div class="stat-icon" style="background:rgba(16,185,129,.12);color:#10B981">
            <i class="fas fa-earth-africa"></i></div>
          <div class="stat-info"><h3>${totalContinents}</h3><p>Continents</p></div></div>
        <div class="stat-card" style="border-left:4px solid #3B82F6">
          <div class="stat-icon" style="background:rgba(59,130,246,.12);color:#3B82F6">
            <i class="fas fa-flag"></i></div>
          <div class="stat-info"><h3>${totalPays}</h3><p>Pays représentés</p></div></div>
        <div class="stat-card info"><div class="stat-icon"><i class="fas fa-globe-africa"></i></div>
          <div class="stat-info"><h3>${regs.total}</h3><p>Régions</p></div></div>
        <div class="stat-card"><div class="stat-icon"><i class="fas fa-map-marked-alt"></i></div>
          <div class="stat-info"><h3>${srs.total}</h3><p>Sous-régions</p></div></div>
        <div class="stat-card success"><div class="stat-icon"><i class="fas fa-church"></i></div>
          <div class="stat-info"><h3>${egls.total}</h3><p>Églises</p></div></div>
        <div class="stat-card gold"><div class="stat-icon"><i class="fas fa-users"></i></div>
          <div class="stat-info"><h3>${mems.total}</h3><p>Membres</p></div></div>
        <div class="stat-card" style="border-left:4px solid #8B5CF6">
          <div class="stat-icon" style="background:rgba(139,92,246,.12);color:#8B5CF6">
            <i class="fas fa-level-up-alt"></i></div>
          <div class="stat-info"><h3>${promosData.length}</h3><p>Promotions</p></div></div>
      </div>

      <!-- Bannière AJ -->
      <div style="background:linear-gradient(135deg,#4f46e5,#6d28d9,#7c3aed);
        border-radius:14px;padding:20px 24px;margin-bottom:24px;color:#fff">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
          <i class="fas fa-child" style="font-size:22px"></i>
          <h3 style="margin:0;font-size:16px;font-weight:700">
            Enfants de l'Ami de Jésus (AJ) — Vue globale
          </h3>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:14px">
          <div style="background:rgba(255,255,255,.18);border-radius:10px;padding:14px;text-align:center">
            <div style="font-size:28px;font-weight:800">${totalEnfants}</div>
            <div style="font-size:12px;opacity:.85">Enfants inscrits</div>
          </div>
          <div style="background:rgba(255,255,255,.18);border-radius:10px;padding:14px;text-align:center">
            <div style="font-size:28px;font-weight:800">${totalEncadreurs}</div>
            <div style="font-size:12px;opacity:.85">Encadreurs AJ</div>
          </div>
          <div style="background:rgba(255,255,255,.18);border-radius:10px;padding:14px;text-align:center">
            <div style="font-size:28px;font-weight:800">${garcons}</div>
            <div style="font-size:12px;opacity:.85">♂ Garçons</div>
          </div>
          <div style="background:rgba(255,255,255,.18);border-radius:10px;padding:14px;text-align:center">
            <div style="font-size:28px;font-weight:800">${filles}</div>
            <div style="font-size:12px;opacity:.85">♀ Filles</div>
          </div>
          <div style="background:rgba(255,255,255,.18);border-radius:10px;padding:14px;text-align:center">
            <div style="font-size:28px;font-weight:800">
              ${egls.data.filter(e => enfantsByEgl[e.nom] > 0).length}
            </div>
            <div style="font-size:12px;opacity:.85">Paroisses avec AJ</div>
          </div>
          <div style="background:rgba(255,255,255,.18);border-radius:10px;padding:14px;text-align:center">
            <div style="font-size:28px;font-weight:800">
              ${totalEncadreurs > 0 ? (totalEnfants / totalEncadreurs).toFixed(1) : '—'}
            </div>
            <div style="font-size:12px;opacity:.85">Enfants / encadreur</div>
          </div>
        </div>
      </div>

      <div class="grid-2">
        <!-- Membres par grade -->
        <div class="card">
          <div class="card-header"><h3><i class="fas fa-layer-group"></i> Répartition par grade</h3></div>
          <div class="card-body"><div style="height:280px"><canvas id="chartGrades"></canvas></div></div>
        </div>

        <!-- Membres par rôle -->
        <div class="card">
          <div class="card-header"><h3><i class="fas fa-user-tag"></i> Répartition par rôle</h3></div>
          <div class="card-body"><div style="height:280px"><canvas id="chartRoles"></canvas></div></div>
        </div>

        <!-- Membres par église (bar) -->
        <div class="card">
          <div class="card-header"><h3><i class="fas fa-church"></i> Membres par église</h3></div>
          <div class="card-body"><div style="height:280px"><canvas id="chartMemsEgl"></canvas></div></div>
        </div>

        <!-- Cotisations statut -->
        <div class="card">
          <div class="card-header"><h3><i class="fas fa-hand-holding-usd"></i> Cotisations (FC)</h3></div>
          <div class="card-body"><div style="height:280px"><canvas id="chartCots"></canvas></div></div>
        </div>

        <!-- Événements par type -->
        <div class="card">
          <div class="card-header"><h3><i class="fas fa-calendar-alt"></i> Événements par type</h3></div>
          <div class="card-body"><div style="height:280px"><canvas id="chartEvs"></canvas></div></div>
        </div>

        <!-- Statut membres -->
        <div class="card">
          <div class="card-header"><h3><i class="fas fa-user-check"></i> Statuts des membres</h3></div>
          <div class="card-body"><div style="height:280px"><canvas id="chartStatuts"></canvas></div></div>
        </div>
      </div>

      <!-- Membres par région (full width) -->
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-globe-africa"></i> Membres par région</h3></div>
        <div class="card-body"><div style="height:260px"><canvas id="chartMemsReg"></canvas></div></div>
      </div>

      <!-- Graphiques AJ -->
      <div class="grid-2" style="margin-top:24px">
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-child" style="color:#6d28d9"></i> Enfants AJ par paroisse</h3>
          </div>
          <div class="card-body"><div style="height:280px"><canvas id="chartAJEnfants"></canvas></div></div>
        </div>
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-user-tie" style="color:#6d28d9"></i> Encadreurs AJ par paroisse</h3>
          </div>
          <div class="card-body"><div style="height:280px"><canvas id="chartAJEncadreurs"></canvas></div></div>
        </div>
      </div>

      <!-- ══════════════ SECTION GÉOGRAPHIE ══════════════ -->
      <div style="margin-top:32px;margin-bottom:16px;padding-bottom:8px;border-bottom:2px solid var(--border)">
        <h3 style="margin:0;font-size:16px;font-weight:700;color:var(--primary)">
          <i class="fas fa-globe" style="margin-right:8px"></i>
          Répartition Géographique
        </h3>
        <p style="margin:4px 0 0;font-size:12px;color:var(--text-muted)">Statistiques par continent, pays et sous-région</p>
      </div>

      <!-- Continents : 2 charts côte à côte -->
      <div class="grid-2" style="margin-bottom:24px">
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-earth-africa" style="color:#10B981"></i> Paroisses par continent</h3>
          </div>
          <div class="card-body"><div style="height:280px"><canvas id="chartEglsByCont"></canvas></div></div>
        </div>
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-users" style="color:#3B82F6"></i> Membres par continent</h3>
          </div>
          <div class="card-body"><div style="height:280px"><canvas id="chartMemsByCont"></canvas></div></div>
        </div>
      </div>

      <!-- Top pays (full width) -->
      <div class="card" style="margin-bottom:24px">
        <div class="card-header">
          <h3><i class="fas fa-flag" style="color:#F59E0B"></i> Top ${paysSorted.length} pays — Membres</h3>
        </div>
        <div class="card-body"><div style="height:${Math.max(240, paysSorted.length * 28)}px"><canvas id="chartMemsByPays"></canvas></div></div>
      </div>

      <!-- Sous-régions (full width) -->
      <div class="card" style="margin-bottom:24px">
        <div class="card-header">
          <h3><i class="fas fa-map-marked-alt" style="color:#8B5CF6"></i> Top ${srSorted.length} sous-régions — Membres</h3>
        </div>
        <div class="card-body"><div style="height:${Math.max(200, srSorted.length * 26)}px"><canvas id="chartMemsBySR"></canvas></div></div>
      </div>

      <!-- ══════════════ SECTION PROMOTIONS ══════════════ -->
      ${promosData.length > 0 ? `
      <div style="margin-top:32px;margin-bottom:16px;padding-bottom:8px;border-bottom:2px solid var(--border)">
        <h3 style="margin:0;font-size:16px;font-weight:700;color:#8B5CF6">
          <i class="fas fa-level-up-alt" style="margin-right:8px"></i>
          Promotions de Grade
        </h3>
        <p style="margin:4px 0 0;font-size:12px;color:var(--text-muted)">Analyse des changements de grade</p>
      </div>
      <div class="grid-2" style="margin-bottom:24px">
        <div class="card">
          <div class="card-header"><h3><i class="fas fa-medal" style="color:#8B5CF6"></i> Top grades promus</h3></div>
          <div class="card-body"><div style="height:280px"><canvas id="chartPromoGrades"></canvas></div></div>
        </div>
        <div class="card">
          <div class="card-header"><h3><i class="fas fa-chart-line" style="color:#8B5CF6"></i> Promotions / mois (12 derniers mois)</h3></div>
          <div class="card-body"><div style="height:280px"><canvas id="chartPromoMois"></canvas></div></div>
        </div>
      </div>` : ''}
    `;

    // Destroy old charts
    Object.values(chartsInstances).forEach(c => c.destroy());
    chartsInstances = {};

    const chartDefaults = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { labels: { font: { family: 'Inter', size: 12 } } } }
    };

    // Grades (doughnut)
    chartsInstances.grades = new Chart(document.getElementById('chartGrades'), {
      type: 'doughnut',
      data: { labels: Object.keys(grades), datasets: [{ data: Object.values(grades), backgroundColor: palettePurple }] },
      options: { ...chartDefaults, cutout: '60%' }
    });

    // Rôles (pie)
    chartsInstances.roles = new Chart(document.getElementById('chartRoles'), {
      type: 'pie',
      data: { labels: Object.keys(roles), datasets: [{ data: Object.values(roles), backgroundColor: paletteMulti }] },
      options: chartDefaults
    });

    // Membres par église (bar)
    chartsInstances.memsEgl = new Chart(document.getElementById('chartMemsEgl'), {
      type: 'bar',
      data: {
        labels: Object.keys(memsByEgl),
        datasets: [{ label: 'Membres', data: Object.values(memsByEgl), backgroundColor: '#6C3483', borderRadius: 6 }]
      },
      options: { ...chartDefaults, plugins: { ...chartDefaults.plugins, legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
    });

    // Cotisations (bar groupé)
    chartsInstances.cots = new Chart(document.getElementById('chartCots'), {
      type: 'bar',
      data: {
        labels: Object.keys(cotStatuts),
        datasets: [{ label: 'Montant (FC)', data: Object.values(cotStatuts), backgroundColor: ['#1E8449', '#D68910', '#C0392B'], borderRadius: 6 }]
      },
      options: { ...chartDefaults, plugins: { ...chartDefaults.plugins, legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });

    // Événements (doughnut)
    chartsInstances.evs = new Chart(document.getElementById('chartEvs'), {
      type: 'doughnut',
      data: { labels: Object.keys(evTypes), datasets: [{ data: Object.values(evTypes), backgroundColor: paletteMulti }] },
      options: { ...chartDefaults, cutout: '55%' }
    });

    // Statuts membres (pie)
    chartsInstances.statuts = new Chart(document.getElementById('chartStatuts'), {
      type: 'pie',
      data: { labels: Object.keys(memStatuts), datasets: [{ data: Object.values(memStatuts), backgroundColor: ['#1E8449', '#7F8C8D', '#D68910'] }] },
      options: chartDefaults
    });

    // Membres par région (horizontal bar)
    chartsInstances.memsReg = new Chart(document.getElementById('chartMemsReg'), {
      type: 'bar',
      data: {
        labels: Object.keys(memsByReg),
        datasets: [{ label: 'Membres par région', data: Object.values(memsByReg), backgroundColor: paletteMulti.slice(0, regs.total), borderRadius: 6 }]
      },
      options: {
        ...chartDefaults,
        indexAxis: 'y',
        plugins: { ...chartDefaults.plugins, legend: { display: false } },
        scales: { x: { beginAtZero: true, ticks: { stepSize: 1 } } }
      }
    });

    /* ── Graphiques AJ ── */
    const eglAvecAJ       = egls.data.filter(e => enfantsByEgl[e.nom] > 0 || encadreursByEgl[e.nom] > 0);
    const ajLabels        = eglAvecAJ.length ? eglAvecAJ.map(e => e.nom)                 : ['Aucune donnée'];
    const ajEnfantsVals   = eglAvecAJ.length ? eglAvecAJ.map(e => enfantsByEgl[e.nom]    || 0) : [0];
    const ajEncadreursVals= eglAvecAJ.length ? eglAvecAJ.map(e => encadreursByEgl[e.nom] || 0) : [0];

    chartsInstances.ajEnfants = new Chart(document.getElementById('chartAJEnfants'), {
      type: 'bar',
      data: {
        labels: ajLabels,
        datasets: [{ label: 'Enfants AJ', data: ajEnfantsVals, backgroundColor: '#6d28d9', borderRadius: 6 }]
      },
      options: {
        ...chartDefaults,
        plugins: { ...chartDefaults.plugins, legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
      }
    });

    chartsInstances.ajEncadreurs = new Chart(document.getElementById('chartAJEncadreurs'), {
      type: 'bar',
      data: {
        labels: ajLabels,
        datasets: [{ label: 'Encadreurs AJ', data: ajEncadreursVals, backgroundColor: '#0f3460', borderRadius: 6 }]
      },
      options: {
        ...chartDefaults,
        plugins: { ...chartDefaults.plugins, legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
      }
    });

    /* ── Graphiques Géographie ── */

    // Paroisses par continent (doughnut)
    chartsInstances.eglsByCont = new Chart(document.getElementById('chartEglsByCont'), {
      type: 'doughnut',
      data: {
        labels: continentsSorted,
        datasets: [{
          data: continentsSorted.map(c => eglsByCont[c]),
          backgroundColor: paletteCont.slice(0, continentsSorted.length)
        }]
      },
      options: { ...chartDefaults, cutout: '58%' }
    });

    // Membres par continent (bar)
    chartsInstances.memsByCont = new Chart(document.getElementById('chartMemsByCont'), {
      type: 'bar',
      data: {
        labels: continentsSorted,
        datasets: [{
          label: 'Membres',
          data: continentsSorted.map(c => memsByCont[c]),
          backgroundColor: paletteCont.slice(0, continentsSorted.length),
          borderRadius: 6
        }]
      },
      options: {
        ...chartDefaults,
        plugins: { ...chartDefaults.plugins, legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
      }
    });

    // Top pays — membres (horizontal bar)
    chartsInstances.memsByPays = new Chart(document.getElementById('chartMemsByPays'), {
      type: 'bar',
      data: {
        labels: paysSorted,
        datasets: [{
          label: 'Membres',
          data: paysSorted.map(p => memsByPays[p]),
          backgroundColor: '#F59E0B',
          borderRadius: 5
        }]
      },
      options: {
        ...chartDefaults,
        indexAxis: 'y',
        plugins: { ...chartDefaults.plugins, legend: { display: false } },
        scales: { x: { beginAtZero: true, ticks: { stepSize: 1 } } }
      }
    });

    // Sous-régions — membres (horizontal bar)
    chartsInstances.memsBySR = new Chart(document.getElementById('chartMemsBySR'), {
      type: 'bar',
      data: {
        labels: srSorted,
        datasets: [{
          label: 'Membres',
          data: srSorted.map(s => memsBySR[s]),
          backgroundColor: '#8B5CF6',
          borderRadius: 5
        }]
      },
      options: {
        ...chartDefaults,
        indexAxis: 'y',
        plugins: { ...chartDefaults.plugins, legend: { display: false } },
        scales: { x: { beginAtZero: true, ticks: { stepSize: 1 } } }
      }
    });

    /* ── Graphiques Promotions ── */
    if (promosData.length > 0 && document.getElementById('chartPromoGrades')) {
      // Top grades promus (doughnut)
      chartsInstances.promoGrades = new Chart(document.getElementById('chartPromoGrades'), {
        type: 'doughnut',
        data: {
          labels: promoGradesSorted,
          datasets: [{
            data: promoGradesSorted.map(g => promosByGrade[g]),
            backgroundColor: palettePurple.slice(0, promoGradesSorted.length)
          }]
        },
        options: { ...chartDefaults, cutout: '55%' }
      });

      // Promotions par mois (line)
      const monthLabels = Object.keys(promoByMonth).map(k => {
        const [y, m] = k.split('-');
        return new Date(y, m - 1, 1).toLocaleDateString('fr-FR', { month: 'short', year: '2-digit' });
      });
      chartsInstances.promoMois = new Chart(document.getElementById('chartPromoMois'), {
        type: 'line',
        data: {
          labels: monthLabels,
          datasets: [{
            label: 'Promotions',
            data: Object.values(promoByMonth),
            borderColor: '#8B5CF6',
            backgroundColor: 'rgba(139,92,246,.12)',
            borderWidth: 2,
            tension: 0.35,
            fill: true,
            pointRadius: 4,
            pointBackgroundColor: '#8B5CF6'
          }]
        },
        options: {
          ...chartDefaults,
          plugins: { ...chartDefaults.plugins, legend: { display: false } },
          scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
        }
      });
    }

  } catch (err) {
    content.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erreur</h3><p>${err.message}</p></div>`;
  }
}
