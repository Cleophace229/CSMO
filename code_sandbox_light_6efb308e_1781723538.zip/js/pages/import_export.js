/**
 * Import / Export Page
 */

// ============================
// EXPORT PAGE
// ============================
async function renderExport() {
  setBreadcrumb([{ label: I18n.t('export.title') }]);
  const content = document.getElementById('pageContent');

  const egls = await API.getAll('eglises');

  content.innerHTML = `
    <div class="page-header">
      <div class="page-header-left">
        <h2><i class="fas fa-file-export" style="color:var(--success);margin-right:10px"></i>Export & Impression</h2>
        <p>Exporter les données du recensement en PDF ou Excel</p>
      </div>
    </div>

    <div class="grid-2">
      <!-- Export PDF -->
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-file-pdf" style="color:var(--danger)"></i> Export PDF</h3></div>
        <div class="card-body">
          <div class="form-group">
            <label>Type de rapport</label>
            <select class="form-control" id="pdfType">
              <option value="all_membres">Liste complète des membres</option>
              <option value="eglise">Liste d'une église</option>
              <option value="region">Rapport par région</option>
              <option value="cotisations">Rapport des cotisations</option>
            </select>
          </div>
          <div class="form-group" id="pdfEglGroup">
            <label>Église (si applicable)</label>
            <select class="form-control" id="pdfEglise">
              <option value="">— Toutes —</option>
              ${egls.data.map(e => `<option value="${e.id}">${e.nom}</option>`).join('')}
            </select>
          </div>
          <div class="mt-2" style="display:flex;gap:8px">
            <button class="btn btn-danger" onclick="exportPDF()"><i class="fas fa-file-pdf"></i> Générer PDF</button>
            <button class="btn btn-outline" onclick="printPage()"><i class="fas fa-print"></i> Imprimer</button>
          </div>
        </div>
      </div>

      <!-- Export Excel -->
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-file-excel" style="color:var(--success)"></i> Export Excel</h3></div>
        <div class="card-body">
          <div class="form-group">
            <label>Données à exporter</label>
            <select class="form-control" id="xlsxType">
              <option value="membres">Membres & Fidèles</option>
              <option value="eglises">Églises Paroissiales</option>
              <option value="regions">Régions & Sous-régions</option>
              <option value="cotisations">Cotisations</option>
              <option value="evenements">Événements</option>
              <option value="historique">Historique des mouvements</option>
            </select>
          </div>
          <div class="form-group">
            <label>Église (filtre optionnel)</label>
            <select class="form-control" id="xlsxEglise">
              <option value="">— Toutes —</option>
              ${egls.data.map(e => `<option value="${e.id}">${e.nom}</option>`).join('')}
            </select>
          </div>
          <div class="mt-2">
            <button class="btn btn-success" onclick="exportExcel()"><i class="fas fa-file-excel"></i> Télécharger Excel</button>
          </div>
        </div>
      </div>

      <!-- Impression par église -->
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-print"></i> Impression par église</h3></div>
        <div class="card-body">
          <p style="color:var(--text-muted);font-size:13px;margin-bottom:12px">Imprimer la liste complète des membres d'une église paroissiale.</p>
          <div class="form-group">
            <label>Sélectionner l'église</label>
            <select class="form-control" id="printEglSelect">
              ${egls.data.map(e => `<option value="${e.id}">${e.nom}</option>`).join('')}
            </select>
          </div>
          <button class="btn btn-primary" onclick="exportEglisePDF(document.getElementById('printEglSelect').value)">
            <i class="fas fa-print"></i> Imprimer la liste
          </button>
        </div>
      </div>

      <!-- Export complet -->
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-database"></i> Export complet</h3></div>
        <div class="card-body">
          <p style="color:var(--text-muted);font-size:13px;margin-bottom:12px">Exporter toutes les données du système en un seul fichier Excel (toutes feuilles).</p>
          <button class="btn btn-gold" onclick="exportAll()">
            <i class="fas fa-file-export"></i> Exporter tout (Excel)
          </button>
        </div>
      </div>
    </div>
  `;
}

// ============================
// IMPORT PAGE
// ============================
async function renderImport() {
  setBreadcrumb([{ label: I18n.t('import.title') }]);
  const content = document.getElementById('pageContent');

  const egls = await API.getAll('eglises');

  content.innerHTML = `
    <div class="page-header">
      <div class="page-header-left">
        <h2><i class="fas fa-file-import" style="color:var(--primary);margin-right:10px"></i>Import en masse via CSV</h2>
        <p>Importez des membres ou des données depuis un fichier CSV</p>
      </div>
    </div>

    <div class="grid-2">
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-upload"></i> Importer des membres</h3></div>
        <div class="card-body">
          <div class="form-group">
            <label>Église de destination <span style="color:var(--danger)">*</span></label>
            <select class="form-control" id="importEglise">
              <option value="">— Choisir —</option>
              ${egls.data.map(e => `<option value="${e.id}">${e.nom}</option>`).join('')}
            </select>
          </div>

          <div class="drop-zone" id="csvDropZone" onclick="document.getElementById('csvFileInput').click()">
            <i class="fas fa-cloud-upload-alt"></i>
            <h3>Glisser-déposer un fichier CSV</h3>
            <p>ou cliquer pour sélectionner</p>
          </div>
          <input type="file" id="csvFileInput" accept=".csv" style="display:none" onchange="handleCSVFile(this)" />

          <div id="csvPreview" style="margin-top:16px"></div>

          <div class="mt-2" id="importActions" style="display:none">
            <button class="btn btn-primary" onclick="executeImport()"><i class="fas fa-upload"></i> Importer les données</button>
            <button class="btn btn-secondary" onclick="clearImport()"><i class="fas fa-times"></i> Annuler</button>
          </div>
        </div>
      </div>

      <!-- Template CSV -->
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-file-csv"></i> Format CSV requis</h3></div>
        <div class="card-body">
          <p style="color:var(--text-muted);font-size:13px;margin-bottom:12px">Le fichier CSV doit contenir les colonnes suivantes (séparateur : virgule) :</p>

          <div style="background:var(--bg);border-radius:8px;padding:12px;font-family:monospace;font-size:12px;margin-bottom:12px;overflow-x:auto">
            prenom,nom,telephone,email,grade,role,date_naissance,date_adhesion,statut
          </div>

          <p style="font-size:12px;color:var(--text-muted);margin-bottom:8px"><strong>Valeurs acceptées :</strong></p>
          <ul style="font-size:12px;color:var(--text-muted);padding-left:16px;line-height:2">
            <li><strong>grade :</strong> Catéchumène, Fidèle simple, Lecteur, Acolyte, Diacre, Prêtre, Senior, Notaire</li>
            <li><strong>role :</strong> Chargé paroissial, Secrétaire, Secrétaire adjoint, Maître de chœurs, Adjoint chœurs, Fidèle</li>
            <li><strong>statut :</strong> actif, inactif, suspendu</li>
            <li><strong>dates :</strong> format AAAA-MM-JJ</li>
          </ul>

          <button class="btn btn-outline-primary mt-2" onclick="downloadCSVTemplate()">
            <i class="fas fa-download"></i> Télécharger le modèle CSV
          </button>
        </div>
      </div>
    </div>
  `;

  // Drag & Drop
  const dropZone = document.getElementById('csvDropZone');
  dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.style.background = '#d5c8f0'; });
  dropZone.addEventListener('dragleave', () => { dropZone.style.background = ''; });
  dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.style.background = '';
    const file = e.dataTransfer.files[0];
    if (file) processCSVFile(file);
  });
}

let csvImportData = [];

function handleCSVFile(input) {
  const file = input.files[0];
  if (file) processCSVFile(file);
}

function processCSVFile(file) {
  const reader = new FileReader();
  reader.onload = function(e) {
    const text = e.target.result;
    const lines = text.trim().split('\n');
    if (lines.length < 2) { showToast('Fichier CSV vide ou invalide', 'error'); return; }

    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    csvImportData = lines.slice(1).map(line => {
      const vals = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
      const obj = {};
      headers.forEach((h, i) => { obj[h] = vals[i] || ''; });
      return obj;
    }).filter(r => r.prenom || r.nom);

    // Preview
    const preview = document.getElementById('csvPreview');
    preview.innerHTML = `
      <div style="font-size:13px;font-weight:600;margin-bottom:8px;color:var(--success)"><i class="fas fa-check-circle"></i> ${csvImportData.length} ligne(s) détectée(s)</div>
      <div class="table-wrapper" style="max-height:220px;overflow-y:auto">
        <table>
          <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead>
          <tbody>${csvImportData.slice(0, 10).map(r => `<tr>${headers.map(h => `<td>${r[h] || '—'}</td>`).join('')}</tr>`).join('')}</tbody>
        </table>
      </div>
      ${csvImportData.length > 10 ? `<p style="font-size:12px;color:var(--text-muted);margin-top:6px">... et ${csvImportData.length - 10} autre(s)</p>` : ''}
    `;
    document.getElementById('importActions').style.display = '';
  };
  reader.readAsText(file, 'UTF-8');
}

async function executeImport() {
  const egliseId = document.getElementById('importEglise').value;
  if (!egliseId) { showToast('Veuillez choisir une église', 'warning'); return; }
  if (csvImportData.length === 0) { showToast('Aucune donnée à importer', 'warning'); return; }

  const btn = event.target;
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Importation...';

  let success = 0, errors = 0;
  for (const row of csvImportData) {
    try {
      await API.create('membres', {
        id: generateId('mb'),
        prenom: row.prenom || '',
        nom: row.nom || '',
        telephone: row.telephone || '',
        email: row.email || '',
        grade: row.grade || 'Fidèle simple',
        role: row.role || 'Fidèle',
        date_naissance: row.date_naissance || '',
        date_adhesion: row.date_adhesion || new Date().toISOString().split('T')[0],
        statut: row.statut || 'actif',
        eglise_id: egliseId
      });
      success++;
    } catch { errors++; }
  }

  showToast(`${success} membre(s) importé(s)${errors > 0 ? `, ${errors} erreur(s)` : ''}`, success > 0 ? 'success' : 'error');
  clearImport();
  btn.disabled = false;
}

function clearImport() {
  csvImportData = [];
  document.getElementById('csvPreview').innerHTML = '';
  document.getElementById('importActions').style.display = 'none';
  document.getElementById('csvFileInput').value = '';
}

function downloadCSVTemplate() {
  const header = 'prenom,nom,telephone,email,grade,role,date_naissance,date_adhesion,statut';
  const example = 'Jean,Dupont,+243812345678,jean@mail.com,Fidèle simple,Fidèle,1990-01-15,2024-01-01,actif';
  const blob = new Blob([header + '\n' + example], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'modele_membres.csv'; a.click();
  URL.revokeObjectURL(url);
}

// ============================
// PDF EXPORT
// ============================
async function exportPDF() {
  const type = document.getElementById('pdfType').value;
  const eglId = document.getElementById('pdfEglise').value;

  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(108, 52, 131);
    doc.text('Recensement des Églises Paroissiales', 14, 18);
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Généré le ${new Date().toLocaleDateString('fr-FR')}`, 14, 25);
    doc.line(14, 27, 283, 27);

    if (type === 'all_membres' || type === 'eglise') {
      const [mems, egls] = await Promise.all([API.getAll('membres'), API.getAll('eglises')]);
      let data = mems.data;
      if (eglId) data = data.filter(m => m.eglise_id === eglId);

      const egl = eglId ? egls.data.find(e => e.id === eglId) : null;
      doc.setFontSize(13);
      doc.setTextColor(44, 62, 80);
      doc.text(egl ? `Liste des membres - ${egl.nom}` : 'Liste complète des membres', 14, 35);

      const rows = data.map(m => {
        const church = egls.data.find(e => e.id === m.eglise_id);
        return [
          `${m.prenom || ''} ${m.nom || ''}`,
          church ? church.nom : '—',
          m.grade || '—',
          m.role || '—',
          m.telephone || '—',
          m.statut || '—',
          formatDateShort(m.date_adhesion)
        ];
      });

      doc.autoTable({
        startY: 40,
        head: [['Membre', 'Église', 'Grade', 'Rôle', 'Téléphone', 'Statut', 'Adhésion']],
        body: rows,
        theme: 'striped',
        headStyles: { fillColor: [108, 52, 131], textColor: 255, fontStyle: 'bold' },
        alternateRowStyles: { fillColor: [248, 240, 253] },
        styles: { font: 'helvetica', fontSize: 9, cellPadding: 3 }
      });
    } else if (type === 'cotisations') {
      const [cots, mems, egls] = await Promise.all([API.getAll('cotisations'), API.getAll('membres'), API.getAll('eglises')]);
      doc.setFontSize(13);
      doc.text('Rapport des cotisations', 14, 35);

      const rows = cots.data.map(c => {
        const m = mems.data.find(mb => mb.id === c.membre_id);
        const e = egls.data.find(eg => eg.id === c.eglise_id);
        return [
          m ? `${m.prenom} ${m.nom}` : '—',
          e ? e.nom : '—',
          `${Number(c.montant || 0).toLocaleString('fr-FR')} FC`,
          c.type_cotisation || '—',
          c.periode || '—',
          c.statut || '—',
          formatDateShort(c.date_paiement)
        ];
      });

      doc.autoTable({
        startY: 40,
        head: [['Membre', 'Église', 'Montant', 'Type', 'Période', 'Statut', 'Date paiement']],
        body: rows,
        theme: 'striped',
        headStyles: { fillColor: [30, 132, 73], textColor: 255, fontStyle: 'bold' },
        styles: { font: 'helvetica', fontSize: 9, cellPadding: 3 }
      });
    }

    doc.save(`recensement_paroisses_${new Date().toISOString().split('T')[0]}.pdf`);
    showToast('PDF généré avec succès', 'success');
  } catch (err) {
    showToast('Erreur PDF: ' + err.message, 'error');
    console.error(err);
  }
}

async function exportEglisePDF(eglId) {
  if (!eglId) { showToast('Veuillez sélectionner une église', 'warning'); return; }
  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });

    const [egl, mems] = await Promise.all([API.getById('eglises', eglId), API.getAll('membres')]);
    const eglMems = mems.data.filter(m => m.eglise_id === eglId);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(108, 52, 131);
    doc.text(egl.nom, 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Adresse: ${egl.adresse || '—'} · Ville: ${egl.ville || '—'}`, 14, 28);
    doc.text(`Chargé paroissial: ${egl.dir_cp1_nom || '—'}`, 14, 34);
    doc.text(`Secrétaire: ${egl.dir_sec_nom || '—'} · Maître de chœurs: ${egl.dir_mc_nom || '—'}`, 14, 40);
    doc.line(14, 43, 196, 43);

    doc.setFontSize(13);
    doc.setTextColor(44, 62, 80);
    doc.text(`Liste des membres (${eglMems.length})`, 14, 52);

    const rows = eglMems.map(m => [
      `${m.prenom || ''} ${m.nom || ''}`,
      m.grade || '—',
      m.role || '—',
      m.telephone || '—',
      m.statut || '—',
      formatDateShort(m.date_adhesion)
    ]);

    doc.autoTable({
      startY: 56,
      head: [['Membre', 'Grade', 'Rôle', 'Téléphone', 'Statut', 'Adhésion']],
      body: rows,
      theme: 'striped',
      headStyles: { fillColor: [108, 52, 131], textColor: 255 },
      alternateRowStyles: { fillColor: [248, 240, 253] },
      styles: { fontSize: 9 }
    });

    const totalPages = doc.internal.getNumberOfPages();
    for (let p = 1; p <= totalPages; p++) {
      doc.setPage(p);
      doc.setFontSize(8);
      doc.setTextColor(150);
      doc.text(`Page ${p} / ${totalPages} · Généré le ${new Date().toLocaleDateString('fr-FR')}`, 14, 290);
    }

    doc.save(`${egl.nom.replace(/\s+/g, '_')}_membres.pdf`);
    showToast('PDF imprimé avec succès', 'success');
  } catch (err) {
    showToast('Erreur: ' + err.message, 'error');
  }
}

// ============================
// EXCEL EXPORT
// ============================
async function exportExcel() {
  const type = document.getElementById('xlsxType').value;
  const eglId = document.getElementById('xlsxEglise').value;

  try {
    const wb = XLSX.utils.book_new();
    let ws, data, headers;

    if (type === 'membres') {
      const [mems, egls] = await Promise.all([API.getAll('membres'), API.getAll('eglises')]);
      let rows = mems.data;
      if (eglId) rows = rows.filter(m => m.eglise_id === eglId);
      headers = ['Prénom', 'Nom', 'Église', 'Grade', 'Rôle', 'Téléphone', 'Email', 'Statut', 'Date naissance', 'Date adhésion'];
      data = rows.map(m => {
        const egl = egls.data.find(e => e.id === m.eglise_id);
        return [m.prenom, m.nom, egl ? egl.nom : '', m.grade, m.role, m.telephone, m.email, m.statut, m.date_naissance, m.date_adhesion];
      });
    } else if (type === 'eglises') {
      const [egls, srs, regs] = await Promise.all([API.getAll('eglises'), API.getAll('sous_regions'), API.getAll('regions')]);
      headers = ['Nom', 'Région', 'Sous-région', 'Ville', 'Adresse', 'Téléphone', 'Email', 'Chargé paroissial 1', 'Secrétaire', 'Maître de chœurs', 'Statut'];
      data = egls.data.map(e => {
        const sr = srs.data.find(s => s.id === e.sous_region_id);
        const rg = regs.data.find(r => r.id === e.region_id);
        return [e.nom, rg ? rg.nom : '', sr ? sr.nom : '', e.ville, e.adresse, e.telephone, e.email, e.dir_cp1_nom, e.dir_sec_nom, e.dir_mc_nom, e.statut];
      });
    } else if (type === 'cotisations') {
      const [cots, mems, egls] = await Promise.all([API.getAll('cotisations'), API.getAll('membres'), API.getAll('eglises')]);
      let rows = cots.data;
      if (eglId) rows = rows.filter(c => c.eglise_id === eglId);
      headers = ['Membre', 'Église', 'Montant (FC)', 'Type', 'Période', 'Statut', 'Date paiement'];
      data = rows.map(c => {
        const m = mems.data.find(mb => mb.id === c.membre_id);
        const e = egls.data.find(eg => eg.id === c.eglise_id);
        return [m ? `${m.prenom} ${m.nom}` : '', e ? e.nom : '', c.montant, c.type_cotisation, c.periode, c.statut, c.date_paiement];
      });
    } else if (type === 'evenements') {
      const [evs, egls] = await Promise.all([API.getAll('evenements'), API.getAll('eglises')]);
      let rows = evs.data;
      if (eglId) rows = rows.filter(e => e.eglise_id === eglId);
      headers = ['Titre', 'Type', 'Église', 'Date début', 'Date fin', 'Lieu', 'Responsable'];
      data = rows.map(ev => {
        const e = egls.data.find(eg => eg.id === ev.eglise_id);
        return [ev.titre, ev.type_evenement, e ? e.nom : '', ev.date_debut, ev.date_fin, ev.lieu, ev.responsable];
      });
    } else if (type === 'regions') {
      const [regs, srs] = await Promise.all([API.getAll('regions'), API.getAll('sous_regions')]);
      headers = ['Région', 'Responsable', 'Contact', 'Sous-régions'];
      data = regs.data.map(r => {
        const regSrs = srs.data.filter(s => s.region_id === r.id).map(s => s.nom).join(', ');
        return [r.nom, r.responsable, r.contact, regSrs];
      });
    } else if (type === 'historique') {
      const [hist, mems, egls] = await Promise.all([API.getAll('historique'), API.getAll('membres'), API.getAll('eglises')]);
      headers = ['Action', 'Membre', 'Ancienne valeur', 'Nouvelle valeur', 'Église', 'Date', 'Notes'];
      data = hist.data.map(h => {
        const m = mems.data.find(mb => mb.id === h.membre_id);
        const e = egls.data.find(eg => eg.id === h.eglise_id);
        return [h.type_action, m ? `${m.prenom} ${m.nom}` : '', h.ancienne_valeur, h.nouvelle_valeur, e ? e.nom : '', h.date_action, h.notes];
      });
    }

    ws = XLSX.utils.aoa_to_sheet([headers, ...data]);
    ws['!cols'] = headers.map(() => ({ wch: 20 }));
    XLSX.utils.book_append_sheet(wb, ws, type.charAt(0).toUpperCase() + type.slice(1));
    XLSX.writeFile(wb, `recensement_${type}_${new Date().toISOString().split('T')[0]}.xlsx`);
    showToast('Fichier Excel téléchargé', 'success');
  } catch (err) {
    showToast('Erreur Excel: ' + err.message, 'error');
    console.error(err);
  }
}

async function exportAll() {
  try {
    const [mems, egls, srs, regs, evs, cots, hist] = await Promise.all([
      API.getAll('membres'), API.getAll('eglises'), API.getAll('sous_regions'),
      API.getAll('regions'), API.getAll('evenements'), API.getAll('cotisations'), API.getAll('historique')
    ]);

    const wb = XLSX.utils.book_new();

    const addSheet = (name, headers, rows) => {
      const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
      ws['!cols'] = headers.map(() => ({ wch: 18 }));
      XLSX.utils.book_append_sheet(wb, ws, name);
    };

    addSheet('Membres', ['Prénom', 'Nom', 'Église', 'Grade', 'Rôle', 'Téléphone', 'Statut', 'Adhésion'],
      mems.data.map(m => {
        const e = egls.data.find(eg => eg.id === m.eglise_id);
        return [m.prenom, m.nom, e ? e.nom : '', m.grade, m.role, m.telephone, m.statut, m.date_adhesion];
      })
    );

    addSheet('Eglises', ['Nom', 'Région', 'Ville', 'Téléphone', 'Chargé Paroissial', 'Secrétaire', 'Statut'],
      egls.data.map(e => {
        const r = regs.data.find(rg => rg.id === e.region_id);
        return [e.nom, r ? r.nom : '', e.ville, e.telephone, e.dir_cp1_nom, e.dir_sec_nom, e.statut];
      })
    );

    addSheet('Régions', ['Nom', 'Responsable', 'Contact'],
      regs.data.map(r => [r.nom, r.responsable, r.contact])
    );

    addSheet('Sous-régions', ['Nom', 'Région', 'Responsable', 'Contact'],
      srs.data.map(s => {
        const r = regs.data.find(rg => rg.id === s.region_id);
        return [s.nom, r ? r.nom : '', s.responsable, s.contact];
      })
    );

    addSheet('Cotisations', ['Membre', 'Église', 'Montant', 'Type', 'Période', 'Statut'],
      cots.data.map(c => {
        const m = mems.data.find(mb => mb.id === c.membre_id);
        const e = egls.data.find(eg => eg.id === c.eglise_id);
        return [m ? `${m.prenom} ${m.nom}` : '', e ? e.nom : '', c.montant, c.type_cotisation, c.periode, c.statut];
      })
    );

    addSheet('Événements', ['Titre', 'Type', 'Église', 'Date', 'Lieu'],
      evs.data.map(ev => {
        const e = egls.data.find(eg => eg.id === ev.eglise_id);
        return [ev.titre, ev.type_evenement, e ? e.nom : '', ev.date_debut, ev.lieu];
      })
    );

    XLSX.writeFile(wb, `recensement_complet_${new Date().toISOString().split('T')[0]}.xlsx`);
    showToast('Export complet réussi', 'success');
  } catch (err) {
    showToast('Erreur: ' + err.message, 'error');
  }
}

function printPage() {
  window.print();
}
