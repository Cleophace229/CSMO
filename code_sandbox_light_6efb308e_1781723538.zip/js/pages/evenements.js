/**
 * Événements Page — Recensement Paroissial
 * Types enrichis + champs dynamiques
 */
App.registerAddHandler('evenements', () => showEvenementForm());

/* ─── Configuration des types d'événements ─────────────────── */
const TYPES_EV_CONFIG = {
  'Messe':                { color: 'badge-primary',   icon: 'fa-cross',       champs: [] },
  'Bapteme':              { color: 'badge-success',   icon: 'fa-tint',        champs: [] },
  'Mariage':              { color: 'badge-gold',      icon: 'fa-heart',       champs: [] },
  'Funérailles':          { color: 'badge-secondary', icon: 'fa-cross',       champs: ['nom_famille','nom_defunt'] },
  'Sortie d\'enfant':     { color: 'badge-info',      icon: 'fa-baby',        champs: ['nom_pere','nom_mere','nom_bebe'] },
  'Veillée de funéraille':{ color: 'badge-dark',      icon: 'fa-moon',        champs: ['nom_famille','nom_defunt'] },
  'Messe du 8ème jour':   { color: 'badge-warning',   icon: 'fa-church',      champs: ['nom_famille','nom_defunt'] },
  'Messe du 41ème jour':  { color: 'badge-warning',   icon: 'fa-church',      champs: ['nom_famille','nom_defunt'] },
  'Pâques':               { color: 'badge-success',   icon: 'fa-sun',         champs: [] },
  'Pentecôte':            { color: 'badge-danger',    icon: 'fa-fire',        champs: [] },
  'Ascension':            { color: 'badge-primary',   icon: 'fa-cloud',       champs: [] },
  'Réunion':              { color: 'badge-info',      icon: 'fa-users',       champs: [] },
  'Fête liturgique':      { color: 'badge-warning',   icon: 'fa-star',        champs: [] },
  'Fête de Moisson':      { color: 'badge-gold',      icon: 'fa-wheat-awn',   champs: [] },
  'Autre':                { color: 'badge-secondary', icon: 'fa-calendar',    champs: [] }
};

const TYPES_EV = Object.keys(TYPES_EV_CONFIG);

/* Labels des champs dynamiques */
const CHAMP_LABELS = {
  nom_pere:    'Nom du Père',
  nom_mere:    'Nom de la Mère',
  nom_bebe:    'Nom du Bébé',
  nom_famille: 'Nom de la Famille',
  nom_defunt:  'Nom du/de la Défunt(e)'
};

/* ─── Render principal ──────────────────────────────────────── */
async function renderEvenements(params = {}) {
  setBreadcrumb([{ label: I18n.t('events.title') }]);
  const content = document.getElementById('pageContent');
  const user    = Auth.getCurrentUser();
  const isEglise = user && user.eglise_id && user.role !== 'super_admin' && user.role !== 'admin';

  try {
    const [evs, egls] = await Promise.all([
      API.getAll('evenements'),
      API.getAll('eglises')
    ]);

    /* Types d'événements visibles par TOUTES les paroisses (pas seulement la créatrice) */
    const TYPES_GLOBAUX = ['Fête de Moisson', 'Fête liturgique', 'Pâques', 'Pentecôte', 'Ascension'];

    // Filtrage automatique pour compte église
    let filtered = evs.data;
    if (isEglise) {
      filtered = evs.data.filter(e =>
        e.eglise_id === user.eglise_id ||
        TYPES_GLOBAUX.includes(e.type_evenement)
      );
    } else if (params.eglise_id) {
      filtered = evs.data.filter(e => e.eglise_id === params.eglise_id);
    }

    const eglFilterHTML = !isEglise ? `
      <select class="form-control" id="evEglFilter" style="width:180px" onchange="filterEvenements()">
        <option value="">Toutes les églises</option>
        ${egls.data.map(e =>
          `<option value="${e.id}" ${params.eglise_id === e.id ? 'selected' : ''}>${e.nom}</option>`
        ).join('')}
      </select>` : '';

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title"><i class="fas fa-calendar-alt" style="margin-right:10px"></i>Événements Paroissiaux</h2>
          <p id="evCount">${filtered.length} événement(s)</p>
        </div>
        <div class="page-header-actions">
          ${Auth.canWrite()
            ? `<button class="btn btn-primary" onclick="showEvenementForm()"><i class="fas fa-plus"></i> Nouvel événement</button>`
            : ''}
        </div>
      </div>

      <div class="page-search" style="flex-wrap:wrap;gap:8px">
        <div class="search-input-wrapper" style="flex:1">
          <i class="fas fa-search"></i>
          <input type="text" id="evSearch" placeholder="Rechercher un événement..." oninput="filterEvenements()" />
        </div>
        ${eglFilterHTML}
        <select class="form-control" id="evTypeFilter" style="width:200px" onchange="filterEvenements()">
          <option value="">Tous les types</option>
          ${TYPES_EV.map(t => `<option value="${t}">${t}</option>`).join('')}
        </select>
      </div>

      <div class="table-wrapper" id="evTable">
        ${renderEvenementsTable(filtered, egls.data)}
      </div>

      <!-- Données cachées pour le filtre côté client -->
      <div id="evData"
        data-evs='${JSON.stringify(evs.data).replace(/'/g,"&#39;")}'
        data-egls='${JSON.stringify(egls.data).replace(/'/g,"&#39;")}'
        data-eglise-id="${isEglise ? user.eglise_id : ''}"
        style="display:none"></div>
    `;

    if (!isEglise && params.eglise_id) {
      const sel = document.getElementById('evEglFilter');
      if (sel) sel.value = params.eglise_id;
    }

  } catch (err) {
    content.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erreur</h3><p>${err.message}</p></div>`;
  }
}

/* ─── Table HTML ──────────────────────────────────────────────── */
function renderEvenementsTable(evs, egls) {
  if (!evs || evs.length === 0)
    return emptyState(
      'fa-calendar',
      'Aucun événement',
      'Aucun événement paroissial enregistré.',
      Auth.canWrite() ? 'Créer un événement' : null,
      'showEvenementForm()'
    );

  return `<table>
    <thead>
      <tr>
        <th>Événement</th>
        <th>Type</th>
        <th>Église</th>
        <th>Date</th>
        <th>Lieu</th>
        <th>Détails spécifiques</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      ${evs.map(ev => {
        const egl = egls.find(e => e.id === ev.eglise_id);
        const cfg = TYPES_EV_CONFIG[ev.type_evenement] || TYPES_EV_CONFIG['Autre'];
        const details = _buildDetailsCell(ev);
        return `<tr
          data-title="${(ev.titre || '').toLowerCase()}"
          data-egl="${ev.eglise_id || ''}"
          data-type="${ev.type_evenement || ''}">
          <td style="font-weight:600">${ev.titre || '—'}</td>
          <td>
            <span class="badge ${cfg.color}">
              <i class="fas ${cfg.icon}" style="margin-right:4px"></i>${ev.type_evenement || '—'}
            </span>
          </td>
          <td style="font-size:12px">${egl ? egl.nom : '—'}</td>
          <td style="font-size:12px">
            ${formatDateShort(ev.date_debut)}
            ${ev.date_fin && ev.date_fin !== ev.date_debut
              ? ' → ' + formatDateShort(ev.date_fin) : ''}
          </td>
          <td style="font-size:12px">${ev.lieu || '—'}</td>
          <td style="font-size:11px;color:var(--text-muted)">${details}</td>
          <td>
            <div class="td-actions">
              ${Auth.canWrite()
                ? `<button class="btn btn-xs btn-primary" onclick="showEvenementForm('${ev.id}')">
                     <i class="fas fa-edit"></i>
                   </button>`
                : ''}
              ${Auth.canDelete()
                ? `<button class="btn btn-xs btn-danger" onclick="deleteEvenement('${ev.id}','${(ev.titre || '').replace(/'/g,"\\'")}')">
                     <i class="fas fa-trash"></i>
                   </button>`
                : ''}
            </div>
          </td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>`;
}

/* ─── Cellule détails dynamiques ──────────────────────────────── */
function _buildDetailsCell(ev) {
  const parts = [];
  if (ev.nom_bebe)    parts.push(`👶 Bébé : <strong>${ev.nom_bebe}</strong>`);
  if (ev.nom_pere)    parts.push(`Père : ${ev.nom_pere}`);
  if (ev.nom_mere)    parts.push(`Mère : ${ev.nom_mere}`);
  if (ev.nom_defunt)  parts.push(`✝ Défunt(e) : <strong>${ev.nom_defunt}</strong>`);
  if (ev.nom_famille) parts.push(`Famille : ${ev.nom_famille}`);
  if (!parts.length && ev.responsable) parts.push(ev.responsable);
  return parts.join(' · ') || '—';
}

/* ─── Filtre côté client ─────────────────────────────────────── */
function filterEvenements() {
  const q     = (document.getElementById('evSearch')?.value || '').toLowerCase();
  const eglId = document.getElementById('evEglFilter')?.value || '';
  const type  = document.getElementById('evTypeFilter')?.value || '';

  // Récupérer le filtre fixe (compte église)
  const dataEl    = document.getElementById('evData');
  const fixedEgl  = dataEl?.dataset.egliseId || '';

  document.querySelectorAll('#evTable tbody tr').forEach(tr => {
    const matchQ = !q     || tr.dataset.title.includes(q);
    const matchE = !eglId || tr.dataset.egl === eglId;
    const matchT = !type  || tr.dataset.type === type;
    const matchF = !fixedEgl || tr.dataset.egl === fixedEgl;
    tr.style.display = (matchQ && matchE && matchT && matchF) ? '' : 'none';
  });
}

/* ─── Champs dynamiques selon le type ────────────────────────── */
function _renderDynamicFields(type, data = {}) {
  const cfg = TYPES_EV_CONFIG[type];
  if (!cfg || !cfg.champs.length) return '';

  let html = `
    <hr style="border:none;border-top:2px dashed var(--border);margin:16px 0">
    <h4 style="font-weight:700;margin-bottom:12px;color:var(--primary-dark);display:flex;align-items:center;gap:8px">
      <i class="fas ${cfg.icon}" style="color:var(--gold)"></i>
      Informations spécifiques — <em style="font-style:normal;font-size:13px">${type}</em>
    </h4>`;

  const champs = cfg.champs;
  for (let i = 0; i < champs.length; i += 2) {
    const pair = champs.slice(i, i + 2);
    html += `<div class="form-row">`;
    pair.forEach(key => {
      html += `
        <div class="form-group">
          <label>${CHAMP_LABELS[key] || key} <span style="color:var(--danger)">*</span></label>
          <input class="form-control" id="fEv_${key}"
            value="${(data[key] || '')}"
            placeholder="${CHAMP_LABELS[key] || key}" />
        </div>`;
    });
    if (pair.length === 1) html += `<div class="form-group"></div>`;
    html += `</div>`;
  }
  return html;
}

function _onTypeChange() {
  const type      = document.getElementById('fEvType')?.value || '';
  const container = document.getElementById('fEvDynamicFields');
  if (container) container.innerHTML = _renderDynamicFields(type);
}

/* ─── Formulaire événement ───────────────────────────────────── */
async function showEvenementForm(id = null) {
  const egls = await API.getAll('eglises');
  let data = {};
  if (id) { try { data = await API.getById('evenements', id); } catch {} }

  const user     = Auth.getCurrentUser();
  const isEglise = user && user.eglise_id && user.role !== 'super_admin' && user.role !== 'admin';
  const preselEgl = isEglise ? user.eglise_id : (data.eglise_id || '');

  const html = `
    <div class="form-group">
      <label>Titre de l'événement <span style="color:var(--danger)">*</span></label>
      <input class="form-control" id="fEvTitre" value="${data.titre || ''}" placeholder="Titre de l'événement" />
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Type <span style="color:var(--danger)">*</span></label>
        <select class="form-control" id="fEvType" onchange="_onTypeChange()">
          <option value="">— Choisir le type —</option>
          ${TYPES_EV.map(t => `<option value="${t}" ${data.type_evenement === t ? 'selected' : ''}>${t}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Église <span style="color:var(--danger)">*</span></label>
        <select class="form-control" id="fEvEgl" ${isEglise ? 'disabled' : ''}>
          <option value="">— Choisir —</option>
          ${egls.data.map(e =>
            `<option value="${e.id}" ${preselEgl === e.id ? 'selected' : ''}>${e.nom}</option>`
          ).join('')}
        </select>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Date de début</label>
        <input class="form-control" type="date" id="fEvDebut" value="${data.date_debut || ''}" />
      </div>
      <div class="form-group">
        <label>Date de fin</label>
        <input class="form-control" type="date" id="fEvFin" value="${data.date_fin || ''}" />
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Lieu</label>
        <input class="form-control" id="fEvLieu" value="${data.lieu || ''}" placeholder="Lieu de l'événement" />
      </div>
      <div class="form-group">
        <label>Responsable</label>
        <input class="form-control" id="fEvResp" value="${data.responsable || ''}" placeholder="Personne responsable" />
      </div>
    </div>

    <div class="form-group">
      <label>Description</label>
      <textarea class="form-control" id="fEvDesc">${data.description || ''}</textarea>
    </div>

    <!-- Champs dynamiques injectés selon le type -->
    <div id="fEvDynamicFields">
      ${_renderDynamicFields(data.type_evenement || '', data)}
    </div>
  `;

  openModal(
    id ? 'Modifier l\'événement' : 'Nouvel événement',
    html,
    id ? 'Enregistrer' : 'Créer',
    async () => {
      const titre          = document.getElementById('fEvTitre').value.trim();
      const type_evenement = document.getElementById('fEvType').value;
      const eglise_id      = isEglise ? user.eglise_id : document.getElementById('fEvEgl').value;

      if (!titre)          { showToast('Le titre est requis', 'warning'); return; }
      if (!type_evenement) { showToast('Veuillez choisir un type', 'warning'); return; }
      if (!eglise_id)      { showToast('Veuillez choisir une église', 'warning'); return; }

      // Vérifier champs dynamiques obligatoires
      const cfg = TYPES_EV_CONFIG[type_evenement] || { champs: [] };
      const dynamicPayload = {};
      for (const key of cfg.champs) {
        const val = (document.getElementById(`fEv_${key}`)?.value || '').trim();
        if (!val) {
          showToast(`Le champ "${CHAMP_LABELS[key]}" est requis pour ce type`, 'warning');
          return;
        }
        dynamicPayload[key] = val;
      }

      const payload = {
        titre,
        type_evenement,
        eglise_id,
        date_debut:   document.getElementById('fEvDebut').value,
        date_fin:     document.getElementById('fEvFin').value,
        lieu:         document.getElementById('fEvLieu').value.trim(),
        responsable:  document.getElementById('fEvResp').value.trim(),
        description:  document.getElementById('fEvDesc').value.trim(),
        // Réinitialiser tous les champs dynamiques puis appliquer
        nom_pere:     '',
        nom_mere:     '',
        nom_bebe:     '',
        nom_famille:  '',
        nom_defunt:   '',
        ...dynamicPayload
      };

      try {
        if (id) {
          await API.update('evenements', id, payload);
          showToast('Événement mis à jour', 'success');
        } else {
          await API.create('evenements', { id: generateId('ev'), ...payload });
          showToast('Événement créé avec succès', 'success');
        }
        closeModal();
        renderEvenements();
      } catch (err) {
        showToast('Erreur : ' + err.message, 'error');
      }
    }
  );
}

/* ─── Suppression ─────────────────────────────────────────────── */
async function deleteEvenement(id, nom) {
  confirmDelete(nom, async () => {
    try {
      await API.remove('evenements', id);
      showToast('Événement supprimé', 'success');
      closeModal();
      renderEvenements();
    } catch (err) {
      showToast('Erreur : ' + err.message, 'error');
    }
  });
}
