/**
 * contributeurs.js — À propos du site
 *
 * RÈGLES D'ACCÈS :
 *  - Tous les comptes (admin, église) : lecture seule — AUCUN ajout/modification/suppression
 *  - Aucun bouton d'édition affiché, aucun handler d'ajout enregistré
 *
 * Table : contributeurs
 * Colonnes : id, nom, role_contributeur, telephone, email, eglise, grade, ordre, photo_url, notes
 */

/* Pas de registerAddHandler → le bouton "Ajouter" n'apparaîtra JAMAIS sur cette page */

let _contribData = [];

/* ══════════════════════════════════════════════════════════════════
   RENDU PRINCIPAL
══════════════════════════════════════════════════════════════════ */
async function renderContributeurs() {
  setBreadcrumb([{ label: 'À propos' }]);
  const content = document.getElementById('pageContent');

  content.innerHTML = `<div class="loading-spinner">
    <i class="fas fa-circle-notch fa-spin"></i><p>Chargement...</p></div>`;

  try {
    const res = await API.getAll('contributeurs', { limit: 50 });
    _contribData = (res.data || []).sort((a, b) => (a.ordre || 99) - (b.ordre || 99));

    content.innerHTML = `

      <!-- ═══ BANNIÈRE IDENTITAIRE ═══ -->
      <div style="background:linear-gradient(135deg,#1e1b4b 0%,#312e81 50%,#4c1d95 100%);
        border-radius:20px;padding:32px 36px;margin-bottom:32px;color:#fff;
        box-shadow:0 12px 40px rgba(124,58,237,0.35)">
        <div style="display:flex;align-items:flex-start;gap:24px;flex-wrap:wrap">

          <!-- Icône centrale -->
          <div style="flex-shrink:0;width:80px;height:80px;border-radius:20px;
            background:rgba(255,255,255,0.12);border:2px solid rgba(255,255,255,0.2);
            display:flex;align-items:center;justify-content:center;font-size:40px">
            ⛪
          </div>

          <div style="flex:1;min-width:240px">
            <h1 style="font-size:24px;font-weight:800;margin-bottom:8px;
              font-family:'Playfair Display',serif;letter-spacing:.4px">
              Recensement des Paroisses Célestes
            </h1>
            <p style="font-size:14px;opacity:.88;line-height:1.75;margin-bottom:20px;
              max-width:620px">
              Ce site a été conçu pour servir l'ensemble de la
              <strong>Communauté Céleste de toutes les paroisses</strong>.
              Il centralise le recensement des fidèles, la gestion hiérarchique,
              les événements, la messagerie inter-paroissiale et bien plus encore.
            </p>

            <!-- Carte créateur -->
            <div style="background:rgba(255,255,255,0.1);border-radius:14px;
              padding:16px 20px;display:flex;align-items:center;gap:16px;
              border:1px solid rgba(255,255,255,0.15);max-width:500px">
              <div style="width:52px;height:52px;border-radius:14px;flex-shrink:0;
                background:linear-gradient(135deg,#f59e0b,#ef4444);
                display:flex;align-items:center;justify-content:center;
                font-size:24px;box-shadow:0 4px 12px rgba(0,0,0,0.25)">
                ✝️
              </div>
              <div>
                <div style="font-size:11px;opacity:.7;text-transform:uppercase;
                  letter-spacing:.8px;margin-bottom:4px">Créateur du site</div>
                <div style="font-size:17px;font-weight:800;color:#fde68a;
                  font-family:'Playfair Display',serif">
                  Dehoto Cléophace TODJINOU
                </div>
                <div style="font-size:12px;opacity:.82;margin-top:4px">
                  <i class="fas fa-church" style="margin-right:5px"></i>
                  Fidèle de la Paroisse <strong>Saint Samuel Hindé 2</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ═══ STATISTIQUES RAPIDES ═══ -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
        gap:14px;margin-bottom:32px">
        ${_carteStatAPropos('fa-church','Paroisses','Communauté Céleste','#7c3aed')}
        ${_carteStatAPropos('fa-users','Fidèles & Membres','Recensement complet','#059669')}
        ${_carteStatAPropos('fa-envelope','Messagerie','Inter-paroissiale','#d97706')}
        ${_carteStatAPropos('fa-calendar-alt','Activités','Événements & Calendrier','#dc2626')}
      </div>

      <!-- ═══ FONCTIONNALITÉS ═══ -->
      <div class="card" style="margin-bottom:28px">
        <div class="card-header">
          <h3><i class="fas fa-list-check" style="color:var(--primary);margin-right:8px"></i>
            Fonctionnalités de la plateforme</h3>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
            gap:12px">
            ${[
              ['fa-sitemap',       'Gestion hiérarchique',    'Régions → Sous-régions → Églises'],
              ['fa-users',         'Membres & Grades',        'Tous grades de la Communauté Céleste'],
              ['fa-crown',         'Comités Supérieurs',      'CSM · CDSS · CSMO'],
              ['fa-child',         'Enfants AJ',              "Enfants de l'Ami de Jésus"],
              ['fa-envelope',      'Messagerie',              'Direct, diffusion, pièces jointes PDF'],
              ['fa-calendar-alt',  'Activités',               'Événements & Calendrier liturgique'],
              ['fa-hand-holding-usd','Cotisations',           'Suivi des contributions'],
              ['fa-chart-bar',     'Statistiques',            'Tableaux de bord & analyses'],
              ['fa-map',           'Carte des paroisses',     'Géolocalisation des églises'],
              ['fa-file-export',   'Export & Impression',     'PDF et Excel'],
              ['fa-moon',          'Mode sombre / clair',     'Confort visuel jour et nuit'],
              ['fa-mobile-alt',    'Application PWA',         'Installable sur mobile & PC'],
            ].map(([icon, titre, desc]) => `
              <div style="display:flex;align-items:flex-start;gap:12px;padding:12px;
                border-radius:10px;background:var(--bg);border:1px solid var(--border)">
                <div style="width:36px;height:36px;border-radius:9px;flex-shrink:0;
                  background:var(--accent);display:flex;align-items:center;
                  justify-content:center;color:var(--primary);font-size:15px">
                  <i class="fas ${icon}"></i>
                </div>
                <div>
                  <div style="font-weight:700;font-size:13px;color:var(--text)">${titre}</div>
                  <div style="font-size:11px;color:var(--text-muted);margin-top:2px">${desc}</div>
                </div>
              </div>`).join('')}
          </div>
        </div>
      </div>

      <!-- ═══ MEMBRES CONTRIBUTEURS ═══ -->
      ${_contribData.length > 0 ? `
      <div class="card" style="margin-bottom:28px">
        <div class="card-header">
          <h3><i class="fas fa-hands-helping" style="color:var(--gold);margin-right:8px"></i>
            Membres contributeurs</h3>
          <span style="font-size:12px;color:var(--text-muted)">
            ${_contribData.length} contributeur(s)
          </span>
        </div>
        <div class="card-body" style="padding:20px">
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));
            gap:16px">
            ${_contribData.map((c, i) => _carteContributeur(c, i)).join('')}
          </div>
        </div>
      </div>` : ''}

      <!-- ═══ NOTE DE BAS DE PAGE ═══ -->
      <div style="background:var(--bg-card);border:1px solid var(--border);
        border-radius:12px;padding:18px 22px;
        display:flex;align-items:center;gap:14px;color:var(--text-muted);font-size:13px">
        <i class="fas fa-info-circle" style="color:var(--primary);font-size:20px;flex-shrink:0"></i>
        <span>
          Ce site est au service de la
          <strong style="color:var(--text)">Communauté Céleste de toutes les paroisses</strong>.
          Toutes les données sont gérées avec soin pour le bon fonctionnement de chaque paroisse.
        </span>
      </div>
    `;

  } catch (err) {
    content.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
        <h3>Erreur de chargement</h3>
        <p>${err.message}</p>
        <button class="btn btn-primary" onclick="renderContributeurs()">
          <i class="fas fa-redo"></i> Réessayer
        </button>
      </div>`;
  }
}

/* ── Mini-carte statistique décorative ──────────────────────────── */
function _carteStatAPropos(icon, titre, sousTitre, couleur) {
  return `
    <div style="background:var(--bg-card);border:1px solid var(--border);
      border-radius:14px;padding:18px;display:flex;align-items:center;gap:14px;
      box-shadow:var(--shadow)">
      <div style="width:44px;height:44px;border-radius:12px;flex-shrink:0;
        background:${couleur}18;display:flex;align-items:center;justify-content:center;
        color:${couleur};font-size:18px">
        <i class="fas ${icon}"></i>
      </div>
      <div>
        <div style="font-weight:700;font-size:14px;color:var(--text)">${titre}</div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:2px">${sousTitre}</div>
      </div>
    </div>`;
}

/* ── Carte d'un contributeur (lecture seule) ────────────────────── */
function _carteContributeur(c, i) {
  const gradients = [
    'linear-gradient(135deg,#7c3aed,#4f46e5)',
    'linear-gradient(135deg,#059669,#0891b2)',
    'linear-gradient(135deg,#d97706,#ef4444)',
    'linear-gradient(135deg,#be185d,#9333ea)',
    'linear-gradient(135deg,#0284c7,#0d9488)',
    'linear-gradient(135deg,#dc2626,#ea580c)',
    'linear-gradient(135deg,#15803d,#166534)',
    'linear-gradient(135deg,#1d4ed8,#7c3aed)',
    'linear-gradient(135deg,#b45309,#92400e)',
    'linear-gradient(135deg,#7e22ce,#be185d)'
  ];
  const grad = gradients[i % gradients.length];
  const nom  = (c.nom || '??');
  const ini  = nom.slice(0, 2).toUpperCase();

  return `
    <div style="background:var(--bg);border:1px solid var(--border);
      border-radius:14px;overflow:hidden;transition:box-shadow .2s"
      onmouseenter="this.style.boxShadow='var(--shadow-lg)'"
      onmouseleave="this.style.boxShadow='none'">

      <!-- Bandeau coloré + avatar -->
      <div style="background:${grad};height:72px;position:relative">
        <div style="position:absolute;bottom:-24px;left:18px;
          width:48px;height:48px;border-radius:50%;
          border:3px solid var(--bg-card);
          background:${grad};
          display:flex;align-items:center;justify-content:center;
          font-weight:800;font-size:16px;color:#fff;
          box-shadow:0 4px 12px rgba(0,0,0,0.2)">
          ${c.photo_url
            ? `<img src="${c.photo_url}" alt="${ini}"
                style="width:100%;height:100%;object-fit:cover;border-radius:50%"
                onerror="this.parentElement.textContent='${ini}'" />`
            : ini}
        </div>
        <div style="position:absolute;top:8px;right:10px;
          background:rgba(255,255,255,0.18);border-radius:20px;
          padding:2px 9px;font-size:10px;color:#fff;font-weight:700">
          #${c.ordre || (i + 1)}
        </div>
      </div>

      <!-- Corps -->
      <div style="padding:32px 16px 16px">
        <div style="font-weight:800;font-size:14px;color:var(--text);margin-bottom:2px">
          ${nom}
        </div>
        <div style="font-size:12px;font-weight:600;color:var(--primary);margin-bottom:8px">
          ${c.role_contributeur || '—'}
        </div>
        ${c.grade ? `<div style="margin-bottom:8px">${gradeBadge(c.grade)}</div>` : ''}
        ${c.eglise ? `
          <div style="font-size:12px;color:var(--text-muted);margin-bottom:5px">
            <i class="fas fa-church" style="width:14px;color:var(--primary)"></i>
            ${c.eglise}
          </div>` : ''}
        ${c.telephone ? `
          <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px">
            <i class="fas fa-phone" style="width:14px;color:var(--success)"></i>
            <a href="tel:${c.telephone}"
              style="color:var(--text-muted);text-decoration:none">${c.telephone}</a>
          </div>` : ''}
        ${c.email ? `
          <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px">
            <i class="fas fa-envelope" style="width:14px;color:var(--info)"></i>
            <a href="mailto:${c.email}"
              style="color:var(--text-muted);text-decoration:none">${c.email}</a>
          </div>` : ''}
        ${c.notes ? `
          <p style="font-size:11px;color:var(--text-muted);font-style:italic;
            margin-top:10px;padding-top:10px;border-top:1px solid var(--border);
            line-height:1.5">"${c.notes}"</p>` : ''}
      </div>
    </div>`;
}
