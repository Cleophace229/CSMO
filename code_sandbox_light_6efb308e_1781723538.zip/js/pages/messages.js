/**
 * messages.js — Messagerie Admin ↔ Église
 * - Admin : envoie à une église, par région, par sous-région ou à toutes (broadcast)
 * - Admin : peut joindre un document PDF (base64) que l'église peut imprimer
 * - Église : reçoit les messages admin, répond, télécharge/imprime le PDF
 */

App.registerAddHandler('messages', () => {
  const user = Auth.getCurrentUser();
  const isAdmin = user && (user.role === 'super_admin' || user.role === 'admin');
  if (isAdmin) showNouveauMessage();
  else showToast('Seuls les administrateurs peuvent initier une conversation.', 'warning');
});

/* ═══════════════════════════════════════════════════════════════
   RENDU PRINCIPAL
   ═══════════════════════════════════════════════════════════════ */
async function renderMessages(params = {}) {
  setBreadcrumb([{ label: I18n.t('messages.title') }]);
  const content = document.getElementById('pageContent');
  const user    = Auth.getCurrentUser();
  if (!user) return;

  const isAdmin  = user.role === 'super_admin' || user.role === 'admin';
  const isEglise = !isAdmin && !!user.eglise_id;

  content.innerHTML = `<div class="loading-spinner">
    <i class="fas fa-circle-notch fa-spin"></i><p>Chargement des messages...</p></div>`;

  try {
    const [messagesRes, eglesRes, regsRes, srsRes] = await Promise.all([
      API.getAll('messages', { limit: 500 }).catch(() => ({ data: [] })),
      isAdmin ? API.getAll('eglises').catch(() => ({ data: [] })) : Promise.resolve({ data: [] }),
      isAdmin ? API.getAll('regions').catch(()  => ({ data: [] })) : Promise.resolve({ data: [] }),
      isAdmin ? API.getAll('sous_regions').catch(() => ({ data: [] })) : Promise.resolve({ data: [] })
    ]);

    let messages = messagesRes.data || [];

    /* Filtrer selon le rôle église */
    if (isEglise) {
      let eglData = {};
      try { eglData = await API.getById('eglises', user.eglise_id); } catch (_) {}
      const sr = eglData.sous_region_id || '';
      const rg = eglData.region_id      || '';
      messages = messages.filter(m =>
        m.eglise_id === user.eglise_id ||
        m.destinataire_id === 'all' ||
        (m.type === 'region'      && m.region_id      === rg) ||
        (m.type === 'sous_region' && m.sous_region_id === sr)
      );
    }

    /* Trier par date décroissante */
    messages.sort((a, b) =>
      ((b.date_envoi || b.created_at || 0) > (a.date_envoi || a.created_at || 0)) ? 1 : -1
    );

    /* Séparer conversations principales des réponses */
    const principals = messages.filter(m => !m.message_parent_id);
    const reponses   = messages.filter(m =>  m.message_parent_id);

    /* Compter les non-lus */
    const nonLus = isEglise
      ? principals.filter(m => !m.lu && m.direction === 'admin_to_eglise').length
      : principals.filter(m => !m.lu && m.direction === 'eglise_to_admin').length;

    const eglises    = eglesRes.data  || [];
    const regions    = regsRes.data   || [];
    const sousRegs   = srsRes.data    || [];

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-envelope" style="margin-right:10px"></i>${I18n.t('messages.title')}
            ${nonLus > 0 ? `<span class="badge badge-danger" style="font-size:13px;margin-left:8px">${nonLus} non lu${nonLus>1?'s':''}</span>` : ''}
          </h2>
          <p>${isAdmin ? (I18n.lang==='en'?'Communicate with churches — send by region, sub-region or individual':'Communiquez avec les églises — envoi par région, sous-région ou individuel') : (I18n.lang==='en'?'Administration messages':'Messages de l\'administration')}</p>
        </div>
        <div class="page-header-actions">
          ${isAdmin ? `<button class="btn btn-primary" onclick="showNouveauMessage()">
            <i class="fas fa-pen"></i> ${I18n.t('messages.new')}
          </button>` : ''}
        </div>
      </div>

      <div style="display:grid;grid-template-columns:${isAdmin ? '260px 1fr' : '1fr'};gap:20px;min-height:500px" id="msgLayout">

        ${isAdmin ? `
        <div style="background:var(--bg-card);border-radius:14px;border:1px solid var(--border);overflow:hidden">
          <div style="padding:16px;border-bottom:1px solid var(--border)">
            <div style="font-weight:700;font-size:14px;color:var(--primary)">
              <i class="fas fa-inbox" style="margin-right:6px"></i>Boîtes
            </div>
          </div>
          <div>
            <div class="msg-box-item active" onclick="filterMsgBox(this,'all')"
              style="padding:12px 16px;cursor:pointer;display:flex;align-items:center;gap:10px;
                     border-left:3px solid var(--primary);background:rgba(124,58,237,.06)">
              <i class="fas fa-inbox" style="color:var(--primary);width:16px"></i>
              <span style="font-size:13px;font-weight:600">${I18n.lang==='en'?'All':'Tous'}</span>
              <span class="badge badge-primary" style="margin-left:auto">${principals.length}</span>
            </div>
            <div class="msg-box-item" onclick="filterMsgBox(this,'envoi')"
              style="padding:12px 16px;cursor:pointer;display:flex;align-items:center;gap:10px;border-left:3px solid transparent">
              <i class="fas fa-paper-plane" style="color:var(--info);width:16px"></i>
              <span style="font-size:13px">${I18n.t('messages.sent')}</span>
              <span class="badge badge-info" style="margin-left:auto">
                ${principals.filter(m=>m.direction==='admin_to_eglise').length}
              </span>
            </div>
            <div class="msg-box-item" onclick="filterMsgBox(this,'reponses')"
              style="padding:12px 16px;cursor:pointer;display:flex;align-items:center;gap:10px;border-left:3px solid transparent">
              <i class="fas fa-reply-all" style="color:var(--success);width:16px"></i>
              <span style="font-size:13px">${I18n.lang==='en'?'Replies':'Réponses'}</span>
              <span class="badge badge-success" style="margin-left:auto">
                ${reponses.length}
              </span>
            </div>
            <div class="msg-box-item" onclick="filterMsgBox(this,'nonlu')"
              style="padding:12px 16px;cursor:pointer;display:flex;align-items:center;gap:10px;border-left:3px solid transparent">
              <i class="fas fa-bell" style="color:var(--warning);width:16px"></i>
              <span style="font-size:13px">Non lus</span>
              ${nonLus > 0 ? `<span class="badge badge-danger" style="margin-left:auto">${nonLus}</span>` : ''}
            </div>
            <div class="msg-box-item" onclick="filterMsgBox(this,'broadcast')"
              style="padding:12px 16px;cursor:pointer;display:flex;align-items:center;gap:10px;border-left:3px solid transparent">
              <i class="fas fa-broadcast-tower" style="color:var(--danger);width:16px"></i>
              <span style="font-size:13px">Diffusions</span>
              <span class="badge badge-warning" style="margin-left:auto">
                ${principals.filter(m=>m.type==='broadcast'||m.destinataire_id==='all').length}
              </span>
            </div>
            <div class="msg-box-item" onclick="filterMsgBox(this,'docs')"
              style="padding:12px 16px;cursor:pointer;display:flex;align-items:center;gap:10px;border-left:3px solid transparent">
              <i class="fas fa-file-pdf" style="color:#E74C3C;width:16px"></i>
              <span style="font-size:13px">Avec document</span>
              <span class="badge badge-secondary" style="margin-left:auto">
                ${principals.filter(m=>m.document_url).length}
              </span>
            </div>
          </div>
        </div>` : ''}

        <!-- Panneau droit : liste des messages -->
        <div style="background:var(--bg-card);border-radius:14px;border:1px solid var(--border);overflow:hidden">
          <div style="padding:16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px">
            <div class="search-input-wrapper" style="flex:1">
              <i class="fas fa-search"></i>
              <input type="text" id="msgSearch" placeholder="Rechercher un message..."
                oninput="filterMessages()" />
            </div>
          </div>

          <div id="msgList" style="overflow-y:auto;max-height:620px">
            ${principals.length === 0
              ? `<div style="padding:48px;text-align:center;color:var(--text-muted)">
                   <i class="fas fa-inbox" style="font-size:48px;opacity:.3;display:block;margin-bottom:16px"></i>
                   <p>Aucun message</p>
                   ${isAdmin
                     ? `<button class="btn btn-primary" onclick="showNouveauMessage()">
                          <i class="fas fa-pen"></i> Écrire un message
                        </button>`
                     : '<p style="font-size:12px">Les messages de l\'administration apparaîtront ici</p>'}
                 </div>`
              : principals.map(m => _renderMsgItem(m, reponses, isAdmin, user)).join('')}
          </div>
        </div>
      </div>`;

    window._msgData = { principals, reponses, isAdmin, user, eglises, regions, sousRegs };

  } catch (err) {
    content.innerHTML = `<div class="empty-state">
      <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
      <h3>Erreur de chargement</h3><p>${err.message}</p>
      <button class="btn btn-primary" onclick="renderMessages()">
        <i class="fas fa-redo"></i> Réessayer
      </button></div>`;
  }
}

/* ─── Rendu d'un item de message ──────────────────────────────── */
function _renderMsgItem(m, reponses, isAdmin, user) {
  const reps = reponses.filter(r => r.message_parent_id === m.id);
  const estNonLu = !m.lu && (
    (isAdmin  && m.direction === 'eglise_to_admin') ||
    (!isAdmin && m.direction === 'admin_to_eglise')
  );

  const dateStr = m.date_envoi
    ? new Date(m.date_envoi).toLocaleString('fr-FR', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' })
    : formatDateShort(m.created_at);

  const isBroadcast    = m.destinataire_id === 'all' || m.type === 'broadcast';
  const isRegion       = m.type === 'region';
  const isSousRegion   = m.type === 'sous_region';
  const hasDoc         = !!m.document_url;

  const iconBg = isBroadcast
    ? 'linear-gradient(135deg,#ef4444,#f97316)'
    : isRegion
      ? 'linear-gradient(135deg,#10b981,#3b82f6)'
      : isSousRegion
        ? 'linear-gradient(135deg,#8b5cf6,#06b6d4)'
        : 'linear-gradient(135deg,#7c3aed,#3b82f6)';

  const iconClass = isBroadcast ? 'fa-broadcast-tower'
    : isRegion ? 'fa-globe-africa'
    : isSousRegion ? 'fa-map-marked-alt'
    : 'fa-envelope';

  const dirIcon = m.direction === 'admin_to_eglise'
    ? `<i class="fas fa-arrow-down" style="color:var(--info);font-size:10px"></i>`
    : `<i class="fas fa-arrow-up" style="color:var(--success);font-size:10px"></i>`;

  return `
    <div class="msg-item" data-sujet="${(m.sujet||'').toLowerCase()}"
      data-dir="${m.direction||''}" data-lu="${m.lu||false}"
      data-type="${m.type||'direct'}" data-hasdoc="${hasDoc}"
      onclick="viewMessage('${m.id}')"
      style="padding:16px;border-bottom:1px solid var(--border);cursor:pointer;
             transition:background .15s;${estNonLu ? 'background:rgba(124,58,237,.04)' : ''}">
      <div style="display:flex;align-items:flex-start;gap:12px">
        <div style="width:40px;height:40px;border-radius:10px;flex-shrink:0;
          background:${iconBg};display:flex;align-items:center;justify-content:center;color:#fff;font-size:16px">
          <i class="fas ${iconClass}"></i>
        </div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;flex-wrap:wrap">
            <span style="font-weight:${estNonLu ? '700' : '600'};font-size:14px;
              color:${estNonLu ? 'var(--primary)' : 'var(--text)'};
              white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px">
              ${m.sujet || '(Sans objet)'}
            </span>
            ${estNonLu   ? `<span class="badge badge-primary" style="font-size:10px">Nouveau</span>` : ''}
            ${isBroadcast ? `<span class="badge badge-warning" style="font-size:10px">Diffusion</span>` : ''}
            ${isRegion    ? `<span class="badge badge-success" style="font-size:10px">Région</span>` : ''}
            ${isSousRegion ? `<span class="badge badge-info" style="font-size:10px">Sous-région</span>` : ''}
            ${hasDoc      ? `<span class="badge badge-secondary" style="font-size:10px"><i class="fas fa-paperclip"></i> PDF</span>` : ''}
            ${dirIcon}
          </div>
          <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px">
            <i class="fas fa-user" style="margin-right:4px"></i>${m.expediteur_nom || '—'}
            ${m.destinataire_nom && m.destinataire_nom !== m.expediteur_nom
              ? ` → <i class="fas fa-church" style="margin:0 4px"></i>${m.destinataire_nom}`
              : ''}
          </div>
          <div style="font-size:12px;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            ${(m.contenu || '').replace(/<[^>]*>/g, '').slice(0, 90)}${m.contenu && m.contenu.length > 90 ? '…' : ''}
          </div>
        </div>
        <div style="text-align:right;flex-shrink:0">
          <div style="font-size:11px;color:var(--text-muted);margin-bottom:6px;white-space:nowrap">${dateStr}</div>
          ${reps.length > 0
            ? `<span class="badge badge-success" style="font-size:10px">
                 <i class="fas fa-reply"></i> ${reps.length}
               </span>`
            : ''}
        </div>
      </div>
    </div>`;
}

/* ─── Filtrage côté client ────────────────────────────────────── */
function filterMessages() {
  const q = (document.getElementById('msgSearch')?.value || '').toLowerCase();
  document.querySelectorAll('#msgList .msg-item').forEach(item => {
    const match = !q || (item.dataset.sujet || '').includes(q)
      || item.textContent.toLowerCase().includes(q);
    item.style.display = match ? '' : 'none';
  });
}

function filterMsgBox(el, box) {
  document.querySelectorAll('.msg-box-item').forEach(b => {
    b.classList.remove('active');
    b.style.borderLeftColor = 'transparent';
    b.style.background = '';
  });
  el.classList.add('active');
  el.style.borderLeftColor = 'var(--primary)';
  el.style.background = 'rgba(124,58,237,.06)';

  const d = window._msgData;
  if (!d) return;

  let filtered = d.principals;
  if (box === 'envoi')     filtered = d.principals.filter(m => m.direction === 'admin_to_eglise');
  if (box === 'reponses')  filtered = d.reponses;
  if (box === 'nonlu')     filtered = d.principals.filter(m => !m.lu);
  if (box === 'broadcast') filtered = d.principals.filter(m => m.type==='broadcast' || m.destinataire_id==='all');
  if (box === 'docs')      filtered = d.principals.filter(m => !!m.document_url);

  const list = document.getElementById('msgList');
  if (!list) return;

  list.innerHTML = filtered.length === 0
    ? `<div style="padding:40px;text-align:center;color:var(--text-muted)">
         <i class="fas fa-inbox" style="font-size:36px;opacity:.3;display:block;margin-bottom:12px"></i>
         Aucun message dans cette boîte
       </div>`
    : filtered.map(m => _renderMsgItem(m, d.reponses, d.isAdmin, d.user)).join('');
}

/* ═══════════════════════════════════════════════════════════════
   VOIR UN MESSAGE (modal)
   ═══════════════════════════════════════════════════════════════ */
async function viewMessage(id) {
  try {
    const [msgRes, allMsgs] = await Promise.all([
      API.getById('messages', id).catch(() => null),
      API.getAll('messages', { limit: 500 }).catch(() => ({ data: [] }))
    ]);

    if (!msgRes) { showToast('Message introuvable', 'error'); return; }
    const user    = Auth.getCurrentUser();
    const isAdmin = user.role === 'super_admin' || user.role === 'admin';

    /* Marquer comme lu si destinataire */
    const doitMarquer = (isAdmin  && msgRes.direction === 'eglise_to_admin') ||
                        (!isAdmin && msgRes.direction === 'admin_to_eglise');
    if (!msgRes.lu && doitMarquer) {
      API.getById('messages', id).then(msg => API.update('messages', id, { ...msg, lu: true })).catch(() => {});
    }

    /* Réponses */
    const reponses = (allMsgs.data || [])
      .filter(m => m.message_parent_id === id)
      .sort((a, b) => ((a.date_envoi||a.created_at||0) > (b.date_envoi||b.created_at||0)) ? 1 : -1);

    const dateStr = msgRes.date_envoi
      ? new Date(msgRes.date_envoi).toLocaleString('fr-FR', {
          weekday:'long', day:'numeric', month:'long', year:'numeric', hour:'2-digit', minute:'2-digit'
        })
      : '—';

    const isBroadcast  = msgRes.destinataire_id === 'all' || msgRes.type === 'broadcast';
    const isRegion     = msgRes.type === 'region';
    const isSousRegion = msgRes.type === 'sous_region';
    const hasDoc       = !!msgRes.document_url;

    const typeBg = isBroadcast ? 'linear-gradient(135deg,#ef4444,#f97316)'
      : isRegion    ? 'linear-gradient(135deg,#10b981,#3b82f6)'
      : isSousRegion ? 'linear-gradient(135deg,#8b5cf6,#06b6d4)'
      : 'linear-gradient(135deg,#7c3aed,#3b82f6)';

    const typeIcon = isBroadcast ? 'fa-broadcast-tower'
      : isRegion    ? 'fa-globe-africa'
      : isSousRegion ? 'fa-map-marked-alt'
      : 'fa-envelope';

    const destLabel = isBroadcast ? '<span class="badge badge-warning">Toutes les églises</span>'
      : isRegion     ? `<span class="badge badge-success">Région : ${msgRes.destinataire_nom}</span>`
      : isSousRegion ? `<span class="badge badge-info">Sous-région : ${msgRes.destinataire_nom}</span>`
      : (msgRes.destinataire_nom || '—');

    const html = `
      <!-- En-tête message -->
      <div style="background:linear-gradient(135deg,#faf5ff,#eff6ff);
        border:1px solid rgba(124,58,237,.15);border-radius:12px;padding:20px;margin-bottom:16px">
        <div style="display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap">
          <div style="width:48px;height:48px;border-radius:12px;flex-shrink:0;
            background:${typeBg};display:flex;align-items:center;justify-content:center;color:#fff;font-size:20px">
            <i class="fas ${typeIcon}"></i>
          </div>
          <div style="flex:1">
            <h3 style="margin:0 0 8px;font-size:17px;color:var(--primary)">${msgRes.sujet || '(Sans objet)'}</h3>
            <div style="font-size:12px;color:var(--text-muted);display:flex;flex-wrap:wrap;gap:12px">
              <span><i class="fas fa-user" style="color:var(--gold);margin-right:4px"></i>
                <strong>De :</strong> ${msgRes.expediteur_nom || '—'}</span>
              <span><i class="fas fa-church" style="color:var(--info);margin-right:4px"></i>
                <strong>À :</strong> ${destLabel}</span>
              <span><i class="fas fa-clock" style="margin-right:4px"></i>${dateStr}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Corps du message -->
      <div style="padding:20px;background:var(--accent);border-radius:10px;margin-bottom:16px;
        font-size:14px;line-height:1.7;color:var(--text);min-height:80px">
        ${msgRes.contenu || '<em style="color:var(--text-muted)">Aucun contenu</em>'}
      </div>

      <!-- Document PDF joint -->
      ${hasDoc ? `
      <div style="background:linear-gradient(135deg,#fff5f5,#fff1ee);border:1.5px solid #f87171;
        border-radius:10px;padding:14px 18px;margin-bottom:16px;display:flex;align-items:center;gap:14px">
        <div style="width:44px;height:44px;border-radius:10px;background:#EF4444;flex-shrink:0;
          display:flex;align-items:center;justify-content:center;color:#fff;font-size:20px">
          <i class="fas fa-file-pdf"></i>
        </div>
        <div style="flex:1">
          <div style="font-weight:700;font-size:14px;color:#b91c1c">Document joint</div>
          <div style="font-size:12px;color:#6b7280;margin-top:2px">${msgRes.document_nom || 'document.pdf'}</div>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-sm btn-outline" onclick="_previewPdf('${id}')" title="Aperçu">
            <i class="fas fa-eye"></i> Aperçu
          </button>
          <button class="btn btn-sm btn-primary" onclick="_imprimerPdf('${id}')" title="Imprimer">
            <i class="fas fa-print"></i> Imprimer
          </button>
          <button class="btn btn-sm btn-outline" onclick="_telechargerPdf('${id}')" title="Télécharger">
            <i class="fas fa-download"></i>
          </button>
        </div>
      </div>` : ''}

      <!-- Réponses -->
      ${reponses.length > 0 ? `
        <div style="margin-bottom:16px">
          <div style="font-size:12px;font-weight:700;color:var(--text-muted);
            text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">
            <i class="fas fa-reply" style="margin-right:6px"></i>
            ${reponses.length} réponse${reponses.length>1?'s':''}
          </div>
          ${reponses.map(r => `
            <div style="background:${r.direction==='eglise_to_admin'
              ? 'linear-gradient(135deg,#f0fdf4,#dcfce7)'
              : 'linear-gradient(135deg,#eff6ff,#dbeafe)'};
              border:1px solid ${r.direction==='eglise_to_admin'
              ? 'rgba(16,185,129,.2)' : 'rgba(59,130,246,.2)'};
              border-radius:10px;padding:14px;margin-bottom:10px">
              <div style="font-size:11px;color:var(--text-muted);margin-bottom:8px;
                display:flex;align-items:center;gap:10px">
                <i class="fas fa-${r.direction==='eglise_to_admin' ? 'church' : 'user-shield'}"
                  style="color:${r.direction==='eglise_to_admin' ? 'var(--success)' : 'var(--info)'}"></i>
                <strong>${r.expediteur_nom || '—'}</strong>
                <span style="margin-left:auto">${r.date_envoi
                  ? new Date(r.date_envoi).toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'})
                  : ''}</span>
              </div>
              <div style="font-size:13px;line-height:1.6">${r.contenu || ''}</div>
            </div>`).join('')}
        </div>` : ''}

      <!-- Formulaire de réponse -->
      <div style="border-top:1px solid var(--border);padding-top:16px">
        <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:10px">
          <i class="fas fa-reply" style="color:var(--primary);margin-right:6px"></i>Répondre
        </div>
        <textarea id="replyContent" class="form-control"
          placeholder="Votre réponse..."
          style="min-height:90px;resize:vertical;margin-bottom:12px"></textarea>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button class="btn btn-outline" onclick="closeModal()">Fermer</button>
          <button class="btn btn-primary" onclick="_envoyerReponse('${id}','${msgRes.eglise_id || ''}')">
            <i class="fas fa-paper-plane"></i> Envoyer la réponse
          </button>
        </div>
      </div>`;

    openModal(`Message : ${msgRes.sujet || '(Sans objet)'}`, html, '', null, 'large');
    _refreshMsgBadge();

  } catch (err) {
    showToast('Erreur : ' + err.message, 'error');
  }
}

/* ─── PDF : aperçu / impression / téléchargement ─────────────── */
async function _getPdfData(msgId) {
  try {
    const msg = await API.getById('messages', msgId);
    return { url: msg.document_url || '', nom: msg.document_nom || 'document.pdf' };
  } catch { return null; }
}

async function _previewPdf(msgId) {
  const data = await _getPdfData(msgId);
  if (!data || !data.url) { showToast('Document introuvable', 'error'); return; }
  /* Ouvrir dans un nouvel onglet */
  const w = window.open('', '_blank');
  if (!w) { showToast('Popup bloquée — autorisez les popups', 'warning'); return; }
  w.document.write(`<!DOCTYPE html><html><head><title>${data.nom}</title></head>
    <body style="margin:0"><embed src="${data.url}" type="application/pdf" width="100%" height="100%"></body></html>`);
}

async function _imprimerPdf(msgId) {
  const data = await _getPdfData(msgId);
  if (!data || !data.url) { showToast('Document introuvable', 'error'); return; }
  const iframe = document.createElement('iframe');
  iframe.style.cssText = 'display:none;width:0;height:0;position:absolute;left:-9999px';
  document.body.appendChild(iframe);
  iframe.src = data.url;
  iframe.onload = () => {
    try { iframe.contentWindow.print(); } catch { _previewPdf(msgId); }
    setTimeout(() => iframe.remove(), 3000);
  };
}

async function _telechargerPdf(msgId) {
  const data = await _getPdfData(msgId);
  if (!data || !data.url) { showToast('Document introuvable', 'error'); return; }
  const a = document.createElement('a');
  a.href     = data.url;
  a.download = data.nom;
  a.click();
}

/* ─── Envoyer une réponse ─────────────────────────────────────── */
async function _envoyerReponse(parentId, egliseId) {
  const contenu = document.getElementById('replyContent')?.value.trim();
  if (!contenu) { showToast('La réponse ne peut pas être vide', 'warning'); return; }

  const user    = Auth.getCurrentUser();
  const isAdmin = user.role === 'super_admin' || user.role === 'admin';

  let parent = null;
  try { parent = await API.getById('messages', parentId); } catch (_) {}

  const direction = isAdmin ? 'admin_to_eglise' : 'eglise_to_admin';
  const egId      = egliseId || (parent ? parent.eglise_id : user.eglise_id || '');

  const payload = {
    id:                generateId('msg'),
    expediteur_id:     user.id || '',
    expediteur_nom:    user.nom || user.username || '—',
    destinataire_id:   isAdmin ? egId : 'admin',
    destinataire_nom:  isAdmin ? (parent?.expediteur_nom || 'Église') : 'Administration',
    sujet:             'RE: ' + (parent?.sujet || ''),
    contenu,
    type:              'direct',
    lu:                false,
    date_envoi:        new Date().toISOString(),
    message_parent_id: parentId,
    eglise_id:         egId,
    direction,
    document_nom:      '',
    document_url:      '',
    region_id:         '',
    sous_region_id:    ''
  };

  try {
    await API.create('messages', payload);
    showToast('Réponse envoyée avec succès !', 'success');
    closeModal();
    renderMessages();
  } catch (err) {
    showToast('Erreur : ' + err.message, 'error');
  }
}

/* ═══════════════════════════════════════════════════════════════
   NOUVEAU MESSAGE (Admin uniquement)
   ═══════════════════════════════════════════════════════════════ */
async function showNouveauMessage() {
  const user = Auth.getCurrentUser();
  if (!user || (user.role !== 'super_admin' && user.role !== 'admin')) {
    showToast('Accès réservé aux administrateurs', 'warning');
    return;
  }

  let eglises = [], regions = [], sousRegs = [];
  try {
    const [er, rr, sr] = await Promise.all([
      API.getAll('eglises').catch(() => ({ data: [] })),
      API.getAll('regions').catch(() => ({ data: [] })),
      API.getAll('sous_regions').catch(() => ({ data: [] }))
    ]);
    eglises  = er.data || [];
    regions  = rr.data || [];
    sousRegs = sr.data || [];
  } catch (_) {}

  /* Stocker globalement pour usage dans les callbacks */
  window._msgEglises  = eglises;
  window._msgRegions  = regions;
  window._msgSousRegs = sousRegs;

  const html = `
    <div class="form-group">
      <label style="font-weight:600">Destinataire <span style="color:var(--danger)">*</span></label>
      <select class="form-control" id="msgDestType" onchange="_updateMsgDestOptions()">
        <option value="">— Choisir le type de destinataire —</option>
        <option value="all">📢 Toutes les églises (diffusion générale)</option>
        <option value="region">🌍 Par région</option>
        <option value="sous_region">🗺️ Par sous-région</option>
        <option value="direct">⛪ Église spécifique</option>
      </select>
    </div>

    <!-- Sous-sélection dynamique -->
    <div id="msgDestSubContainer" style="display:none" class="form-group">
      <label id="msgDestSubLabel" style="font-weight:600">Choisir</label>
      <select class="form-control" id="msgDestSub">
        <option value="">— Choisir —</option>
      </select>
    </div>

    <!-- Bannière broadcast -->
    <div id="broadcastBanner" style="display:none;background:linear-gradient(135deg,#fff7ed,#fef3c7);
      border:1px solid #f59e0b;border-radius:10px;padding:12px 16px;margin-bottom:14px">
      <p style="font-size:12px;color:#92400e;margin:0">
        <i class="fas fa-broadcast-tower" style="margin-right:6px;color:#f59e0b"></i>
        <strong>Diffusion générale :</strong> ce message sera envoyé à toutes les églises enregistrées.
      </p>
    </div>

    <div class="form-group">
      <label style="font-weight:600">Sujet <span style="color:var(--danger)">*</span></label>
      <input class="form-control" id="msgSujet" placeholder="Objet du message..." />
    </div>

    <div class="form-group">
      <label style="font-weight:600">Message <span style="color:var(--danger)">*</span></label>
      <textarea class="form-control" id="msgContenu"
        placeholder="Rédigez votre message ici..."
        style="min-height:130px;resize:vertical"></textarea>
    </div>

    <!-- Section document PDF -->
    <div style="background:linear-gradient(135deg,#fff5f5,#fef2f2);border:1px dashed #f87171;
      border-radius:10px;padding:14px;margin-bottom:14px">
      <div style="font-size:13px;font-weight:600;color:#b91c1c;margin-bottom:10px">
        <i class="fas fa-paperclip" style="margin-right:6px"></i>Document PDF joint (optionnel)
      </div>
      <input type="file" id="msgPdfFile" accept=".pdf,application/pdf"
        class="form-control" style="margin-bottom:8px"
        onchange="_onMsgPdfChange(this)" />
      <div id="msgPdfInfo" style="display:none;font-size:12px;color:var(--text-muted);
        display:flex;align-items:center;gap:8px">
        <i class="fas fa-file-pdf" style="color:#EF4444"></i>
        <span id="msgPdfName"></span>
        <button type="button" class="btn btn-sm btn-danger" onclick="_clearMsgPdf()"
          style="padding:2px 8px;font-size:11px;margin-left:auto">
          <i class="fas fa-times"></i> Supprimer
        </button>
      </div>
      <p style="font-size:11px;color:var(--text-muted);margin-top:6px;margin-bottom:0">
        <i class="fas fa-info-circle"></i> PDF uniquement. L'église pourra l'apercevoir et l'imprimer.
      </p>
    </div>

    <div style="background:var(--accent);border-radius:10px;padding:12px 14px;
      display:flex;align-items:center;gap:10px">
      <i class="fas fa-info-circle" style="color:var(--info);font-size:18px;flex-shrink:0"></i>
      <p style="font-size:12px;color:var(--text-muted);margin:0">
        Les messages sont consultables dans l'espace messagerie.
        Les comptes église verront une notification de nouveau message.
      </p>
    </div>`;

  /* Stocker le PDF en base64 */
  window._msgPdfData = null;

  openModal('✉️ Nouveau message', html, 'Envoyer', async () => {
    const destType = document.getElementById('msgDestType')?.value || '';
    const destSub  = document.getElementById('msgDestSub');
    const sujet    = document.getElementById('msgSujet')?.value.trim();
    const contenu  = document.getElementById('msgContenu')?.value.trim();

    if (!destType) { showToast('Choisissez un type de destinataire', 'warning'); return; }
    if (!sujet)    { showToast('Le sujet est requis', 'warning'); return; }
    if (!contenu)  { showToast('Le message est requis', 'warning'); return; }

    const pdfData = window._msgPdfData || {};
    const base = {
      expediteur_id:     user.id   || '',
      expediteur_nom:    user.nom  || user.username || 'Administrateur',
      sujet, contenu,
      lu:                false,
      date_envoi:        new Date().toISOString(),
      message_parent_id: '',
      direction:         'admin_to_eglise',
      document_nom:      pdfData.nom  || '',
      document_url:      pdfData.data || ''
    };

    try {
      if (destType === 'all') {
        /* Un seul enregistrement — broadcast général */
        await API.create('messages', {
          id: generateId('msg'), ...base,
          destinataire_id:  'all',
          destinataire_nom: 'Toutes les églises',
          type:             'broadcast',
          eglise_id:        '',
          region_id:        '',
          sous_region_id:   ''
        });
        showToast('Message diffusé à toutes les églises !', 'success');

      } else if (destType === 'region') {
        const regionId = destSub?.value || '';
        if (!regionId) { showToast('Choisissez une région', 'warning'); return; }
        const reg = (window._msgRegions || []).find(r => r.id === regionId);
        await API.create('messages', {
          id: generateId('msg'), ...base,
          destinataire_id:  regionId,
          destinataire_nom: reg?.nom || 'Région',
          type:             'region',
          eglise_id:        '',
          region_id:        regionId,
          sous_region_id:   ''
        });
        showToast(`Message envoyé à la région "${reg?.nom || ''}" !`, 'success');

      } else if (destType === 'sous_region') {
        const srId = destSub?.value || '';
        if (!srId) { showToast('Choisissez une sous-région', 'warning'); return; }
        const sr = (window._msgSousRegs || []).find(s => s.id === srId);
        await API.create('messages', {
          id: generateId('msg'), ...base,
          destinataire_id:  srId,
          destinataire_nom: sr?.nom || 'Sous-région',
          type:             'sous_region',
          eglise_id:        '',
          region_id:        '',
          sous_region_id:   srId
        });
        showToast(`Message envoyé à la sous-région "${sr?.nom || ''}" !`, 'success');

      } else {
        /* direct */
        const eglId = destSub?.value || '';
        if (!eglId) { showToast('Choisissez une église', 'warning'); return; }
        const egl = (window._msgEglises || []).find(e => e.id === eglId);
        await API.create('messages', {
          id: generateId('msg'), ...base,
          destinataire_id:  eglId,
          destinataire_nom: egl?.nom || 'Église',
          type:             'direct',
          eglise_id:        eglId,
          region_id:        '',
          sous_region_id:   ''
        });
        showToast('Message envoyé !', 'success');
      }

      closeModal();
      renderMessages();
    } catch (err) {
      showToast('Erreur d\'envoi : ' + err.message, 'error');
    }
  }, 'large');
}

/* Met à jour la sous-sélection selon le type choisi */
function _updateMsgDestOptions() {
  const type     = document.getElementById('msgDestType')?.value || '';
  const sub      = document.getElementById('msgDestSubContainer');
  const subLabel = document.getElementById('msgDestSubLabel');
  const subSel   = document.getElementById('msgDestSub');
  const banner   = document.getElementById('broadcastBanner');

  if (banner) banner.style.display = (type === 'all') ? 'block' : 'none';
  if (!sub || !subSel) return;

  if (type === 'all' || type === '') {
    sub.style.display = 'none';
    return;
  }
  sub.style.display = '';

  if (type === 'region') {
    subLabel.textContent = 'Région';
    const regs = window._msgRegions || [];
    subSel.innerHTML = `<option value="">— Choisir une région —</option>
      ${regs.map(r => `<option value="${r.id}">${r.nom}</option>`).join('')}`;

  } else if (type === 'sous_region') {
    subLabel.textContent = 'Sous-région';
    const srs = window._msgSousRegs || [];
    subSel.innerHTML = `<option value="">— Choisir une sous-région —</option>
      ${srs.map(s => `<option value="${s.id}">${s.nom}</option>`).join('')}`;

  } else if (type === 'direct') {
    subLabel.textContent = 'Église';
    const egls = window._msgEglises || [];
    subSel.innerHTML = `<option value="">— Choisir une église —</option>
      ${egls.map(e => `<option value="${e.id}">${e.nom}${e.ville ? ' — ' + e.ville : ''}</option>`).join('')}`;
  }
}

/* Gestion PDF */
function _onMsgPdfChange(input) {
  const file = input.files[0];
  if (!file) { _clearMsgPdf(); return; }
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    showToast('Veuillez sélectionner un fichier PDF', 'warning');
    input.value = '';
    return;
  }
  if (file.size > 5 * 1024 * 1024) {
    showToast('Le fichier PDF ne doit pas dépasser 5 Mo', 'warning');
    input.value = '';
    return;
  }
  const reader = new FileReader();
  reader.onload = (e) => {
    window._msgPdfData = { nom: file.name, data: e.target.result };
    const info = document.getElementById('msgPdfInfo');
    const name = document.getElementById('msgPdfName');
    if (info) info.style.display = 'flex';
    if (name) name.textContent   = `${file.name} (${(file.size/1024).toFixed(1)} Ko)`;
    showToast('PDF chargé : ' + file.name, 'success');
  };
  reader.readAsDataURL(file);
}

function _clearMsgPdf() {
  window._msgPdfData = null;
  const input = document.getElementById('msgPdfFile');
  if (input) input.value = '';
  const info = document.getElementById('msgPdfInfo');
  if (info) info.style.display = 'none';
}

/* ═══════════════════════════════════════════════════════════════
   BADGE NON-LUS (sidebar)
   ═══════════════════════════════════════════════════════════════ */
async function _refreshMsgBadge() {
  try {
    const user = Auth.getCurrentUser();
    if (!user) return;
    const isAdmin = user.role === 'super_admin' || user.role === 'admin';
    const res     = await API.getAll('messages', { limit: 500 }).catch(() => ({ data: [] }));
    const msgs    = res.data || [];

    let count = 0;
    if (isAdmin) {
      count = msgs.filter(m => !m.lu && m.direction === 'eglise_to_admin' && !m.message_parent_id).length;
    } else {
      count = msgs.filter(m =>
        !m.lu && m.direction === 'admin_to_eglise' && !m.message_parent_id &&
        (m.eglise_id === user.eglise_id || m.destinataire_id === 'all')
      ).length;
    }

    const badge = document.getElementById('msgNavBadge');
    if (badge) {
      badge.textContent = count > 9 ? '9+' : count;
      badge.style.display = count > 0 ? '' : 'none';
    }
  } catch (_) {}
}

/* Appel auto au chargement */
setTimeout(_refreshMsgBadge, 2000);
