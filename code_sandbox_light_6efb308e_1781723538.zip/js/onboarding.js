/**
 * onboarding.js — Guide de démarrage pas-à-pas pour nouveaux admins
 * Affiché UNE SEULE FOIS après la première connexion admin/super_admin
 * Stocké dans localStorage : cc_onboarding_done
 *
 * Étapes : Région → Sous-région → Église → Membre
 */
const Onboarding = (() => {

  const STORAGE_KEY = 'cc_onboarding_done';

  /* ── Textes des étapes ────────────────────────────────────────── */
  const STEPS = [
    {
      icon:    'fa-globe-africa',
      color:   '#3B82F6',
      bg:      '#DBEAFE',
      number:  1,
      title_fr: 'Créer une Région',
      title_en: 'Create a Region',
      desc_fr:  'Les régions sont le premier niveau de votre hiérarchie paroissiale. Commencez par créer au moins une région (ex : Région Nord, Région Sud).',
      desc_en:  'Regions are the first level of your parish hierarchy. Start by creating at least one region (e.g. North Region, South Region).',
      action_fr: 'Aller aux Régions',
      action_en: 'Go to Regions',
      page:    'regions',
      tip_fr:  '💡 Conseil : nommez vos régions selon la géographie locale (ex : Région du Littoral, Région du Nord-Ouest).',
      tip_en:  '💡 Tip: name your regions after local geography (e.g. Coastal Region, North-West Region).',
    },
    {
      icon:    'fa-map-marked-alt',
      color:   '#10B981',
      bg:      '#D1FAE5',
      number:  2,
      title_fr: 'Créer une Sous-région',
      title_en: 'Create a Sub-region',
      desc_fr:  'Chaque région contient des sous-régions. Une sous-région regroupe plusieurs paroisses géographiquement proches.',
      desc_en:  'Each region contains sub-regions. A sub-region groups several geographically close parishes.',
      action_fr: 'Aller aux Sous-régions',
      action_en: 'Go to Sub-regions',
      page:    'sous_regions',
      tip_fr:  '💡 Conseil : créez la sous-région depuis la page Régions en cliquant sur le bouton "Sous-régions" d\'une région.',
      tip_en:  '💡 Tip: create the sub-region from the Regions page by clicking the "Sub-regions" button on a region.',
    },
    {
      icon:    'fa-church',
      color:   '#7C3AED',
      bg:      '#EDE9FE',
      number:  3,
      title_fr: 'Enregistrer une Église',
      title_en: 'Register a Church',
      desc_fr:  'Ajoutez votre première paroisse avec ses informations : nom, ville, responsable, contacts et effectif estimé.',
      desc_en:  'Add your first parish with its information: name, city, leader, contacts and estimated membership.',
      action_fr: 'Aller aux Églises',
      action_en: 'Go to Churches',
      page:    'eglises',
      tip_fr:  '💡 Conseil : renseignez les coordonnées GPS de l\'église pour la faire apparaître sur la carte des paroisses.',
      tip_en:  '💡 Tip: enter the church GPS coordinates to make it appear on the parish map.',
    },
    {
      icon:    'fa-user-plus',
      color:   '#F59E0B',
      bg:      '#FEF3C7',
      number:  4,
      title_fr: 'Ajouter un Membre',
      title_en: 'Add a Member',
      desc_fr:  'Enregistrez le premier fidèle de votre paroisse. Vous pouvez importer des membres en masse via Import CSV.',
      desc_en:  'Register the first member of your parish. You can import members in bulk via CSV Import.',
      action_fr: 'Aller aux Membres',
      action_en: 'Go to Members',
      page:    'membres',
      tip_fr:  '💡 Conseil : utilisez l\'outil "Import CSV" dans la section Outils pour importer plusieurs membres à la fois.',
      tip_en:  '💡 Tip: use the "Import CSV" tool in the Tools section to import multiple members at once.',
    }
  ];

  let _currentStep = 0;
  let _overlayEl   = null;

  /* ── Helpers ─────────────────────────────────────────────────── */
  function _lang() {
    return (typeof I18n !== 'undefined' ? I18n.lang : null) || 'fr';
  }

  function _t(step, field) {
    const suffix = _lang() === 'en' ? '_en' : '_fr';
    return step[field + suffix] || step[field + '_fr'];
  }

  /* ── Rendu d'une étape ────────────────────────────────────────── */
  function _renderStep(idx) {
    const step    = STEPS[idx];
    const lang    = _lang();
    const isLast  = idx === STEPS.length - 1;
    const isFirst = idx === 0;

    /* Indicateurs de progression */
    const dots = STEPS.map((s, i) => `
      <div style="
        width:${i === idx ? 28 : 10}px;height:10px;border-radius:6px;
        background:${i === idx ? step.color : (i < idx ? '#94A3B8' : '#E2E8F0')};
        transition:all .3s ease;flex-shrink:0">
      </div>`).join('');

    const box = document.getElementById('onboardingBox');
    if (!box) return;

    box.innerHTML = `
      <!-- En-tête gradient -->
      <div style="
        background:linear-gradient(135deg,${step.color}22,${step.color}08);
        border-bottom:1px solid ${step.color}33;
        padding:28px 28px 20px;
        border-radius:20px 20px 0 0;
        position:relative">

        <!-- Bouton fermer -->
        <button onclick="Onboarding.dismiss()"
          aria-label="${lang === 'en' ? 'Close guide' : 'Fermer le guide'}"
          style="
            position:absolute;top:14px;right:14px;
            background:rgba(0,0,0,0.06);border:none;
            width:30px;height:30px;border-radius:50%;
            cursor:pointer;font-size:14px;color:#6B7280;
            display:flex;align-items:center;justify-content:center;
            transition:background .15s"
          onmouseover="this.style.background='rgba(0,0,0,0.12)'"
          onmouseout="this.style.background='rgba(0,0,0,0.06)'">
          ✕
        </button>

        <!-- Icône + Numéro -->
        <div style="display:flex;align-items:center;gap:16px;margin-bottom:14px">
          <div style="
            width:54px;height:54px;border-radius:16px;
            background:${step.bg};flex-shrink:0;
            display:flex;align-items:center;justify-content:center;
            box-shadow:0 4px 14px ${step.color}33">
            <i class="fas ${step.icon}" style="font-size:22px;color:${step.color}"></i>
          </div>
          <div>
            <div style="font-size:11px;font-weight:700;text-transform:uppercase;
              letter-spacing:.8px;color:${step.color};margin-bottom:3px">
              ${lang === 'en' ? `Step ${step.number} of ${STEPS.length}` : `Étape ${step.number} sur ${STEPS.length}`}
            </div>
            <h3 style="margin:0;font-size:18px;font-weight:700;color:#1F2937">
              ${_t(step, 'title')}
            </h3>
          </div>
        </div>

        <!-- Barre de progression -->
        <div style="display:flex;gap:6px;align-items:center">${dots}</div>
      </div>

      <!-- Corps -->
      <div style="padding:22px 28px">
        <p style="font-size:14px;line-height:1.7;color:#374151;margin:0 0 16px">
          ${_t(step, 'desc')}
        </p>

        <!-- Astuce -->
        <div style="
          background:${step.bg};
          border-left:3px solid ${step.color};
          border-radius:0 8px 8px 0;
          padding:11px 14px;
          font-size:12.5px;line-height:1.6;
          color:#374151;margin-bottom:20px">
          ${_t(step, 'tip')}
        </div>

        <!-- Actions -->
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">

          <!-- Précédent + Skip -->
          <div style="display:flex;gap:8px">
            ${!isFirst ? `
            <button onclick="Onboarding.prev()"
              style="
                padding:9px 16px;border-radius:9px;border:1.5px solid #E5E7EB;
                background:#fff;color:#374151;font-size:13px;cursor:pointer;
                font-family:'Inter',sans-serif;font-weight:500;transition:all .15s"
              onmouseover="this.style.borderColor='${step.color}';this.style.color='${step.color}'"
              onmouseout="this.style.borderColor='#E5E7EB';this.style.color='#374151'">
              ← ${lang === 'en' ? 'Back' : 'Précédent'}
            </button>` : ''}
            <button onclick="Onboarding.dismiss()"
              style="
                padding:9px 16px;border-radius:9px;border:1.5px solid #E5E7EB;
                background:#fff;color:#9CA3AF;font-size:12px;cursor:pointer;
                font-family:'Inter',sans-serif;transition:all .15s"
              onmouseover="this.style.color='#6B7280'"
              onmouseout="this.style.color='#9CA3AF'">
              ${lang === 'en' ? 'Skip for now' : 'Passer pour l\'instant'}
            </button>
          </div>

          <!-- Bouton action principal -->
          <div style="display:flex;gap:8px">
            <button onclick="Onboarding.goToPage('${step.page}')"
              style="
                padding:10px 18px;border-radius:9px;
                background:${step.color};color:#fff;border:none;
                font-size:13px;font-weight:600;cursor:pointer;
                font-family:'Inter',sans-serif;
                box-shadow:0 3px 10px ${step.color}44;
                transition:all .15s"
              onmouseover="this.style.transform='translateY(-1px)';this.style.boxShadow='0 5px 16px ${step.color}55'"
              onmouseout="this.style.transform='';this.style.boxShadow='0 3px 10px ${step.color}44'">
              <i class="fas ${step.icon}" style="margin-right:6px"></i>
              ${_t(step, 'action')}
            </button>
            <button onclick="Onboarding.${isLast ? 'finish' : 'next'}()"
              style="
                padding:10px 18px;border-radius:9px;
                background:${isLast ? '#10B981' : '#1F2937'};color:#fff;border:none;
                font-size:13px;font-weight:600;cursor:pointer;
                font-family:'Inter',sans-serif;transition:all .15s"
              onmouseover="this.style.opacity='.88'"
              onmouseout="this.style.opacity='1'">
              ${isLast
                ? (lang === 'en' ? '✓ Finish' : '✓ Terminer')
                : (lang === 'en' ? 'Next →' : 'Suivant →')}
            </button>
          </div>
        </div>
      </div>
    `;
  }

  /* ── API publique ─────────────────────────────────────────────── */
  return {

    /**
     * Vérifie si l'onboarding doit être affiché.
     * Conditions : admin/super_admin + jamais vu + aucune donnée dans la DB.
     */
    async checkAndShow() {
      if (localStorage.getItem(STORAGE_KEY)) return;

      const user = typeof Auth !== 'undefined' ? Auth.getCurrentUser() : null;
      if (!user) return;
      const isAdmin = user.role === 'super_admin' || user.role === 'admin';
      if (!isAdmin) return;

      /* Vérifie si des régions existent déjà (si oui → pas un nouvel admin) */
      try {
        const regs = await API.getAll('regions', { limit: 1 });
        if (regs && regs.data && regs.data.length > 0) return;
      } catch { /* Si erreur réseau, affiche quand même */ }

      /* Petit délai pour laisser l'app se stabiliser */
      setTimeout(() => this.show(), 1200);
    },

    /** Affiche le wizard */
    show() {
      if (_overlayEl) return;
      _currentStep = 0;

      const overlay = document.createElement('div');
      overlay.id = 'onboardingOverlay';
      overlay.setAttribute('role', 'dialog');
      overlay.setAttribute('aria-modal', 'true');
      overlay.setAttribute('aria-label', _lang() === 'en' ? 'Getting started guide' : 'Guide de démarrage');
      overlay.style.cssText = `
        position:fixed;inset:0;z-index:9000;
        background:rgba(15,15,26,0.72);
        display:flex;align-items:center;justify-content:center;
        padding:20px;backdrop-filter:blur(4px);
        animation:fadeIn .25s ease`;

      overlay.innerHTML = `
        <div id="onboardingBox" style="
          background:#fff;border-radius:20px;
          width:100%;max-width:520px;
          box-shadow:0 24px 64px rgba(0,0,0,0.28);
          overflow:hidden;
          animation:slideUp .3s cubic-bezier(.22,.68,0,1.2)">
        </div>`;

      /* Injection CSS animation si absent */
      if (!document.getElementById('onboardingStyle')) {
        const st = document.createElement('style');
        st.id = 'onboardingStyle';
        st.textContent = `
          @keyframes fadeIn  { from{opacity:0} to{opacity:1} }
          @keyframes slideUp { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
          body.dark-mode #onboardingBox { background:#1A1A2E; }
          body.dark-mode #onboardingBox p,
          body.dark-mode #onboardingBox h3 { color:#E2E8F0; }
          body.dark-mode #onboardingBox button[onclick*="dismiss"] { background:#252540;border-color:#3d3d60;color:#94A3B8; }`;
        document.head.appendChild(st);
      }

      document.body.appendChild(overlay);
      _overlayEl = overlay;

      /* Fermer au clic sur overlay (pas sur la boîte) */
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) this.dismiss();
      });

      /* Touche Escape */
      document.addEventListener('keydown', this._onKeydown.bind(this));

      _renderStep(_currentStep);
    },

    _onKeydown(e) {
      if (e.key === 'Escape') this.dismiss();
      if (e.key === 'ArrowRight') this.next();
      if (e.key === 'ArrowLeft')  this.prev();
    },

    next() {
      if (_currentStep < STEPS.length - 1) {
        _currentStep++;
        _renderStep(_currentStep);
      }
    },

    prev() {
      if (_currentStep > 0) {
        _currentStep--;
        _renderStep(_currentStep);
      }
    },

    goToPage(page) {
      this.dismiss();
      if (typeof App !== 'undefined') App.navigate(page);
    },

    finish() {
      localStorage.setItem(STORAGE_KEY, '1');
      this._remove();
      if (typeof showToast !== 'undefined') {
        const msg = _lang() === 'en'
          ? '🎉 Setup guide complete! You\'re ready to go.'
          : '🎉 Guide terminé ! Votre système est prêt.';
        showToast(msg, 'success');
      }
    },

    dismiss() {
      /* Ne marque PAS comme terminé — réapparaîtra si DB toujours vide */
      this._remove();
    },

    _remove() {
      if (_overlayEl) {
        _overlayEl.remove();
        _overlayEl = null;
      }
      document.removeEventListener('keydown', this._onKeydown.bind(this));
    },

    /** Réinitialise — utile en développement */
    reset() {
      localStorage.removeItem(STORAGE_KEY);
      console.log('[Onboarding] Réinitialisé — relancez App.init() pour tester.');
    }
  };
})();
