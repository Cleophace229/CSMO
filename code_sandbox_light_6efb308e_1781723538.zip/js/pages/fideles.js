/**
 * fideles.js — Gestion des Fidèles (Standard & Woli)
 * Fetch 100% robustes : vérification resp.ok avant .json()
 */

App.registerAddHandler('fideles', () => showFideleForm());

/* ─── Helper fetch sécurisé ───────────────────────────────── */
/* Lit toujours comme texte puis JSON.parse()
   → gère Content-Type absent, vide ou incorrect */
async function _apiFetch(url) {
  const r = await fetch(url);
  const txt = await r.text().catch(() => '');
  if (!r.ok) {
    throw new Error(`API ${r.status}${txt ? ' : ' + txt.slice(0, 120) : ''}`);
  }
  if (!txt || !txt.trim()) return {};
  try {
    return JSON.parse(txt);
  } catch {
    throw new Error(`Réponse invalide du serveur pour ${url}`);
  }
}

async function _apiPost(url, body) {
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const txt = await r.text().catch(() => '');
  if (!r.ok) {
    throw new Error(`API ${r.status}${txt ? ' : ' + txt.slice(0, 120) : ''}`);
  }
  if (!txt || !txt.trim()) return {};
  try { return JSON.parse(txt); } catch { return {}; }
}

async function _apiPut(url, body) {
  const r = await fetch(url, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const txt = await r.text().catch(() => '');
  if (!r.ok) {
    throw new Error(`API ${r.status}${txt ? ' : ' + txt.slice(0, 120) : ''}`);
  }
  if (!txt || !txt.trim()) return {};
  try { return JSON.parse(txt); } catch { return {}; }
}

async function _apiDelete(url) {
  const r = await fetch(url, { method: 'DELETE' });
  if (!r.ok && r.status !== 204) {
    throw new Error(`Erreur suppression (${r.status})`);
  }
  return true;
}

/* ─── État local ──────────────────────────────────────────── */
let _fidelesAll      = [];
let _fidelesFiltered = [];
let _fidelesPage     = 1;
const FIDELES_PER    = 25;
let _fidelesEglises  = [];
let _fidelesRegs     = [];
let _fidelesSrs      = [];

/* ─── Permissions ─────────────────────────────────────────── */
function _getFidelePerms() {
  const u = Auth.getCurrentUser();
  if (!u) return {};
  return {
    user:         u,
    isSuperAdmin: u.role === 'super_admin' || u.role === 'admin',
    isChurchAdmin:['church_admin','secretaire'].includes(u.role),
    isChurchWoli: u.role === 'church_woli',
    isRegionWoli: u.role === 'regional_woli',
    isSrWoli:     u.role === 'subregional_woli',
    isWoli:       ['regional_woli','subregional_woli','church_woli'].includes(u.role),
    churchId:     u.eglise_id       || '',
    regionId:     u.region_id       || '',
    sousRegionId: u.sous_region_id  || ''
  };
}

/* ════════════════════════════════════════════════════════════
   RENDER PRINCIPAL
════════════════════════════════════════════════════════════ */
async function renderFideles(params = {}) {
  const p = _getFidelePerms();
  setBreadcrumb([{ label: 'Fidèles' }]);
  const content = document.getElementById('pageContent');
  content.innerHTML = `<div class="loading-spinner">
    <i class="fas fa-circle-notch fa-spin"></i><p>Chargement…</p></div>`;

  try {
    /* Tous les fetch avec vérification ok */
    const [fJson, eglJson, regJson, srJson] = await Promise.all([
      _apiFetch('tables/fideles?limit=2000'),
      _apiFetch('tables/eglises?limit=300'),
      _apiFetch('tables/regions?limit=200'),
      _apiFetch('tables/sous_regions?limit=200')
    ]);

    _fidelesEglises = eglJson.data || [];
    _fidelesRegs    = regJson.data || [];
    _fidelesSrs     = srJson.data  || [];
    let raw = fJson.data || [];

    /* Filtrage selon le rôle */
    if (p.isChurchAdmin || p.isChurchWoli) {
      raw = raw.filter(f => f.church_id === p.churchId);
    } else if (p.isSrWoli) {
      raw = raw.filter(f => f.sous_region_id === p.sousRegionId && f.type_fidele === 'woli');
    } else if (p.isRegionWoli) {
      raw = raw.filter(f => f.region_id === p.regionId && f.type_fidele === 'woli');
    }

    _fidelesAll  = raw;
    _fidelesPage = 1;

    /* Titre selon le rôle */
    let titreRole = 'Tous les fidèles';
    if (p.isChurchWoli)    titreRole = 'Fidèles Woli — Ma paroisse';
    else if (p.isSrWoli)   titreRole = 'Fidèles Woli — Ma sous-région';
    else if (p.isRegionWoli) titreRole = 'Fidèles Woli — Ma région';
    else if (p.isChurchAdmin) titreRole = 'Fidèles de ma paroisse';

    const canAddStd  = p.isSuperAdmin || p.isChurchAdmin;
    const canAddWoli = p.isChurchWoli;

    /* Filtres contextuels */
    const eglSelect = p.isSuperAdmin
      ? `<select class="form-control" id="fidEglFilter" style="min-width:180px" onchange="applyFideleFilters()">
           <option value="">Toutes les paroisses</option>
           ${_fidelesEglises.map(e => `<option value="${e.id}">${e.nom}</option>`).join('')}
         </select>` : '';

    const regSelect = p.isSuperAdmin
      ? `<select class="form-control" id="fidRegFilter" style="min-width:150px" onchange="applyFideleFilters()">
           <option value="">Toutes les régions</option>
           ${_fidelesRegs.map(r => `<option value="${r.id}">${r.nom}</option>`).join('')}
         </select>` : '';

    const typeSelect = (p.isSuperAdmin || p.isChurchAdmin)
      ? `<select class="form-control" id="fidTypeFilter" style="min-width:130px" onchange="applyFideleFilters()">
           <option value="">Tous les types</option>
           <option value="standard">Standard</option>
           <option value="woli">Woli</option>
         </select>` : '';

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-user-friends" style="margin-right:10px"></i>${titreRole}
          </h2>
          <p id="fidelesCount" style="color:var(--text-muted);margin:4px 0 0">${raw.length} fidèle(s)</p>
        </div>
        <div class="page-header-actions" style="gap:8px;flex-wrap:wrap">
          ${canAddStd  ? `<button class="btn btn-primary" onclick="showFideleForm('standard')">
            <i class="fas fa-user-plus"></i> Nouveau fidèle</button>` : ''}
          ${canAddWoli ? `<button class="btn" style="background:linear-gradient(135deg,#922B21,#CB4335);color:#fff"
            onclick="showFideleForm('woli')">
            <i class="fas fa-eye"></i> Nouveau Woli</button>` : ''}
          <button class="btn btn-outline" onclick="imprimerFideles()">
            <i class="fas fa-print"></i> Imprimer PDF
          </button>
        </div>
      </div>

      ${_buildWoliBadgeBar(raw)}

      <div class="page-search" style="flex-wrap:wrap;gap:8px;margin-bottom:16px">
        <div class="search-input-wrapper" style="flex:1;min-width:200px">
          <i class="fas fa-search"></i>
          <input type="text" id="fidSearch" placeholder="Rechercher nom, prénom, téléphone…"
            oninput="applyFideleFilters()" />
        </div>
        ${regSelect}
        ${eglSelect}
        ${typeSelect}
        <select class="form-control" id="fidSexeFilter" style="min-width:110px" onchange="applyFideleFilters()">
          <option value="">Tous sexes</option>
          <option value="homme">♂ Hommes</option>
          <option value="femme">♀ Femmes</option>
        </select>
        <select class="form-control" id="fidStatutFilter" style="min-width:120px" onchange="applyFideleFilters()">
          <option value="">Tous statuts</option>
          <option value="actif">Actifs</option>
          <option value="inactif">Inactifs</option>
        </select>
      </div>

      <div id="fidelesTableWrap"></div>
      <div id="fidelesPagination"></div>`;

    applyFideleFilters();

  } catch (err) {
    console.error('[Fideles] Erreur chargement:', err);
    content.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
        <h3>Erreur de chargement</h3>
        <p style="color:var(--text-muted);max-width:400px">${err.message}</p>
        <button class="btn btn-primary" onclick="renderFideles()">
          <i class="fas fa-redo"></i> Réessayer
        </button>
      </div>`;
  }
}

/* ─── Bandeau statistiques ────────────────────────────────── */
function _buildWoliBadgeBar(raw) {
  if (!raw.length) return '';
  const total    = raw.length;
  const woli     = raw.filter(f => f.type_fidele === 'woli').length;
  const standard = total - woli;
  return `
    <div style="display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap">
      <div class="stat-card" style="flex:1;min-width:120px;padding:12px 16px">
        <div class="stat-icon"><i class="fas fa-users"></i></div>
        <div class="stat-info"><h3>${total}</h3><p>Total</p></div>
      </div>
      <div class="stat-card success" style="flex:1;min-width:120px;padding:12px 16px">
        <div class="stat-icon"><i class="fas fa-user"></i></div>
        <div class="stat-info"><h3>${standard}</h3><p>Standard</p></div>
      </div>
      <div class="stat-card" style="flex:1;min-width:120px;padding:12px 16px;
        background:linear-gradient(135deg,rgba(146,43,33,0.08),rgba(203,67,53,0.05));
        border-left:3px solid #922B21">
        <div class="stat-icon" style="background:rgba(146,43,33,0.12)">
          <i class="fas fa-eye" style="color:#922B21"></i></div>
        <div class="stat-info"><h3>${woli}</h3><p>Woli</p></div>
      </div>
    </div>`;
}

/* ─── Filtres ─────────────────────────────────────────────── */
function applyFideleFilters() {
  const search = (document.getElementById('fidSearch')?.value       || '').toLowerCase().trim();
  const type   = document.getElementById('fidTypeFilter')?.value    || '';
  const sexe   = document.getElementById('fidSexeFilter')?.value    || '';
  const statut = document.getElementById('fidStatutFilter')?.value  || '';
  const eglId  = document.getElementById('fidEglFilter')?.value     || '';
  const regId  = document.getElementById('fidRegFilter')?.value     || '';

  let list = _fidelesAll;
  if (search) list = list.filter(f =>
    (`${f.nom||''} ${f.prenom||''} ${f.telephone||''}`).toLowerCase().includes(search));
  if (type)   list = list.filter(f => (f.type_fidele || 'standard') === type);
  if (sexe)   list = list.filter(f => f.sexe === sexe);
  if (statut) list = list.filter(f => (f.statut || 'actif') === statut);
  if (eglId)  list = list.filter(f => f.church_id === eglId);
  if (regId)  list = list.filter(f => f.region_id === regId);

  _fidelesFiltered = list;
  _fidelesPage = 1;

  const cnt = document.getElementById('fidelesCount');
  if (cnt) cnt.textContent = `${list.length} fidèle(s)`;
  renderFidelesTable(_getFidelePerms());
}

/* ─── Tableau paginé ──────────────────────────────────────── */
function renderFidelesTable(p) {
  if (!p) p = _getFidelePerms();
  const wrap = document.getElementById('fidelesTableWrap');
  if (!wrap) return;

  const total = _fidelesFiltered.length;
  const pages = Math.ceil(total / FIDELES_PER) || 1;
  const start = (_fidelesPage - 1) * FIDELES_PER;
  const slice = _fidelesFiltered.slice(start, start + FIDELES_PER);

  if (total === 0) {
    wrap.innerHTML = `<div class="empty-state">
      <i class="fas fa-user-friends" style="color:var(--text-muted)"></i>
      <h3>Aucun fidèle trouvé</h3>
      <p>Modifiez vos filtres ou ajoutez un nouveau fidèle.</p>
    </div>`;
    const pag = document.getElementById('fidelesPagination');
    if (pag) pag.innerHTML = '';
    return;
  }

  wrap.innerHTML = `
    <div class="table-wrapper">
      <table>
        <thead><tr>
          <th>Nom / Prénom</th>
          <th>Sexe</th>
          <th>Téléphone</th>
          <th>Église</th>
          <th>Type</th>
          <th>Statut</th>
          <th>Actions</th>
        </tr></thead>
        <tbody>
          ${slice.map(f => _fideleRow(f, p)).join('')}
        </tbody>
      </table>
    </div>`;

  const pag = document.getElementById('fidelesPagination');
  if (!pag) return;
  if (pages <= 1) { pag.innerHTML = ''; return; }
  pag.innerHTML = `
    <div class="pagination" style="display:flex;gap:6px;justify-content:center;margin-top:16px;flex-wrap:wrap">
      ${Array.from({length: pages}, (_, i) => `
        <button class="btn btn-sm ${i+1 === _fidelesPage ? 'btn-primary' : 'btn-outline'}"
          onclick="_fidelesPage=${i+1};renderFidelesTable()">${i+1}</button>`).join('')}
    </div>`;
}

/* ─── Ligne tableau ───────────────────────────────────────── */
function _fideleRow(f, p) {
  const isWoliFiche = (f.type_fidele || 'standard') === 'woli';
  const egl  = _fidelesEglises.find(e => e.id === f.church_id);
  const act  = (f.statut || 'actif') === 'actif';
  const safe = (f.id || '').replace(/'/g, "\\'");
  const nom  = `${f.prenom||''} ${f.nom||''}`.trim().replace(/'/g, "\\'");

  const canEdit = (
    p.isSuperAdmin ||
    (p.isChurchAdmin && !isWoliFiche  && f.church_id === p.churchId) ||
    (p.isChurchWoli  &&  isWoliFiche  && f.church_id === p.churchId)
  );

  const woliTag = isWoliFiche
    ? `<span style="display:inline-flex;align-items:center;gap:4px;background:#f9e0de;
         color:#922B21;border:1px solid #e8a09a;border-radius:20px;
         padding:2px 9px;font-size:11px;font-weight:700">
         <i class="fas fa-eye" style="font-size:9px"></i> Woli</span>`
    : `<span class="badge badge-secondary" style="font-size:11px">Standard</span>`;

  const init = ((f.prenom||f.nom||'?')[0]||'?').toUpperCase();

  return `<tr>
    <td>
      <div style="display:flex;align-items:center;gap:10px">
        <div style="width:34px;height:34px;border-radius:50%;flex-shrink:0;font-weight:700;
          font-size:13px;display:flex;align-items:center;justify-content:center;
          background:${isWoliFiche ? '#f9e0de' : 'var(--accent)'};
          color:${isWoliFiche ? '#922B21' : 'var(--primary)'}">
          ${init}
        </div>
        <div>
          <div style="font-weight:600">${f.prenom||''} ${f.nom||''}</div>
          ${f.adresse ? `<div style="font-size:11px;color:var(--text-muted)">${f.adresse}</div>` : ''}
        </div>
      </div>
    </td>
    <td>${f.sexe === 'femme'
      ? '<span style="color:#db2777">♀ Femme</span>'
      : '<span style="color:#2563eb">♂ Homme</span>'}</td>
    <td style="font-size:13px">${f.telephone||'—'}</td>
    <td style="font-size:12px">${egl
      ? `<i class="fas fa-church" style="color:var(--primary);margin-right:4px"></i>${egl.nom}`
      : '<em style="color:var(--text-muted)">—</em>'}</td>
    <td>${woliTag}</td>
    <td>${act
      ? '<span class="badge badge-success"><i class="fas fa-circle" style="font-size:7px"></i> Actif</span>'
      : '<span class="badge badge-secondary"><i class="fas fa-circle" style="font-size:7px"></i> Inactif</span>'}</td>
    <td><div class="td-actions">
      ${canEdit ? `<button class="btn btn-xs btn-outline" onclick="showFideleForm(null,'${safe}')" title="Modifier">
        <i class="fas fa-edit"></i></button>` : ''}
      ${canEdit ? `<button class="btn btn-xs btn-danger" onclick="deleteFidele('${safe}','${nom}')" title="Supprimer">
        <i class="fas fa-trash"></i></button>` : ''}
      ${!canEdit ? '<span style="font-size:11px;color:var(--text-muted)">Lecture seule</span>' : ''}
    </div></td>
  </tr>`;
}

/* ════════════════════════════════════════════════════════════
   FORMULAIRE CRÉATION / MODIFICATION
════════════════════════════════════════════════════════════ */
async function showFideleForm(defaultType = null, editId = null) {
  const p    = _getFidelePerms();
  let data   = {};
  const title = editId ? 'Modifier le fidèle' : 'Nouveau fidèle';

  if (editId) {
    try {
      data = await _apiFetch(`tables/fideles/${editId}`);
    } catch (err) {
      showToast('Impossible de charger les données : ' + err.message, 'error');
      return;
    }
  }

  const forcedType = p.isChurchWoli
    ? 'woli'
    : (defaultType || data.type_fidele || 'standard');

  const typeHTML = (p.isSuperAdmin || p.isChurchAdmin)
    ? `<select class="form-control" id="fidFormType">
         <option value="standard" ${forcedType!=='woli'?'selected':''}>Standard</option>
         <option value="woli"     ${forcedType==='woli' ?'selected':''}>Woli</option>
       </select>`
    : `<input class="form-control" readonly value="${forcedType==='woli'?'Woli':'Standard'}" />
       <input type="hidden" id="fidFormType" value="${forcedType}" />`;

  const eglHTML = p.isSuperAdmin
    ? `<select class="form-control" id="fidFormChurch">
         <option value="">— Sélectionner une paroisse —</option>
         ${_fidelesEglises.map(e =>
           `<option value="${e.id}" ${(data.church_id||'')=== e.id ? 'selected':''}>${e.nom}</option>`
         ).join('')}
       </select>`
    : `<input class="form-control" readonly
         value="${(_fidelesEglises.find(e => e.id === p.churchId)||{}).nom || 'Ma paroisse'}" />
       <input type="hidden" id="fidFormChurch" value="${p.churchId}" />`;

  openModal(title, `
    <div class="form-row">
      <div class="form-group">
        <label>Prénom <span style="color:var(--danger)">*</span></label>
        <input class="form-control" id="fidFormPrenom" value="${data.prenom||''}" placeholder="Prénom" />
      </div>
      <div class="form-group">
        <label>Nom <span style="color:var(--danger)">*</span></label>
        <input class="form-control" id="fidFormNom" value="${data.nom||''}" placeholder="Nom de famille" />
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Date de naissance</label>
        <input class="form-control" type="date" id="fidFormDob" value="${data.date_naissance||''}" />
      </div>
      <div class="form-group">
        <label>Sexe</label>
        <select class="form-control" id="fidFormSexe">
          <option value="homme" ${(data.sexe||'homme')==='homme'?'selected':''}>♂ Homme</option>
          <option value="femme" ${data.sexe==='femme'?'selected':''}>♀ Femme</option>
        </select>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Téléphone</label>
        <input class="form-control" id="fidFormTel" value="${data.telephone||''}" placeholder="+229 01 XX XX XX" />
      </div>
      <div class="form-group">
        <label>Statut</label>
        <select class="form-control" id="fidFormStatut">
          <option value="actif"   ${(data.statut||'actif')==='actif'?'selected':''}>Actif</option>
          <option value="inactif" ${data.statut==='inactif'?'selected':''}>Inactif</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label>Adresse</label>
      <input class="form-control" id="fidFormAdresse" value="${data.adresse||''}" placeholder="Quartier, ville…" />
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Église / Paroisse</label>
        ${eglHTML}
      </div>
      <div class="form-group">
        <label>Type de fidèle</label>
        ${typeHTML}
      </div>
    </div>
    <div class="form-group">
      <label>Notes</label>
      <textarea class="form-control" id="fidFormNotes" rows="2">${data.notes||''}</textarea>
    </div>
  `, editId ? 'Modifier' : 'Enregistrer', async () => {
    const nom    = (document.getElementById('fidFormNom')?.value    || '').trim();
    const prenom = (document.getElementById('fidFormPrenom')?.value || '').trim();
    const church = document.getElementById('fidFormChurch')?.value  || p.churchId;
    const type   = document.getElementById('fidFormType')?.value    || forcedType;

    if (!nom)    { showToast('Le nom est obligatoire.', 'error'); return; }
    if (!church) { showToast('Sélectionnez une église.', 'error'); return; }

    const egl = _fidelesEglises.find(e => e.id === church) || {};
    const body = {
      nom,
      prenom,
      date_naissance:       document.getElementById('fidFormDob')?.value     || '',
      sexe:                 document.getElementById('fidFormSexe')?.value    || 'homme',
      telephone:            document.getElementById('fidFormTel')?.value     || '',
      adresse:              document.getElementById('fidFormAdresse')?.value || '',
      statut:               document.getElementById('fidFormStatut')?.value  || 'actif',
      notes:                document.getElementById('fidFormNotes')?.value   || '',
      church_id:            church,
      church_nom:           egl.nom            || '',
      region_id:            egl.region_id      || '',
      sous_region_id:       egl.sous_region_id || '',
      type_fidele:          type,
      recorded_by_woli_id:  p.isChurchWoli ? (p.user.id  || '') : (data.recorded_by_woli_id  || ''),
      recorded_by_woli_nom: p.isChurchWoli ? (p.user.nom || p.user.username || '') : (data.recorded_by_woli_nom || '')
    };

    try {
      if (editId) {
        const full = await _apiFetch(`tables/fideles/${editId}`);
        await _apiPut(`tables/fideles/${editId}`, { ...full, ...body });
        showToast('Fidèle modifié avec succès.', 'success');
      } else {
        body.id = 'f_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
        await _apiPost('tables/fideles', body);
        showToast('Fidèle enregistré avec succès.', 'success');
      }
      closeModal();
      renderFideles();
    } catch (err) {
      showToast('Erreur : ' + err.message, 'error');
    }
  });
}

/* ─── Suppression ─────────────────────────────────────────── */
async function deleteFidele(id, nom) {
  if (!confirm(`Supprimer le fidèle "${nom}" ?`)) return;
  try {
    await _apiDelete(`tables/fideles/${id}`);
    showToast('Fidèle supprimé.', 'success');
    renderFideles();
  } catch (err) {
    showToast('Erreur suppression : ' + err.message, 'error');
  }
}

/* ════════════════════════════════════════════════════════════
   IMPRESSION PDF
════════════════════════════════════════════════════════════ */
async function imprimerFideles() {
  const p    = _getFidelePerms();
  const list = _fidelesFiltered.length > 0 ? _fidelesFiltered : _fidelesAll;

  if (list.length === 0) {
    showToast('Aucun fidèle à imprimer.', 'warning');
    return;
  }

  openModal('Impression PDF — Choisir le type', `
    <p style="margin-bottom:16px;color:var(--text-muted)">
      Sélectionnez les fidèles à inclure dans le PDF.</p>
    <div class="form-group">
      <label>Filtrer par type</label>
      <select class="form-control" id="printTypeChoix">
        <option value="tous">Tous (${list.length})</option>
        <option value="standard">Standard uniquement (${list.filter(f=>f.type_fidele!=='woli').length})</option>
        <option value="woli">Woli uniquement (${list.filter(f=>f.type_fidele==='woli').length})</option>
      </select>
    </div>
  `, 'Imprimer', () => {
    const choix = document.getElementById('printTypeChoix')?.value || 'tous';
    let toPrint = list;
    if (choix === 'standard') toPrint = list.filter(f => (f.type_fidele||'standard') !== 'woli');
    if (choix === 'woli')     toPrint = list.filter(f => f.type_fidele === 'woli');
    closeModal();
    _generateFidelesPDF(toPrint, choix, p);
  });
}

function _generateFidelesPDF(list, choix, p) {
  try {
    const jsPDFClass = (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
    if (!jsPDFClass) { showToast('Librairie PDF non chargée.', 'error'); return; }

    const doc     = new jsPDFClass({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const now     = new Date();
    const dateStr = now.toLocaleDateString('fr-FR', { year:'numeric', month:'long', day:'numeric' });
    const typeLbl = choix==='woli' ? 'Fidèles Woli' : choix==='standard' ? 'Fidèles Standard' : 'Tous les Fidèles';
    const scopeLbl = (p.isChurchWoli||p.isChurchAdmin)
      ? (_fidelesEglises.find(e=>e.id===p.churchId)?.nom || 'Ma paroisse')
      : p.isSrWoli ? 'Sous-région' : p.isRegionWoli ? 'Région' : 'Global';

    doc.setFillColor(108, 52, 131);
    doc.rect(0, 0, 297, 22, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(15); doc.setFont('helvetica','bold');
    doc.text('Recensement Paroissial — ' + typeLbl, 14, 10);
    doc.setFontSize(9);  doc.setFont('helvetica','normal');
    doc.text(`Périmètre : ${scopeLbl}  |  Édité le : ${dateStr}  |  Total : ${list.length} fidèle(s)`, 14, 17);

    const showType = choix === 'tous';
    const head = [['N°','Prénom','Nom','Sexe','Téléphone','Adresse','Église']];
    if (showType) head[0].push('Type');
    head[0].push('Statut');

    const rows = list.map((f, i) => {
      const eglNom = f.church_nom || (_fidelesEglises.find(e=>e.id===f.church_id)?.nom || '—');
      const row = [i+1, f.prenom||'', f.nom||'',
        f.sexe==='femme'?'F':'M', f.telephone||'—', f.adresse||'—', eglNom];
      if (showType) row.push(f.type_fidele==='woli'?'Woli':'Standard');
      row.push((f.statut||'actif')==='actif'?'Actif':'Inactif');
      return row;
    });

    doc.autoTable({
      head, body: rows, startY: 26,
      styles: { fontSize: 8, cellPadding: 2.5 },
      headStyles: { fillColor:[108,52,131], textColor:255, fontStyle:'bold' },
      alternateRowStyles: { fillColor:[248,245,252] }
    });

    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(7); doc.setTextColor(150);
      doc.text(`Page ${i} / ${pageCount}`, 148, 200, { align:'center' });
      doc.text('Signature : ___________________________', 220, 200);
    }

    doc.save(`fideles_${choix}_${now.toISOString().slice(0,10)}.pdf`);
    showToast(`PDF généré : ${list.length} fidèle(s)`, 'success');
  } catch (err) {
    showToast('Erreur PDF : ' + err.message, 'error');
  }
}
