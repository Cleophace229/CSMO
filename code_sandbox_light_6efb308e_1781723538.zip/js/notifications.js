/**
 * notifications.js — Notifications automatiques
 * - Anniversaires des membres
 * - Cotisations en retard
 * - Prochains événements
 * - Centre de notifications dans la topbar
 */

const Notifications = {
  items: [],
  seen: new Set(JSON.parse(localStorage.getItem('notif_seen') || '[]')),

  async refresh() {
    this.items = [];
    const today = new Date();
    const todayMD = `${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
    const todayStr = today.toISOString().split('T')[0];

    try {
      const [mems, cots, evs] = await Promise.all([
        API.getAll('membres'),
        API.getAll('cotisations'),
        API.getAll('evenements')
      ]);

      // ── Anniversaires du jour ──────────────────────────────
      mems.data.forEach(m => {
        if (!m.date_naissance) return;
        const dob = m.date_naissance.slice(5); // MM-DD
        if (dob === todayMD) {
          this.items.push({
            id: `bday_${m.id}`,
            type: 'birthday',
            icon: 'fa-birthday-cake',
            color: '#D4AC0D',
            title: `Anniversaire de ${m.prenom} ${m.nom}`,
            body: `Aujourd'hui est le jour de naissance de ${m.prenom} ${m.nom}.`,
            time: 'Aujourd\'hui',
            action: () => viewMembre(m.id)
          });
        }
      });

      // ── Anniversaires dans 7 jours ─────────────────────────
      mems.data.forEach(m => {
        if (!m.date_naissance) return;
        const dob = m.date_naissance;
        const year = today.getFullYear();
        const bday = new Date(`${year}-${dob.slice(5)}`);
        const diff = Math.ceil((bday - today) / 86400000);
        if (diff > 0 && diff <= 7) {
          this.items.push({
            id: `bday7_${m.id}`,
            type: 'birthday_soon',
            icon: 'fa-gift',
            color: '#D68910',
            title: `Anniversaire dans ${diff} jour(s)`,
            body: `${m.prenom} ${m.nom} fête son anniversaire le ${dob.slice(5).split('-').reverse().join('/')}.`,
            time: `Dans ${diff} jour(s)`,
            action: () => viewMembre(m.id)
          });
        }
      });

      // ── Cotisations en retard ──────────────────────────────
      const retard = cots.data.filter(c => c.statut === 'en retard');
      if (retard.length > 0) {
        this.items.push({
          id: 'cots_retard',
          type: 'cotisation_retard',
          icon: 'fa-exclamation-triangle',
          color: '#C0392B',
          title: `${retard.length} cotisation(s) en retard`,
          body: 'Des membres ont des cotisations impayées en retard.',
          time: 'Maintenant',
          action: () => App.navigate('cotisations')
        });
      }

      // (Cotisations "en attente" supprimées du système)

      // ── Événements dans 3 jours ────────────────────────────
      evs.data.forEach(ev => {
        if (!ev.date_debut) return;
        const diff = Math.ceil((new Date(ev.date_debut) - today) / 86400000);
        if (diff >= 0 && diff <= 3) {
          this.items.push({
            id: `ev3_${ev.id}`,
            type: 'event_soon',
            icon: 'fa-calendar-check',
            color: '#1A5276',
            title: `Événement imminent : ${ev.titre}`,
            body: `${ev.titre} aura lieu le ${ev.date_debut}${ev.lieu ? ' à ' + ev.lieu : ''}.`,
            time: diff === 0 ? 'Aujourd\'hui' : `Dans ${diff} jour(s)`,
            action: () => App.navigate('calendrier')
          });
        }
      });

      // ── Fêtes religieuses dans 7 jours ────────────────────
      if (typeof _getFetesReligieuses === 'function') {
        const fetes = _getFetesReligieuses();
        fetes.filter(f => f.jours >= 0 && f.jours <= 7).forEach(f => {
          this.items.push({
            id: `fete_${f.nom.replace(/\s/g,'_')}_${today.getFullYear()}`,
            type: 'fete',
            icon: 'fa-star',
            color: '#D4AC0D',
            title: f.jours === 0
              ? `🎉 Aujourd'hui : ${f.nom} !`
              : `Fête liturgique : ${f.nom}`,
            body: f.jours === 0
              ? `Bonne fête de ${f.nom} à toutes les paroisses !`
              : `${f.nom} aura lieu dans ${f.jours} jour${f.jours>1?'s':''} (${f.date}).`,
            time: f.jours === 0 ? 'Aujourd\'hui' : `Dans ${f.jours} jour(s)`,
            action: () => App.navigate('calendrier')
          });
        });
      }

      // ── Messages non lus (réponses églises pour admin) ──────
      try {
        const user = Auth.getCurrentUser();
        if (user && (user.role === 'super_admin' || user.role === 'admin')) {
          const msgRes = await API.getAll('messages', { limit: 300 }).catch(() => ({ data: [] }));
          const nonLus = (msgRes.data || []).filter(m =>
            !m.lu && m.direction === 'eglise_to_admin'
          ).length;
          if (nonLus > 0) {
            this.items.push({
              id: `msgs_nonlus_${todayStr}`,
              type: 'messages',
              icon: 'fa-envelope',
              color: '#7C3AED',
              title: `${nonLus} réponse${nonLus>1?'s':''} non lue${nonLus>1?'s':''}`,
              body: 'Des églises ont répondu à vos messages.',
              time: 'Maintenant',
              action: () => App.navigate('messages')
            });
          }
        } else if (user && user.eglise_id) {
          const msgRes = await API.getAll('messages', { limit: 300 }).catch(() => ({ data: [] }));
          const nonLus = (msgRes.data || []).filter(m =>
            !m.lu && m.direction === 'admin_to_eglise' &&
            (m.eglise_id === user.eglise_id || m.destinataire_id === 'all')
          ).length;
          if (nonLus > 0) {
            this.items.push({
              id: `msgs_egl_${user.eglise_id}_${todayStr}`,
              type: 'messages',
              icon: 'fa-envelope',
              color: '#7C3AED',
              title: `${nonLus} message${nonLus>1?'s':''} de l'administration`,
              body: 'Vous avez des messages non lus de l\'administration.',
              time: 'Maintenant',
              action: () => App.navigate('messages')
            });
          }
        }
      } catch (_) {}

    } catch (e) { /* silently fail */ }

    this.render();
  },

  get unreadCount() {
    return this.items.filter(n => !this.seen.has(n.id)).length;
  },

  markAllRead() {
    this.items.forEach(n => this.seen.add(n.id));
    localStorage.setItem('notif_seen', JSON.stringify([...this.seen]));
    this.render();
  },

  markRead(id) {
    this.seen.add(id);
    localStorage.setItem('notif_seen', JSON.stringify([...this.seen]));
    this.render();
  },

  render() {
    const dropdown = document.getElementById('notifDropdown');
    const count = this.unreadCount;

    if (typeof updateNotifBadge === 'function') updateNotifBadge(count);

    if (dropdown && dropdown.classList.contains('open')) {
      this.renderDropdown();
    }
  },

  renderDropdown() {
    const dd = document.getElementById('notifDropdown');
    if (!dd) return;
    const sorted = [...this.items].sort((a, b) => (this.seen.has(a.id) ? 1 : -1) - (this.seen.has(b.id) ? 1 : -1));

    dd.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid var(--border)">
        <span style="font-weight:700;font-size:14px">Notifications</span>
        ${this.unreadCount > 0 ? `<button onclick="Notifications.markAllRead()" style="background:none;border:none;color:var(--primary);font-size:12px;cursor:pointer;font-family:inherit">Tout marquer lu</button>` : ''}
      </div>
      ${sorted.length === 0 ? `<div style="padding:32px;text-align:center;color:var(--text-muted)"><i class="fas fa-bell-slash" style="font-size:32px;display:block;margin-bottom:10px;opacity:0.3"></i>Aucune notification</div>` :
        sorted.map(n => `
          <div style="display:flex;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border);cursor:pointer;background:${this.seen.has(n.id) ? '#fff' : '#f8f0fd'};transition:background 0.2s"
            onmouseover="this.style.background='#f4f6f9'" onmouseout="this.style.background='${this.seen.has(n.id) ? '#fff' : '#f8f0fd'}'"
            onclick="Notifications.markRead('${n.id}');${n.action ? 'closeNotifDropdown();' : ''}n_action_${n.id}()">
            <div style="width:36px;height:36px;border-radius:10px;background:${n.color}22;display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fas ${n.icon}" style="color:${n.color};font-size:15px"></i>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-weight:${this.seen.has(n.id) ? '500' : '700'};font-size:13px;color:var(--text)">${n.title}</div>
              <div style="font-size:12px;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${n.body}</div>
              <div style="font-size:11px;color:var(--text-light);margin-top:2px">${n.time}</div>
            </div>
            ${!this.seen.has(n.id) ? `<div style="width:8px;height:8px;border-radius:50%;background:${n.color};margin-top:6px;flex-shrink:0"></div>` : ''}
          </div>
          <script>function n_action_${n.id.replace(/[^a-zA-Z0-9_]/g,'_')}(){}</script>
        `).join('')
      }
    `;

    // Attach click handlers dynamically
    sorted.forEach(n => {
      const fn = `n_action_${n.id.replace(/[^a-zA-Z0-9_]/g,'_')}`;
      window[fn] = n.action || function(){};
    });
  },

  toggle() {
    const dd = document.getElementById('notifDropdown');
    if (!dd) return;
    const isOpen = dd.classList.toggle('open');
    dd.style.display = isOpen ? 'block' : 'none';
    if (isOpen) {
      this.renderDropdown();
    }
  }
};

function closeNotifDropdown() {
  const dd = document.getElementById('notifDropdown');
  if (dd) { dd.classList.remove('open'); dd.style.display = 'none'; }
}

// Close on outside click
document.addEventListener('click', e => {
  const btn = document.getElementById('notifBtn');
  const dd = document.getElementById('notifDropdown');
  if (dd && btn && !btn.contains(e.target) && !dd.contains(e.target)) {
    dd.classList.remove('open');
  }
});

// Page dédiée aux notifications
async function renderNotifications() {
  setBreadcrumb([{ label: 'Notifications' }]);
  await Notifications.refresh();
  const content = document.getElementById('pageContent');

  content.innerHTML = `
    <div class="page-header">
      <div class="page-header-left">
        <h2><i class="fas fa-bell" style="color:var(--warning);margin-right:10px"></i>Centre de notifications</h2>
        <p>${Notifications.items.length} notification(s) active(s)</p>
      </div>
      <div class="page-header-actions">
        ${Notifications.unreadCount > 0 ? `<button class="btn btn-outline" onclick="Notifications.markAllRead();renderNotifications()"><i class="fas fa-check-double"></i> Tout marquer lu</button>` : ''}
      </div>
    </div>

    ${Notifications.items.length === 0 ? `<div class="empty-state"><i class="fas fa-bell-slash"></i><h3>Aucune notification</h3><p>Tout est à jour !</p></div>` : ''}

    <div style="display:flex;flex-direction:column;gap:12px">
      ${Notifications.items.map(n => `
        <div class="card" style="border-left:4px solid ${n.color};cursor:pointer;margin-bottom:0" onclick="Notifications.markRead('${n.id}');${n.action ? n.action.toString().replace(/\(\s*\)\s*=>/,'').replace(/[{}]/g,'').trim() + ';' : ''}renderNotifications()">
          <div class="card-body" style="display:flex;gap:14px;align-items:center;padding:16px 20px">
            <div style="width:44px;height:44px;border-radius:12px;background:${n.color}22;display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fas ${n.icon}" style="color:${n.color};font-size:20px"></i>
            </div>
            <div style="flex:1">
              <div style="font-weight:${Notifications.seen.has(n.id) ? '500' : '700'};font-size:14px;color:var(--text)">${n.title}</div>
              <div style="font-size:13px;color:var(--text-muted);margin-top:2px">${n.body}</div>
              <div style="font-size:11px;color:var(--text-light);margin-top:4px"><i class="fas fa-clock" style="margin-right:4px"></i>${n.time}</div>
            </div>
            ${!Notifications.seen.has(n.id) ? `<span class="badge" style="background:${n.color}22;color:${n.color}">Nouveau</span>` : '<span class="badge badge-secondary">Lu</span>'}
          </div>
        </div>`).join('')}
    </div>
  `;
}
