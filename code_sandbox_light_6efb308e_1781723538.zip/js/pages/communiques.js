/**
 * communiques.js — Module Communiqués CSMO
 * Diffusion officielle de l'ECC par le Saint Siège (super_admin uniquement)
 * 
 * Ciblage :
 *   - Toutes les Églises
 *   - Une Région spécifique
 *   - Une Sous-région spécifique
 *   - Une Église spécifique
 *   - Toutes les Chorales
 *   - La Chorale d'une Église spécifique
 *
 * Table : communiques
 * Colonnes : id, titre, contenu, categorie, cible_type, cible_id, cible_label,
 *            auteur_nom, date_publication, priorite, statut, created_at
 */

/* ─── Fetch robuste ─────────────────────────────────────────── */
async function _cqFetch(url) {
  const r = await fetch(url);
  const txt = await r.text().catch(() => '');
  if (!r.ok) throw new Error(`API ${r.status}${txt ? ' : ' + txt.slice(0, 100) : ''}`);
  if (!txt || !txt.trim()) return {};
  try { return JSON.parse(txt); } catch { throw new Error('Réponse invalide du serveur'); }
}
async function _cqPost(url, body) {
  const r = await fetch(url, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const txt = await r.text().catch(() => '');
  if (!r.ok) throw new Error(`API ${r.status}${txt ? ' : ' + txt.slice(0, 100) : ''}`);
  if (!txt || !txt.trim()) return {};
  try { return JSON.parse(txt); } catch { return {}; }
}
async function _cqPut(url, body) {
  const r = await fetch(url, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const txt = await r.text().catch(() => '');
  if (!r.ok) throw new Error(`API ${r.status}${txt ? ' : ' + txt.slice(0, 100) : ''}`);
  if (!txt || !txt.trim()) return {};
  try { return JSON.parse(txt); } catch { return {}; }
}
async function _cqDelReq(url) {
  const r = await fetch(url, { method: 'DELETE' });
  if (!r.ok && r.status !== 204) throw new Error(`Erreur suppression (${r.status})`);
  return true;
}

/* ─── Constantes ────────────────────────────────────────────── */
const CQ_CATEGORIES = [
  { value: 'reglementation', label: '📜 Réglementation & Statuts', icon: 'fa-gavel', color: '#6C3483' },
  { value: 'grades',         label: '🏅 Grades & Harmonisation',   icon: 'fa-medal', color: '#D4AC0D' },
  { value: 'ceremonies',     label: '⛪ Cérémonies & Rites',        icon: 'fa-church', color: '#0E6655' },
  { value: 'administrative', label: '📋 Administrative',            icon: 'fa-folder', color: '#1A5276' },
  { value: 'disciplinaire',  label: '⚠️ Disciplinaire',            icon: 'fa-exclamation-triangle', color: '#C0392B' },
  { value: 'pastorale',      label: '🙏 Pastorale',                 icon: 'fa-hands-praying', color: '#117A65' },
  { value: 'information',    label: 'ℹ️ Information Générale',       icon: 'fa-info-circle', color: '#2980B9' }
];

const CQ_PRIORITES = [
  { value: 'normale',  label: 'Normale',  color: '#3498DB' },
  { value: 'urgente',  label: 'Urgente',  color: '#E67E22' },
  { value: 'critique', label: 'Critique', color: '#C0392B' }
];

const CQ_CIBLES = [
  { value: 'tous',         label: '🌍 Toutes les Églises',           desc: 'Visible par toutes les paroisses' },
  { value: 'chorales',     label: '🎵 Toutes les Chorales',          desc: 'Visible par tous les choristes' },
  { value: 'region',       label: '📍 Une Région',                   desc: 'Sélectionner une région' },
  { value: 'sous_region',  label: '📌 Une Sous-région',              desc: 'Sélectionner une sous-région' },
  { value: 'eglise',       label: '⛪ Une Église spécifique',        desc: 'Sélectionner une paroisse' },
  { value: 'chorale_egl',  label: '🎶 Chorale d\'une Église',        desc: 'Choisir une paroisse' }
];

/* ─── État ──────────────────────────────────────────────────── */
let _cqAll      = [];
let _cqFiltered = [];
let _cqPage     = 1;
const CQ_PER    = 10;
let _cqFilter   = { categorie: '', priorite: '', cible: '', search: '' };

/* ════════════════════════════════════════════════════════════
   RENDER PRINCIPAL
════════════════════════════════════════════════════════════ */
async function renderCommuniques() {
  setBreadcrumb([{ label: 'Communiqués CSMO' }]);
  const content = document.getElementById('pageContent');
  const me = Auth.getCurrentUser();
  const isSA = me?.role === 'super_admin';

  content.innerHTML = `<div class="loading-spinner">
    <i class="fas fa-circle-notch fa-spin"></i><p>Chargement des communiqués…</p></div>`;

  try {
    const [cqRes] = await Promise.all([
      _cqFetch('tables/communiques?limit=500&sort=created_at')
    ]);
    _cqAll = (cqRes.data || []).sort((a, b) => (b.created_at || 0) - (a.created_at || 0));

    content.innerHTML = `
      <!-- ── En-tête ── -->
      <div class="page-header">
        <div class="page-header-left">
          <h2 style="display:flex;align-items:center;gap:10px">
            <span style="width:42px;height:42px;border-radius:12px;
              background:linear-gradient(135deg,#6C3483,#9B59B6);
              display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fas fa-bullhorn" style="color:#fff;font-size:18px"></i>
            </span>
            Communiqués Officiels
          </h2>
          <p style="color:var(--text-muted);font-size:13px;margin-top:4px">
            <i class="fas fa-landmark" style="margin-right:4px;color:#6C3483"></i>
            <strong>CSMO</strong> — Conseil Supérieur de Mise en Œuvre · Instauré le 04 juin 2026, Cotonou (Sofitel)
          </p>
        </div>
        <div class="page-header-actions">
          ${isSA ? `
          <button class="btn btn-primary" onclick="showCommuniqueForm()"
            style="background:linear-gradient(135deg,#6C3483,#1A5276)">
            <i class="fas fa-plus"></i> Nouveau Communiqué
          </button>` : ''}
        </div>
      </div>

      ${!isSA ? `
      <div style="background:linear-gradient(135deg,rgba(108,52,131,0.08),rgba(26,82,118,0.08));
        border:1px solid rgba(108,52,131,0.2);border-radius:12px;padding:14px 18px;
        margin-bottom:20px;display:flex;align-items:center;gap:12px;font-size:13px">
        <i class="fas fa-shield-alt" style="font-size:20px;color:#6C3483;flex-shrink:0"></i>
        <span>Seul le <strong>Saint Siège</strong> peut publier des communiqués officiels.
          Vous consultez ici les communiqués qui vous sont adressés.</span>
      </div>` : ''}

      <!-- ── Filtres ── -->
      <div style="background:var(--card-bg);border-radius:12px;padding:16px;
        margin-bottom:20px;display:flex;flex-wrap:wrap;gap:10px;align-items:center">
        <input type="text" id="cqSearch" placeholder="🔍 Rechercher un communiqué…"
          class="form-control" style="flex:1;min-width:200px"
          oninput="_cqApplyFilters()" />
        <select class="form-control" id="cqFiltCat" style="width:200px" onchange="_cqApplyFilters()">
          <option value="">Toutes catégories</option>
          ${CQ_CATEGORIES.map(c => `<option value="${c.value}">${c.label}</option>`).join('')}
        </select>
        <select class="form-control" id="cqFiltPrio" style="width:140px" onchange="_cqApplyFilters()">
          <option value="">Toute priorité</option>
          ${CQ_PRIORITES.map(p => `<option value="${p.value}">${p.label}</option>`).join('')}
        </select>
        <select class="form-control" id="cqFiltCible" style="width:160px" onchange="_cqApplyFilters()">
          <option value="">Toute cible</option>
          ${CQ_CIBLES.map(c => `<option value="${c.value}">${c.label}</option>`).join('')}
        </select>
        <button class="btn btn-outline" onclick="_cqResetFilters()" title="Réinitialiser">
          <i class="fas fa-times"></i>
        </button>
      </div>

      <!-- ── Compteur ── -->
      <div id="cqCount" style="font-size:13px;color:var(--text-muted);margin-bottom:16px"></div>

      <!-- ── Liste des communiqués ── -->
      <div id="cqList"></div>

      <!-- ── Pagination ── -->
      <div id="cqPagination" style="display:flex;justify-content:center;gap:8px;margin-top:20px"></div>
    `;

    _cqApplyFilters();
  } catch (e) {
    content.innerHTML = `<div class="empty-state">
      <i class="fas fa-exclamation-triangle"></i>
      <h3>Erreur de chargement</h3><p>${e.message}</p>
      <button class="btn btn-primary" onclick="renderCommuniques()">Réessayer</button>
    </div>`;
  }
}

/* ─── Filtres ────────────────────────────────────────────── */
function _cqApplyFilters() {
  const q  = (document.getElementById('cqSearch')?.value || '').toLowerCase();
  const cat = document.getElementById('cqFiltCat')?.value || '';
  const pr  = document.getElementById('cqFiltPrio')?.value || '';
  const ci  = document.getElementById('cqFiltCible')?.value || '';

  _cqFiltered = _cqAll.filter(c => {
    const matchQ  = !q  || (c.titre || '').toLowerCase().includes(q)
                        || (c.contenu || '').toLowerCase().includes(q)
                        || (c.cible_label || '').toLowerCase().includes(q);
    const matchCat  = !cat || c.categorie === cat;
    const matchPr   = !pr  || c.priorite === pr;
    const matchCi   = !ci  || c.cible_type === ci;
    return matchQ && matchCat && matchPr && matchCi;
  });

  _cqPage = 1;
  _cqRender();
}

function _cqResetFilters() {
  ['cqSearch','cqFiltCat','cqFiltPrio','cqFiltCible'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  _cqApplyFilters();
}

function _cqRender() {
  const total  = _cqFiltered.length;
  const pages  = Math.ceil(total / CQ_PER) || 1;
  _cqPage      = Math.max(1, Math.min(_cqPage, pages));
  const slice  = _cqFiltered.slice((_cqPage - 1) * CQ_PER, _cqPage * CQ_PER);
  const me     = Auth.getCurrentUser();
  const isSA   = me?.role === 'super_admin';

  document.getElementById('cqCount').textContent =
    `${total} communiqué${total !== 1 ? 's' : ''} trouvé${total !== 1 ? 's' : ''}`;

  if (total === 0) {
    document.getElementById('cqList').innerHTML = `
      <div class="empty-state">
        <i class="fas fa-bullhorn" style="color:var(--text-muted)"></i>
        <h3>Aucun communiqué</h3>
        <p>Aucun communiqué ne correspond à votre recherche.</p>
        ${isSA ? `<button class="btn btn-primary" onclick="showCommuniqueForm()">
          <i class="fas fa-plus"></i> Créer le premier communiqué</button>` : ''}
      </div>`;
    document.getElementById('cqPagination').innerHTML = '';
    return;
  }

  document.getElementById('cqList').innerHTML = slice.map(c => _cqCard(c, isSA)).join('');

  // Pagination
  let pag = '';
  if (pages > 1) {
    if (_cqPage > 1) pag += `<button class="btn btn-outline btn-sm" onclick="_cqPage--;_cqRender()">
      <i class="fas fa-chevron-left"></i></button>`;
    for (let i = 1; i <= pages; i++) {
      if (i === _cqPage) pag += `<button class="btn btn-primary btn-sm">${i}</button>`;
      else if (i === 1 || i === pages || Math.abs(i - _cqPage) <= 1)
        pag += `<button class="btn btn-outline btn-sm" onclick="_cqPage=${i};_cqRender()">${i}</button>`;
      else if (Math.abs(i - _cqPage) === 2) pag += `<span style="padding:0 4px">…</span>`;
    }
    if (_cqPage < pages) pag += `<button class="btn btn-outline btn-sm" onclick="_cqPage++;_cqRender()">
      <i class="fas fa-chevron-right"></i></button>`;
  }
  document.getElementById('cqPagination').innerHTML = pag;
}

function _cqCard(c, isSA) {
  const cat  = CQ_CATEGORIES.find(x => x.value === c.categorie) || CQ_CATEGORIES[6];
  const prio = CQ_PRIORITES.find(x => x.value === c.priorite)   || CQ_PRIORITES[0];
  const date = c.date_publication
    ? new Date(c.date_publication).toLocaleDateString('fr-FR', { day:'2-digit', month:'long', year:'numeric' })
    : (c.created_at ? new Date(c.created_at).toLocaleDateString('fr-FR', { day:'2-digit', month:'long', year:'numeric' }) : 'N/D');

  const cibleIcon = {
    tous: '🌍', chorales: '🎵', region: '📍', sous_region: '📌',
    eglise: '⛪', chorale_egl: '🎶'
  }[c.cible_type] || '📢';

  return `
  <article style="background:var(--card-bg);border-radius:16px;margin-bottom:16px;
    border:1px solid var(--border);overflow:hidden;
    border-left:5px solid ${cat.color};
    box-shadow:0 2px 8px rgba(0,0,0,0.06);transition:box-shadow 0.2s"
    onmouseover="this.style.boxShadow='0 4px 20px rgba(0,0,0,0.12)'"
    onmouseout="this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'">

    <!-- En-tête carte -->
    <div style="padding:18px 20px 14px;display:flex;align-items:flex-start;gap:14px">
      <div style="width:44px;height:44px;border-radius:12px;flex-shrink:0;
        background:${cat.color}22;display:flex;align-items:center;justify-content:center">
        <i class="fas ${cat.icon}" style="color:${cat.color};font-size:18px"></i>
      </div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-bottom:6px">
          <span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;
            color:${cat.color}">${cat.label}</span>
          <span style="font-size:11px;font-weight:700;padding:2px 9px;border-radius:20px;
            background:${prio.color}22;color:${prio.color};border:1px solid ${prio.color}44">
            ${prio.value === 'critique' ? '🔴' : prio.value === 'urgente' ? '🟠' : '🔵'} ${prio.label}
          </span>
          <span style="font-size:11px;background:var(--accent);padding:2px 9px;border-radius:20px;color:var(--text-muted)">
            ${cibleIcon} ${c.cible_label || 'Toutes les Églises'}
          </span>
        </div>
        <h3 style="font-size:17px;font-weight:700;margin:0 0 4px;color:var(--text-primary);
          white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${c.titre || 'Sans titre'}</h3>
        <div style="font-size:12px;color:var(--text-muted);display:flex;gap:14px;flex-wrap:wrap">
          <span><i class="fas fa-calendar" style="margin-right:4px"></i>${date}</span>
          <span><i class="fas fa-user-shield" style="margin-right:4px"></i>${c.auteur_nom || 'Saint Siège'}</span>
        </div>
      </div>
      ${isSA ? `
      <div style="display:flex;gap:6px;flex-shrink:0">
        <button class="btn btn-xs btn-outline" onclick="showCommuniqueForm('${c.id}')" title="Modifier">
          <i class="fas fa-edit"></i></button>
        <button class="btn btn-xs btn-danger" onclick="_cqDeleteUI('${c.id}','${(c.titre||'').replace(/'/g,"\\'")}')">
          <i class="fas fa-trash"></i></button>
      </div>` : ''}
    </div>

    <!-- Contenu (aperçu ou complet) -->
    <div id="cqBody_${c.id}" style="padding:0 20px 18px;padding-left:78px">
      <div id="cqPreview_${c.id}" style="font-size:14px;line-height:1.7;color:var(--text-secondary);
        display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;
        white-space:pre-wrap">${_escHtml(c.contenu || '')}</div>
      <div id="cqFull_${c.id}" style="display:none;font-size:14px;line-height:1.7;
        color:var(--text-secondary);white-space:pre-wrap">${_escHtml(c.contenu || '')}</div>
      ${(c.contenu || '').length > 200 ? `
      <button onclick="_cqToggle('${c.id}')" id="cqToggleBtn_${c.id}"
        style="background:none;border:none;cursor:pointer;font-size:12px;
          color:var(--primary);margin-top:6px;padding:0;font-weight:600">
        <i class="fas fa-chevron-down" style="margin-right:4px"></i>Lire la suite
      </button>` : ''}
    </div>
  </article>`;
}

function _cqToggle(id) {
  const prev = document.getElementById(`cqPreview_${id}`);
  const full = document.getElementById(`cqFull_${id}`);
  const btn  = document.getElementById(`cqToggleBtn_${id}`);
  if (!prev || !full || !btn) return;
  const isOpen = full.style.display !== 'none';
  prev.style.display = isOpen ? '' : 'none';
  full.style.display = isOpen ? 'none' : '';
  btn.innerHTML = isOpen
    ? '<i class="fas fa-chevron-down" style="margin-right:4px"></i>Lire la suite'
    : '<i class="fas fa-chevron-up" style="margin-right:4px"></i>Réduire';
}

function _escHtml(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

/* ════════════════════════════════════════════════════════════
   FORMULAIRE CRÉATION / ÉDITION
════════════════════════════════════════════════════════════ */
async function showCommuniqueForm(cqId = null) {
  const me = Auth.getCurrentUser();
  if (me?.role !== 'super_admin') {
    showToast('Seul le Saint Siège peut publier des communiqués.', 'warning');
    return;
  }

  let data = {};
  if (cqId) {
    const existing = _cqAll.find(x => x.id === cqId);
    if (existing) data = existing;
  }

  /* Charger régions, sous-régions, églises pour ciblage */
  let regs = [], srs = [], egls = [];
  try {
    const [rRes, srRes, eRes] = await Promise.all([
      _cqFetch('tables/regions?limit=100'),
      _cqFetch('tables/sous_regions?limit=200'),
      _cqFetch('tables/eglises?limit=500')
    ]);
    regs = rRes.data  || [];
    srs  = srRes.data || [];
    egls = eRes.data  || [];
  } catch (_) {}

  const today = new Date().toISOString().split('T')[0];

  openModal(
    cqId ? 'Modifier le Communiqué' : 'Nouveau Communiqué Officiel',
    `<div style="max-height:70vh;overflow-y:auto;padding-right:4px">

      <!-- Titre -->
      <div class="form-group">
        <label>Titre du communiqué <span style="color:var(--danger)">*</span></label>
        <input class="form-control" id="cqFTitre" value="${_escHtml(data.titre || '')}"
          placeholder="Ex: Harmonisation des grades — Corps des Leaders" />
      </div>

      <!-- Catégorie + Priorité -->
      <div class="form-row">
        <div class="form-group">
          <label>Catégorie <span style="color:var(--danger)">*</span></label>
          <select class="form-control" id="cqFCat">
            <option value="">— Choisir —</option>
            ${CQ_CATEGORIES.map(c =>
              `<option value="${c.value}" ${data.categorie===c.value?'selected':''}>${c.label}</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Priorité</label>
          <select class="form-control" id="cqFPrio">
            ${CQ_PRIORITES.map(p =>
              `<option value="${p.value}" ${(data.priorite||'normale')===p.value?'selected':''}>${p.label}</option>`
            ).join('')}
          </select>
        </div>
      </div>

      <!-- Date + Auteur -->
      <div class="form-row">
        <div class="form-group">
          <label>Date de publication</label>
          <input class="form-control" type="date" id="cqFDate"
            value="${data.date_publication ? data.date_publication.slice(0,10) : today}" />
        </div>
        <div class="form-group">
          <label>Signataire</label>
          <input class="form-control" id="cqFAuteur"
            value="${_escHtml(data.auteur_nom || 'CSMO — Conseil Supérieur de Mise en Œuvre')}"
            placeholder="Nom ou entité signataire" />
        </div>
      </div>

      <!-- Ciblage -->
      <div class="form-group">
        <label>Destinataires <span style="color:var(--danger)">*</span></label>
        <select class="form-control" id="cqFCible" onchange="_cqUpdateCibleDetail()">
          <option value="">— Choisir les destinataires —</option>
          ${CQ_CIBLES.map(c =>
            `<option value="${c.value}" ${data.cible_type===c.value?'selected':''}>${c.label} — ${c.desc}</option>`
          ).join('')}
        </select>
      </div>

      <!-- Détail cible (régions, sous-régions, églises) -->
      <div id="cqFCibleDetail" style="display:none" class="form-group">
        <label id="cqFCibleDetailLabel">Sélectionner</label>
        <select class="form-control" id="cqFCibleSel">
          <option value="">— Choisir —</option>
        </select>
      </div>

      <!-- Contenu -->
      <div class="form-group">
        <label>Contenu du communiqué <span style="color:var(--danger)">*</span>
          <span style="font-size:11px;color:var(--text-muted);font-weight:400">
            (texte intégral, règles, informations officielles…)</span>
        </label>
        <textarea class="form-control" id="cqFContenu" rows="10"
          style="resize:vertical;font-family:inherit;line-height:1.7"
          placeholder="Rédiger le communiqué officiel ici…">${_escHtml(data.contenu || '')}</textarea>
      </div>

      <p style="font-size:11px;color:var(--text-muted);margin-top:4px">
        <i class="fas fa-info-circle"></i> 
        Ce communiqué sera visible par toutes les paroisses ciblées dès sa publication.
      </p>
    </div>`,
    cqId ? 'Enregistrer' : 'Publier le Communiqué',
    async () => {
      const titre   = document.getElementById('cqFTitre')?.value.trim();
      const cat     = document.getElementById('cqFCat')?.value;
      const prio    = document.getElementById('cqFPrio')?.value || 'normale';
      const dateP   = document.getElementById('cqFDate')?.value || today;
      const auteur  = document.getElementById('cqFAuteur')?.value.trim() || 'CSMO';
      const cible   = document.getElementById('cqFCible')?.value;
      const cibleSel = document.getElementById('cqFCibleSel');
      const cibleId  = cibleSel ? (cibleSel.value || '') : '';
      const cibleLabel = cibleId
        ? (cibleSel.options[cibleSel.selectedIndex]?.text || cible)
        : (CQ_CIBLES.find(x => x.value === cible)?.label || cible);
      const contenu = document.getElementById('cqFContenu')?.value.trim();

      if (!titre)   { showToast('Le titre est requis', 'warning'); return; }
      if (!cat)     { showToast('Choisissez une catégorie', 'warning'); return; }
      if (!cible)   { showToast('Choisissez les destinataires', 'warning'); return; }
      if (!contenu) { showToast('Le contenu est requis', 'warning'); return; }

      const body = {
        id: cqId || ('cq_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6)),
        titre, categorie: cat, priorite: prio, date_publication: dateP,
        auteur_nom: auteur, cible_type: cible, cible_id: cibleId,
        cible_label: cibleId ? cibleLabel : CQ_CIBLES.find(x=>x.value===cible)?.label || cible,
        contenu, statut: 'publie'
      };

      try {
        if (cqId) {
          await _cqPut(`tables/communiques/${cqId}`, { ...data, ...body });
          showToast('Communiqué mis à jour', 'success');
        } else {
          await _cqPost('tables/communiques', body);
          showToast('Communiqué publié avec succès', 'success');
        }
        closeModal();
        renderCommuniques();
      } catch (e) {
        showToast('Erreur : ' + e.message, 'error');
      }
    }
  );

  /* Pré-remplir le sélecteur de détail cible si édition */
  if (data.cible_type) {
    _cqUpdateCibleDetail(data.cible_type, regs, srs, egls, data.cible_id);
  }

  /* Stocker pour _cqUpdateCibleDetail */
  window._cqFormData = { regs, srs, egls };
}

function _cqUpdateCibleDetail(forcedType = null, regs, srs, egls, selectedId = '') {
  const fd = window._cqFormData || {};
  const r  = regs  || fd.regs  || [];
  const s  = srs   || fd.srs   || [];
  const e  = egls  || fd.egls  || [];

  const cibleEl = document.getElementById('cqFCible');
  const detEl   = document.getElementById('cqFCibleDetail');
  const labEl   = document.getElementById('cqFCibleDetailLabel');
  const selEl   = document.getElementById('cqFCibleSel');
  if (!cibleEl || !detEl) return;

  const type = forcedType || cibleEl.value;
  if (!type || type === 'tous' || type === 'chorales') {
    detEl.style.display = 'none';
    return;
  }

  let label = '', options = [];
  if (type === 'region') {
    label = 'Région';
    options = r.map(x => ({ id: x.id, label: x.nom || x.id }));
  } else if (type === 'sous_region') {
    label = 'Sous-région';
    options = s.map(x => ({ id: x.id, label: x.nom || x.id }));
  } else if (type === 'eglise' || type === 'chorale_egl') {
    label = type === 'chorale_egl' ? 'Église (pour sa chorale)' : 'Église';
    options = e.map(x => ({ id: x.id, label: x.nom || x.id }));
  }

  detEl.style.display = '';
  labEl.textContent = label;
  selEl.innerHTML = `<option value="">— Choisir —</option>` +
    options.map(o =>
      `<option value="${o.id}" ${o.id === selectedId ? 'selected' : ''}>${o.label}</option>`
    ).join('');
}

/* ─── Supprimer ─────────────────────────────────────────── */
function _cqDeleteUI(id, titre) {
  confirmDelete(titre, async () => {
    try {
      await _cqDelReq(`tables/communiques/${id}`);
      showToast('Communiqué supprimé', 'success');
      closeModal();
      renderCommuniques();
    } catch (e) { showToast('Erreur : ' + e.message, 'error'); }
  });
}
