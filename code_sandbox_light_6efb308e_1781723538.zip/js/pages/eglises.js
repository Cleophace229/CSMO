/**
 * Églises Page — Recensement Paroissial
 * Direction paroissiale :
 *   - 1er/2ème Chargé Paroissial, Secrétaire, Secrétaire Adjoint → HOMMES uniquement
 *   - Maître de Chœurs, Adjoint de Chœurs → MIXTE (homme ou femme)
 * Comité paroissial : postes libres (saisis ou suggérés), hommes ET femmes
 * Format contact : +229 01 XX XX XX XX
 */
App.registerAddHandler('eglises', () => showEgliseForm());

/* ─── Postes fixes de la direction paroissiale ──────────────── */
const DIRECTION_POSTES = [
  { key: 'cp1',     label: '1er Chargé Paroissial',  icon: 'fa-crown',    sexe: 'homme' },
  { key: 'cp2',     label: '2ème Chargé Paroissial', icon: 'fa-user-tie', sexe: 'homme' },
  { key: 'sec',     label: 'Secrétaire',              icon: 'fa-pen',      sexe: 'homme' },
  { key: 'sec_adj', label: 'Secrétaire Adjoint',      icon: 'fa-pen-alt',  sexe: 'homme' },
  { key: 'mc',      label: 'Maître de Chœurs',        icon: 'fa-music',    sexe: 'mixte' },
  { key: 'mc_adj',  label: 'Adjoint de Chœurs',       icon: 'fa-music',    sexe: 'mixte' },
  { key: 'leader',  label: 'Leader en Charge',         icon: 'fa-star',     sexe: 'homme' }
];

/* Suggestions de postes pour le comité paroissial (liste non exhaustive) */
const POSTES_COMITE_SUGGESTIONS = [
  'Trésorier', 'Trésorière', 'Trésorier Adjoint',
  'Responsable Jeunesse', 'Responsable Femmes', 'Responsable Hommes',
  'Responsable Louange', 'Responsable Évangélisation',
  'Maître de Chœurs Adjoint', 'Caissier', 'Caissière',
  'Coordinateur', 'Coordinatrice', 'Responsable Communication',
  'Responsable Formation', 'Aumônier', 'Diacre',
  'Responsable Protocole', 'Responsable Accueil'
];

/* Mapping clé → colonne réelle dans la table eglises
   IMPORTANT : les colonnes charge_paroissial_1 etc. N'EXISTENT PAS.
   Seules les colonnes dir_*_nom et dir_*_grade existent. */
const DIR_KEY_MAP = {
  cp1:     'dir_cp1_nom',     cp2:     'dir_cp2_nom',
  sec:     'dir_sec_nom',     sec_adj: 'dir_sec_adj_nom',
  mc:      'dir_mc_nom',      mc_adj:  'dir_mc_adj_nom',
  leader:  'dir_leader_nom'
};

/* ─── Génère les champs direction (nom + grade selon sexe du poste) ─ */
function _directionFields(data) {
  const ghomme = typeof GRADES_HOMME !== 'undefined' ? GRADES_HOMME : [];
  const gfemme = typeof GRADES_FEMME !== 'undefined' ? GRADES_FEMME : [];

  return DIRECTION_POSTES.map(p => {
    const nomVal   = data[`dir_${p.key}_nom`]   || '';
    const gradeVal = data[`dir_${p.key}_grade`] || '';
    const sexeVal  = data[`dir_${p.key}_sexe`]  || (p.sexe === 'mixte' ? 'homme' : 'homme');

    const isMixte  = p.sexe === 'mixte';
    const badgeLabel = isMixte ? '♂♀ Mixte' : '♂ Homme';
    const badgeBg    = isMixte ? '#e6f4ff' : '#f0e6ff';
    const badgeColor = isMixte ? 'var(--info)' : 'var(--primary)';

    /* Grades à afficher : si mixte on pré-sélectionne selon sexe stocké */
    const grades = (isMixte && sexeVal === 'femme') ? gfemme : ghomme;
    const isLeader = p.key === 'leader';
    const telVal   = isLeader ? (data[`dir_leader_tel`] || '') : '';

    return `
    <div style="background:linear-gradient(135deg,#fafbff,#f3e9ff);
      border:1px solid rgba(108,52,131,0.15);border-radius:10px;padding:14px;margin-bottom:10px">
      <div style="font-size:12px;font-weight:700;color:var(--primary-dark);
                  text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px;
                  display:flex;align-items:center;gap:6px">
        <i class="fas ${p.icon}" style="color:var(--gold)"></i>${p.label}
        <span style="font-size:10px;font-weight:400;color:${badgeColor};
          background:${badgeBg};padding:1px 6px;border-radius:10px;margin-left:auto">${badgeLabel}</span>
      </div>
      <div class="form-row" style="margin:0;gap:12px">
        <div class="form-group" style="margin-bottom:0;flex:2">
          <label style="font-size:11px">Nom complet</label>
          <input class="form-control" id="fDir_${p.key}_nom"
            value="${nomVal.replace(/"/g,'&quot;')}"
            placeholder="Prénom Nom" />
        </div>
        ${isMixte ? `
        <div class="form-group" style="margin-bottom:0;flex:1">
          <label style="font-size:11px">Sexe</label>
          <select class="form-control" id="fDir_${p.key}_sexe"
            onchange="_updateDirGrades('${p.key}')">
            <option value="homme" ${sexeVal==='homme'?'selected':''}>♂ Homme</option>
            <option value="femme" ${sexeVal==='femme'?'selected':''}>♀ Femme</option>
          </select>
        </div>` : ''}
        <div class="form-group" style="margin-bottom:0;flex:2">
          <label style="font-size:11px">Grade</label>
          <select class="form-control" id="fDir_${p.key}_grade">
            <option value="">— Grade —</option>
            ${grades.map(g =>
              `<option value="${g}" ${gradeVal === g ? 'selected' : ''}>${g}</option>`
            ).join('')}
          </select>
        </div>
        ${isLeader ? `
        <div class="form-group" style="margin-bottom:0;flex:2">
          <label style="font-size:11px">Téléphone <small style="color:var(--text-muted)">(+229 01…)</small></label>
          <input class="form-control" id="fDir_leader_tel"
            value="${telVal.replace(/"/g,'&quot;')}"
            placeholder="+229 01 XX XX XX XX" />
        </div>` : ''}
      </div>
    </div>`;
  }).join('');
}

/* Met à jour les grades quand on change le sexe d'un poste mixte */
function _updateDirGrades(key) {
  const sexeSel  = document.getElementById(`fDir_${key}_sexe`);
  const gradeSel = document.getElementById(`fDir_${key}_grade`);
  if (!sexeSel || !gradeSel) return;
  const grades = sexeSel.value === 'femme'
    ? (typeof GRADES_FEMME !== 'undefined' ? GRADES_FEMME : [])
    : (typeof GRADES_HOMME !== 'undefined' ? GRADES_HOMME : []);
  gradeSel.innerHTML = `<option value="">— Grade —</option>
    ${grades.map(g => `<option value="${g}">${g}</option>`).join('')}`;
}

/* ─── Collecte les valeurs de direction ──────────────────────── */
function _getDirectionPayload() {
  const out = {};
  DIRECTION_POSTES.forEach(p => {
    // Seuls les champs existants dans la table eglises :
    // dir_cp1_nom, dir_cp1_grade, dir_cp2_nom, dir_cp2_grade,
    // dir_sec_nom, dir_sec_grade, dir_sec_adj_nom, dir_sec_adj_grade,
    // dir_mc_nom, dir_mc_grade, dir_mc_adj_nom, dir_mc_adj_grade
    out[`dir_${p.key}_nom`]   = (document.getElementById(`fDir_${p.key}_nom`)?.value || '').trim();
    out[`dir_${p.key}_grade`] = document.getElementById(`fDir_${p.key}_grade`)?.value || '';
    if (p.key === 'leader') {
      out['dir_leader_tel'] = (document.getElementById('fDir_leader_tel')?.value || '').trim();
    }
    // Ne PAS envoyer dir_*_sexe : colonnes inexistantes en base → HTTP 500
  });
  return out;
}

/* ─── Génère le formulaire comité paroissial ─────────────────── */
function _comiteFields(comiteMembers) {
  /* comiteMembers : tableau de { nom, sexe, poste, grade } */
  const rows = (comiteMembers && comiteMembers.length > 0)
    ? comiteMembers
    : [{ nom: '', sexe: 'homme', poste: '', grade: '' }];

  return `
    <div id="comiteRows">
      ${rows.map((m, i) => _comiteRow(i, m)).join('')}
    </div>
    <button type="button" class="btn btn-sm btn-outline"
      style="margin-top:8px" onclick="_addComiteRow()">
      <i class="fas fa-plus"></i> Ajouter un membre du comité
    </button>`;
}

function _comiteRow(i, m = {}) {
  const ghomme = typeof GRADES_HOMME !== 'undefined' ? GRADES_HOMME : [];
  const gfemme = typeof GRADES_FEMME !== 'undefined' ? GRADES_FEMME : [];
  const grades = (m.sexe === 'femme') ? gfemme : ghomme;

  const suggestions = POSTES_COMITE_SUGGESTIONS.map(s =>
    `<option value="${s}">${s}</option>`).join('');

  return `
    <div class="comite-row" id="comiteRow_${i}"
      style="display:grid;grid-template-columns:2fr 1fr 2fr 2fr 1.5fr auto;gap:8px;
             margin-bottom:8px;align-items:end">
      <div>
        ${i === 0 ? '<label style="font-size:11px">Nom complet</label>' : ''}
        <input class="form-control" id="cNom_${i}"
          value="${(m.nom || '').replace(/"/g,'&quot;')}"
          placeholder="Prénom Nom" />
      </div>
      <div>
        ${i === 0 ? '<label style="font-size:11px">Sexe</label>' : ''}
        <select class="form-control" id="cSexe_${i}"
          onchange="_updateComiteGrades(${i})">
          <option value="homme" ${(m.sexe||'homme')==='homme'?'selected':''}>♂</option>
          <option value="femme" ${m.sexe==='femme'?'selected':''}>♀</option>
        </select>
      </div>
      <div>
        ${i === 0 ? '<label style="font-size:11px">Poste <small style="color:var(--text-muted)">(libre ou suggéré)</small></label>' : ''}
        <input class="form-control" id="cPoste_${i}"
          list="posteSuggestions_${i}"
          value="${(m.poste || '').replace(/"/g,'&quot;')}"
          placeholder="Trésorier, Coordinateur..." />
        <datalist id="posteSuggestions_${i}">${suggestions}</datalist>
      </div>
      <div>
        ${i === 0 ? '<label style="font-size:11px">Grade</label>' : ''}
        <select class="form-control" id="cGrade_${i}">
          <option value="">— Grade —</option>
          ${grades.map(g => `<option value="${g}" ${m.grade===g?'selected':''}>${g}</option>`).join('')}
        </select>
      </div>
      <div>
        ${i === 0 ? '<label style="font-size:11px">Téléphone</label>' : ''}
        <input class="form-control" id="cTel_${i}"
          value="${(m.telephone || '').replace(/"/g,'&quot;')}"
          placeholder="+229 01..." style="font-size:12px" />
      </div>
      <div style="padding-bottom:0">
        ${i === 0 ? '<label style="font-size:11px;visibility:hidden">X</label>' : ''}
        <button type="button" class="btn btn-sm btn-danger"
          onclick="_removeComiteRow(${i})" title="Supprimer">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>`;
}

let _comiteRowCount = 0;

function _addComiteRow() {
  const container = document.getElementById('comiteRows');
  if (!container) return;
  _comiteRowCount++;
  const div = document.createElement('div');
  div.innerHTML = _comiteRow(_comiteRowCount + 100);
  container.appendChild(div.firstElementChild);
}

function _removeComiteRow(i) {
  const row = document.getElementById(`comiteRow_${i}`);
  if (row) row.remove();
}

function _updateComiteGrades(i) {
  const sexe  = document.getElementById(`cSexe_${i}`)?.value || 'homme';
  const sel   = document.getElementById(`cGrade_${i}`);
  if (!sel) return;
  const grades = sexe === 'femme'
    ? (typeof GRADES_FEMME !== 'undefined' ? GRADES_FEMME : [])
    : (typeof GRADES_HOMME !== 'undefined' ? GRADES_HOMME : []);
  sel.innerHTML = `<option value="">— Grade —</option>
    ${grades.map(g => `<option value="${g}">${g}</option>`).join('')}`;
}

function _getComitePayload() {
  const rows = document.querySelectorAll('#comiteRows .comite-row');
  const members = [];
  rows.forEach(row => {
    const id = row.id.replace('comiteRow_', '');
    const nom       = document.getElementById(`cNom_${id}`)?.value.trim()   || '';
    const sexe      = document.getElementById(`cSexe_${id}`)?.value         || 'homme';
    const poste     = document.getElementById(`cPoste_${id}`)?.value.trim() || '';
    const grade     = document.getElementById(`cGrade_${id}`)?.value        || '';
    const telephone = document.getElementById(`cTel_${id}`)?.value.trim()   || '';
    if (nom || poste) members.push({ nom, sexe, poste, grade, telephone });
  });
  return members;
}

/* ═══════════════════════════════════════════════════════════════
   RENDER PRINCIPAL
   ═══════════════════════════════════════════════════════════════ */
async function renderEglises(params = {}) {
  setBreadcrumb([
    { label: I18n.t('regions.title'),    onclick: "App.navigate('regions')" },
    { label: I18n.t('srs.title'),        onclick: "App.navigate('sous_regions')" },
    { label: I18n.t('nav.eglises') }
  ]);
  const content = document.getElementById('pageContent');

  try {
    const [regs, srs, egls, mems] = await Promise.all([
      API.getAll('regions'),
      API.getAll('sous_regions'),
      API.getAll('eglises'),
      API.getAll('membres')
    ]);

    let filtered = egls.data;
    if (params.sous_region_id) filtered = egls.data.filter(e => e.sous_region_id === params.sous_region_id);
    else if (params.region_id) filtered = egls.data.filter(e => e.region_id === params.region_id);

    const chips = `
      <div class="filter-chips" style="flex-wrap:wrap;margin-bottom:12px">
        <span class="chip ${!params.sous_region_id && !params.region_id ? 'active' : ''}"
          onclick="App.navigate('eglises')">Toutes</span>
        ${regs.data.map(r =>
          `<span class="chip ${params.region_id === r.id ? 'active' : ''}"
            onclick="App.navigate('eglises',{region_id:'${r.id}'})">${r.nom}</span>`
        ).join('')}
      </div>`;

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="rainbow-title">
            <i class="fas fa-church" style="margin-right:10px"></i>${I18n.t('eglises.title')}
          </h2>
          <p>${filtered.length} ${I18n.lang==='en'?'parish(es)':'paroisse(s)'}</p>
        </div>
        <div class="page-header-actions">
          ${Auth.canWrite()
            ? `<button class="btn btn-primary" onclick="showEgliseForm()">
                 <i class="fas fa-plus"></i> ${I18n.t('eglises.new')}
               </button>`
            : ''}
          <button class="btn btn-outline" onclick="App.navigate('export')">
            <i class="fas fa-print"></i> ${I18n.t('btn.print')}
          </button>
        </div>
      </div>

      ${chips}

      <div class="page-search">
        <div class="search-input-wrapper" style="flex:1">
          <i class="fas fa-search"></i>
          <input type="text" id="eglSearch" placeholder="${I18n.t('eglises.search')}"
            oninput="filterEglises()" />
        </div>
        <select class="form-control" id="eglStatutFilter" style="width:160px" onchange="filterEglises()">
          <option value="">${I18n.t('eglises.all_statuts')}</option>
          <option value="actif">${I18n.t('eglises.active')}</option>
          <option value="inactif">${I18n.t('eglises.inactive')}</option>
        </select>
      </div>

      <div class="grid-auto" id="eglGrid">
        ${filtered.length === 0
          ? emptyState('fa-church', I18n.t('eglises.none'), I18n.lang==='en'?'Register your first parish.':'Enregistrez votre première paroisse.',
              Auth.canWrite() ? I18n.t('eglises.new') : null, 'showEgliseForm()')
          : filtered.map(egl => {
              const sr      = srs.data.find(s => s.id === egl.sous_region_id);
              const reg     = regs.data.find(r => r.id === egl.region_id);
              const eglMems = mems.data.filter(m => m.eglise_id === egl.id);
              const cp1Nom  = egl.dir_cp1_nom  || '';
              const cp1Grade = egl.dir_cp1_grade || '';
              return `
              <div class="entity-card"
                data-name="${(egl.nom || '').toLowerCase()}"
                data-statut="${egl.statut || 'actif'}">
                <div class="entity-card-header eglise">
                  <div class="entity-card-icon"><i class="fas fa-church"></i></div>
                  <h4>${egl.nom}</h4>
                  <p>${egl.ville || ''} ${sr ? '· ' + sr.nom : ''}</p>
                </div>
                <div class="entity-card-body">
                  <div class="meta">
                    <i class="fas fa-user-tie"></i>
                    ${cp1Nom || '<em style="opacity:.6">Non défini</em>'}
                    ${cp1Grade
                      ? `<span class="badge badge-gold" style="margin-left:4px;font-size:10px">${cp1Grade}</span>`
                      : ''}
                  </div>
                  <div class="meta"><i class="fas fa-phone"></i>${egl.telephone || '—'}</div>
                  <div class="meta"><i class="fas fa-globe-africa"></i>${reg ? reg.nom : '—'}</div>
                  <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">
                    <span class="badge badge-primary"><i class="fas fa-users"></i> ${eglMems.length}</span>
                    ${statutBadge(egl.statut || 'actif')}
                  </div>
                </div>
                <div class="entity-card-footer">
                  <button class="btn btn-sm btn-primary" onclick="viewEglise('${egl.id}')">
                    <i class="fas fa-eye"></i> Détails
                  </button>
                  ${Auth.canWrite()
                    ? `<button class="btn btn-sm btn-outline" onclick="showEgliseForm('${egl.id}')">
                         <i class="fas fa-edit"></i>
                       </button>`
                    : ''}
                  ${Auth.canDelete()
                    ? `<button class="btn btn-sm btn-danger"
                         onclick="deleteEglise('${egl.id}','${(egl.nom || '').replace(/'/g,"\\'")}')">
                         <i class="fas fa-trash"></i>
                       </button>`
                    : ''}
                </div>
              </div>`;
            }).join('')}
      </div>`;

  } catch (err) {
    document.getElementById('pageContent').innerHTML =
      `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i>
       <h3>Erreur de chargement</h3><p>${err.message}</p>
       <button class="btn btn-primary" onclick="renderEglises()">
         <i class="fas fa-redo"></i> Réessayer
       </button></div>`;
  }
}

function filterEglises() {
  const q      = (document.getElementById('eglSearch')?.value || '').toLowerCase();
  const statut = document.getElementById('eglStatutFilter')?.value || '';
  document.querySelectorAll('#eglGrid .entity-card').forEach(card => {
    const matchQ = card.dataset.name.includes(q);
    const matchS = !statut || card.dataset.statut === statut;
    card.style.display = (matchQ && matchS) ? '' : 'none';
  });
}

/* ═══════════════════════════════════════════════════════════════
   DÉTAIL ÉGLISE
   ═══════════════════════════════════════════════════════════════ */
async function viewEglise(id) {
  try {
    const [egl, mems, evs, srs, regs, comite] = await Promise.all([
      API.getById('eglises', id),
      API.getAll('membres'),
      API.getAll('evenements'),
      API.getAll('sous_regions'),
      API.getAll('regions'),
      API.getAll('comite_paroissial').catch(() => ({ data: [] }))
    ]);

    const eglMems  = mems.data.filter(m => m.eglise_id === id);
    const eglEvs   = evs.data.filter(e => e.eglise_id === id);
    const eglComite= comite.data.filter(c => c.eglise_id === id);
    const sr       = srs.data.find(s => s.id === egl.sous_region_id);
    const reg      = regs.data.find(r => r.id === egl.region_id);

    // HTML direction paroissiale
    const dirHTML = DIRECTION_POSTES.map(p => {
      const nom      = egl[`dir_${p.key}_nom`]   || '—';
      const grade    = egl[`dir_${p.key}_grade`] || '';
      const isMixte  = p.sexe === 'mixte';
      const isLeader = p.key === 'leader';
      const tel      = isLeader ? (egl['dir_leader_tel'] || '') : '';
      return `
        <div class="detail-item">
          <label>
            <i class="fas ${p.icon}" style="color:var(--gold);margin-right:4px"></i>
            ${p.label}
            <span style="font-size:10px;color:var(--text-muted);font-weight:400">
              ${isMixte ? ' (♂♀ Mixte)' : ' (♂ Homme)'}
            </span>
          </label>
          <p style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
            ${nom}
            ${grade ? `<span class="badge badge-gold" style="font-size:10px">${grade}</span>` : ''}
            ${isLeader && tel ? `<span style="font-size:11px;color:var(--primary)"><i class="fas fa-phone" style="margin-right:3px"></i>${tel}</span>` : ''}
          </p>
        </div>`;
    }).join('');

    // HTML comité paroissial
    const comiteHTML = eglComite.length === 0
      ? '<p style="color:var(--text-muted);font-size:13px;padding:10px 0">Aucun membre du comité enregistré.</p>'
      : `<div class="table-wrapper"><table>
          <thead><tr><th>Nom</th><th>Sexe</th><th>Poste</th><th>Grade</th></tr></thead>
          <tbody>
            ${eglComite.map(c => `
              <tr>
                <td style="font-weight:600">${c.nom || '—'}</td>
                <td>${c.sexe === 'femme' ? '♀ Femme' : '♂ Homme'}</td>
                <td>${c.poste || '—'}</td>
                <td>${c.grade ? `<span class="badge ${typeof _GRADE_COLORS !== 'undefined' ? (_GRADE_COLORS[c.grade] || 'badge-secondary') : 'badge-secondary'}">${c.grade}</span>` : '—'}</td>
              </tr>`).join('')}
          </tbody>
        </table></div>`;

    const html = `
      <div class="profile-banner" style="text-align:left;padding:24px">
        <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
          <div style="width:60px;height:60px;border-radius:14px;
            background:rgba(255,255,255,0.2);display:flex;align-items:center;
            justify-content:center;font-size:28px">
            <i class="fas fa-church"></i>
          </div>
          <div style="flex:1">
            <h2 style="font-size:22px;margin:0">${egl.nom}</h2>
            <p style="margin:4px 0 0;opacity:.8">
              ${egl.ville || ''} · ${sr ? sr.nom : ''} · ${reg ? reg.nom : ''}
            </p>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            ${statutBadge(egl.statut || 'actif')}
            ${Auth.canWrite()
              ? `<button class="btn btn-sm btn-outline" onclick="closeModal();showEgliseForm('${id}')">
                   <i class="fas fa-edit"></i> Modifier
                 </button>`
              : ''}
          </div>
        </div>
      </div>

      <div class="profile-tabs">
        <div class="profile-tab active" onclick="switchEgliseTab(this,'egl-tab-info')">
          <i class="fas fa-info-circle"></i> Infos
        </div>
        <div class="profile-tab" onclick="switchEgliseTab(this,'egl-tab-direction')">
          <i class="fas fa-users-cog"></i> Direction (${DIRECTION_POSTES.length})
        </div>
        <div class="profile-tab" onclick="switchEgliseTab(this,'egl-tab-comite')">
          <i class="fas fa-people-group"></i> Comité (${eglComite.length})
        </div>
        <div class="profile-tab" onclick="switchEgliseTab(this,'egl-tab-membres')">
          <i class="fas fa-users"></i> Membres (${eglMems.length})
        </div>
        <div class="profile-tab" onclick="switchEgliseTab(this,'egl-tab-evs')">
          <i class="fas fa-calendar-alt"></i> Événements (${eglEvs.length})
        </div>
      </div>

      <!-- Tab Infos -->
      <div id="egl-tab-info" class="tab-content active" style="display:block">
        <div class="detail-grid" style="margin-bottom:16px">
          <div class="detail-item"><label>Adresse</label><p>${egl.adresse || '—'}</p></div>
          <div class="detail-item"><label>Ville</label><p>${egl.ville || '—'}</p></div>
          <div class="detail-item"><label>Téléphone</label><p>${egl.telephone || '—'}</p></div>
          <div class="detail-item"><label>Email</label><p>${egl.email || '—'}</p></div>
          <div class="detail-item"><label>Date de fondation</label><p>${formatDate(egl.date_fondation)}</p></div>
          <div class="detail-item"><label>Région</label><p>${reg ? reg.nom : '—'}</p></div>
          <div class="detail-item"><label>Sous-région</label><p>${sr ? sr.nom : '—'}</p></div>
          <div class="detail-item"><label>Statut</label><p>${statutBadge(egl.statut || 'actif')}</p></div>
          ${egl.continent ? `<div class="detail-item"><label><i class="fas fa-globe-africa" style="color:var(--success);margin-right:4px"></i>Continent</label><p>${egl.continent}</p></div>` : ''}
          ${egl.pays ? `<div class="detail-item"><label><i class="fas fa-flag" style="color:var(--info);margin-right:4px"></i>Pays</label><p>${egl.pays}</p></div>` : ''}
        </div>
        ${egl.description
          ? `<div style="font-size:13px;color:var(--text);padding:12px;
              background:var(--accent);border-radius:8px">${egl.description}</div>`
          : ''}
        ${Auth.isSuperAdmin() && egl.identifiant ? `
          <div style="margin-top:12px;padding:14px 16px;
            background:linear-gradient(135deg,#fef9e7,#fffbf0);
            border:1px solid #f39c12;border-radius:10px">
            <p style="font-size:11px;font-weight:700;text-transform:uppercase;color:#856404;margin-bottom:10px">
              <i class="fas fa-key"></i> Identifiants d'accès de la paroisse
            </p>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
              <div>
                <label style="font-size:11px;color:#856404">Identifiant</label>
                <code style="display:block;background:#fff;padding:6px 10px;border-radius:6px;
                  font-size:14px;font-weight:700;color:var(--primary);margin-top:2px">
                  ${egl.identifiant}
                </code>
              </div>
              <div>
                <label style="font-size:11px;color:#856404">Mot de passe</label>
                <code style="display:block;background:#fff;padding:6px 10px;border-radius:6px;
                  font-size:14px;font-weight:700;color:var(--danger);margin-top:2px">
                  ${egl.mot_de_passe || '(caché)'}
                </code>
              </div>
            </div>
          </div>` : ''}
      </div>

      <!-- Tab Direction Paroissiale -->
      <div id="egl-tab-direction" class="tab-content" style="display:none">
        <div style="margin-bottom:12px;padding:10px 14px;
          background:linear-gradient(135deg,#f3e9ff,#faf5ff);
          border-left:3px solid var(--gold);border-radius:6px">
          <p style="font-size:12px;color:var(--text-muted);margin:0">
            <i class="fas fa-info-circle" style="color:var(--gold);margin-right:4px"></i>
            Chargés, Secrétaires, Trésorier : <strong>hommes</strong>.
            Trésorière : <strong>femme</strong>.
            Maître et Adjoint de Chœurs : <strong>homme ou femme</strong>.
          </p>
        </div>
        <div class="detail-grid">${dirHTML}</div>
      </div>

      <!-- Tab Comité Paroissial -->
      <div id="egl-tab-comite" class="tab-content" style="display:none">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
          <p style="font-size:13px;color:var(--text-muted);margin:0">
            <i class="fas fa-info-circle" style="color:var(--info);margin-right:4px"></i>
            Membres du comité (hommes et femmes, postes libres)
          </p>
          ${Auth.canWrite()
            ? `<button class="btn btn-sm btn-primary"
                 onclick="closeModal();showComiteManager('${id}')">
                 <i class="fas fa-edit"></i> Gérer le comité
               </button>`
            : ''}
        </div>
        ${comiteHTML}
      </div>

      <!-- Tab Membres -->
      <div id="egl-tab-membres" class="tab-content" style="display:none">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
          <span style="font-size:13px;color:var(--text-muted)">
            ${eglMems.length} membre(s) ·
            ${eglMems.filter(m => m.sexe === 'homme').length} ♂
            / ${eglMems.filter(m => m.sexe === 'femme').length} ♀
          </span>
          <button class="btn btn-sm btn-primary"
            onclick="closeModal();App.navigate('membres',{eglise_id:'${id}'})">
            <i class="fas fa-external-link-alt"></i> Gérer
          </button>
        </div>
        ${eglMems.length === 0
          ? '<p class="text-center text-muted">Aucun membre enregistré</p>'
          : eglMems.slice(0, 10).map(m => `
            <div style="display:flex;align-items:center;gap:10px;
              padding:8px 0;border-bottom:1px solid var(--border)">
              ${memberAvatar(m, 32)}
              <div style="flex:1">
                <span style="font-weight:600;font-size:13px">${m.prenom} ${m.nom}</span>
                <span style="font-size:11px;color:var(--text-muted);margin-left:6px">
                  ${m.sexe === 'femme' ? '♀' : '♂'} · ${m.role || ''}
                </span>
              </div>
              ${gradeBadge(m.grade)}${statutBadge(m.statut)}
            </div>`).join('')}
        ${eglMems.length > 10
          ? `<p style="text-align:center;font-size:12px;color:var(--text-muted);margin-top:8px">
               + ${eglMems.length - 10} autres membres
             </p>` : ''}
      </div>

      <!-- Tab Événements -->
      <div id="egl-tab-evs" class="tab-content" style="display:none">
        <div style="margin-bottom:12px">
          <button class="btn btn-sm btn-primary"
            onclick="closeModal();App.navigate('evenements',{eglise_id:'${id}'})">
            <i class="fas fa-external-link-alt"></i> Gérer les événements
          </button>
        </div>
        ${eglEvs.length === 0
          ? '<p class="text-center text-muted">Aucun événement</p>'
          : eglEvs.slice(0, 8).map(ev => {
              const cfg = (typeof TYPES_EV_CONFIG !== 'undefined' && TYPES_EV_CONFIG[ev.type_evenement])
                ? TYPES_EV_CONFIG[ev.type_evenement]
                : { color: 'badge-secondary' };
              return `
              <div style="padding:10px 0;border-bottom:1px solid var(--border)">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
                  <strong style="font-size:13px">${ev.titre}</strong>
                  <span class="badge ${cfg.color}">${ev.type_evenement || '—'}</span>
                </div>
                <div style="font-size:11px;color:var(--text-muted);margin-top:4px">
                  ${formatDateShort(ev.date_debut)} · ${ev.lieu || ''}
                </div>
              </div>`;
            }).join('')}
      </div>
    `;

    openModal(`Détails : ${egl.nom}`, html, '', null, 'large');

  } catch (err) {
    showToast('Erreur de chargement : ' + err.message, 'error');
  }
}

function switchEgliseTab(el, tabId) {
  const container = el.closest('.modal-body') || document;
  container.querySelectorAll('.profile-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  container.querySelectorAll('.tab-content').forEach(t => {
    t.style.display = 'none';
    t.classList.remove('active');
  });
  const tc = document.getElementById(tabId);
  if (tc) { tc.style.display = 'block'; tc.classList.add('active'); }
}

/* ═══════════════════════════════════════════════════════════════
   GESTIONNAIRE DU COMITÉ PAROISSIAL (modal séparé)
   ═══════════════════════════════════════════════════════════════ */
async function showComiteManager(egliseId) {
  try {
    const [egl, comite] = await Promise.all([
      API.getById('eglises', egliseId),
      API.getAll('comite_paroissial').catch(() => ({ data: [] }))
    ]);
    const members = comite.data.filter(c => c.eglise_id === egliseId);

    _comiteRowCount = members.length;

    const html = `
      <p style="font-size:13px;color:var(--text-muted);margin-bottom:14px">
        <i class="fas fa-info-circle" style="color:var(--info);margin-right:4px"></i>
        Enregistrez ici les membres du comité paroissial de <strong>${egl.nom}</strong>.
        Les postes sont libres : vous pouvez les saisir ou choisir parmi les suggestions.
      </p>
      ${_comiteFields(members)}
    `;

    openModal(`Comité Paroissial — ${egl.nom}`, html, 'Enregistrer', async () => {
      const newMembers = _getComitePayload();

      try {
        // Supprimer les anciens membres du comité de cette église
        for (const m of members) {
          await API.remove('comite_paroissial', m.id).catch(() => {});
        }
        // Recréer
        for (const m of newMembers) {
          await API.create('comite_paroissial', {
            id:               generateId('cmt'),
            eglise_id:        egliseId,
            nom:              m.nom,
            sexe:             m.sexe,
            poste:            m.poste,
            grade:            m.grade,
            telephone:        m.telephone || '',
            statut:           'actif',
            date_nomination:  new Date().toISOString().slice(0, 10),
            notes:            ''
          });
        }
        showToast(`Comité enregistré (${newMembers.length} membre(s))`, 'success');
        closeModal();
      } catch (err) {
        showToast('Erreur : ' + err.message, 'error');
      }
    }, 'large');

  } catch (err) {
    showToast('Erreur de chargement : ' + err.message, 'error');
  }
}

/* ═══════════════════════════════════════════════════════════════
   FORMULAIRE ÉGLISE (création / édition)
   ═══════════════════════════════════════════════════════════════ */
async function showEgliseForm(id = null) {
  let regs, srs, data = {};
  try {
    [regs, srs] = await Promise.all([API.getAll('regions'), API.getAll('sous_regions')]);
  } catch (err) {
    showToast('Impossible de charger les données : ' + err.message, 'error');
    return;
  }
  if (id) { try { data = await API.getById('eglises', id); } catch {} }

  const html = `
    <div class="form-row">
      <div class="form-group">
        <label>Nom de la paroisse <span style="color:var(--danger)">*</span></label>
        <input class="form-control" id="fEglNom" value="${(data.nom || '').replace(/"/g,'&quot;')}"
          placeholder="Paroisse Saint-..." />
      </div>
      <div class="form-group">
        <label>Ville</label>
        <input class="form-control" id="fEglVille" value="${(data.ville || '').replace(/"/g,'&quot;')}"
          placeholder="Cotonou" />
      </div>
    </div>

    <!-- Continent & Pays -->
    <div style="background:linear-gradient(135deg,#f0fdf4,#dcfce7);border:1px solid #86efac;border-radius:10px;padding:14px 16px;margin-bottom:16px">
      <div class="form-row" style="margin-bottom:0">
        <div class="form-group" style="margin-bottom:0">
          <label>Continent</label>
          ${GEO.continentSelect('fEglContinent', data.continent||'Afrique', "GEO.bindContinentToPays('fEglContinent','fEglPays')")}
        </div>
        <div class="form-group" style="margin-bottom:0">
          <label>Pays</label>
          ${GEO.paysSelect('fEglPays', data.continent||'Afrique', data.pays||'')}
        </div>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Région <span style="color:var(--danger)">*</span></label>
        <select class="form-control" id="fEglRegion"
          onchange="updateSrOptions(this.value,'${data.sous_region_id || ''}')">
          <option value="">— Choisir une région —</option>
          ${regs.data.map(r =>
            `<option value="${r.id}" ${data.region_id === r.id ? 'selected' : ''}>${r.nom}</option>`
          ).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Sous-région</label>
        <select class="form-control" id="fEglSr">
          <option value="">— Choisir d'abord une région —</option>
          ${data.region_id
            ? srs.data.filter(s => s.region_id === data.region_id).map(s =>
                `<option value="${s.id}" ${data.sous_region_id === s.id ? 'selected' : ''}>${s.nom}</option>`
              ).join('')
            : ''}
        </select>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Adresse</label>
        <input class="form-control" id="fEglAddr" value="${(data.adresse || '').replace(/"/g,'&quot;')}" />
      </div>
      <div class="form-group">
        <label>Téléphone <small style="color:var(--text-muted)">(+229 01 XX XX XX XX)</small></label>
        <input class="form-control" id="fEglTel"
          value="${(data.telephone || '').replace(/"/g,'&quot;')}"
          placeholder="+229 01 XX XX XX XX" />
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Email</label>
        <input class="form-control" id="fEglEmail"
          value="${(data.email || '').replace(/"/g,'&quot;')}" placeholder="email@paroisse.bj" />
      </div>
      <div class="form-group">
        <label>Date de fondation</label>
        <input class="form-control" type="date" id="fEglDate"
          value="${data.date_fondation || ''}" />
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Statut</label>
        <select class="form-control" id="fEglStatut">
          <option value="actif"   ${(data.statut || 'actif') === 'actif'   ? 'selected' : ''}>Actif</option>
          <option value="inactif" ${data.statut === 'inactif' ? 'selected' : ''}>Inactif</option>
        </select>
      </div>
    </div>

    <div class="form-group">
      <label>Description</label>
      <textarea class="form-control" id="fEglDesc">${data.description || ''}</textarea>
    </div>

    <hr style="border:none;border-top:2px dashed var(--border);margin:18px 0">

    <!-- Direction Paroissiale -->
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
      <h4 style="font-weight:700;margin:0;color:var(--primary-dark)">
        <i class="fas fa-users-cog" style="margin-right:6px;color:var(--gold)"></i>
        Direction Paroissiale
      </h4>
    </div>
    <p style="font-size:12px;color:var(--text-muted);margin-bottom:14px">
      <i class="fas fa-info-circle"></i>
      Chargés/Secrétaires : hommes uniquement. Maître/Adjoint de Chœurs : homme ou femme.
    </p>
    ${_directionFields(data)}
  `;

  window._srData = srs.data;

  /* Initialiser dynamiquement le lien continent → pays après injection HTML */
  setTimeout(() => {
    if (typeof GEO !== 'undefined') {
      GEO.bindContinentToPays('fEglContinent', 'fEglPays', data.pays || '');
    }
  }, 80);

  openModal(
    id ? 'Modifier l\'église' : 'Nouvelle église',
    html,
    id ? 'Enregistrer' : 'Créer',
    async () => {
      const nom       = document.getElementById('fEglNom')?.value.trim();
      const region_id = document.getElementById('fEglRegion')?.value;
      if (!nom)       { showToast('Le nom de l\'église est requis', 'warning'); return; }
      if (!region_id) { showToast('La région est requise', 'warning'); return; }

      const dirPayload = _getDirectionPayload();
      const payload = {
        nom, region_id,
        continent: document.getElementById('fEglContinent')?.value || '',
        pays:      document.getElementById('fEglPays')?.value || '',
        sous_region_id:  document.getElementById('fEglSr')?.value || '',
        ville:           document.getElementById('fEglVille')?.value.trim() || '',
        adresse:         document.getElementById('fEglAddr')?.value.trim() || '',
        telephone:       document.getElementById('fEglTel')?.value.trim() || '',
        email:           document.getElementById('fEglEmail')?.value.trim() || '',
        date_fondation:  document.getElementById('fEglDate')?.value || '',
        statut:          document.getElementById('fEglStatut')?.value || 'actif',
        description:     document.getElementById('fEglDesc')?.value.trim() || '',
        ...dirPayload
      };

      try {
        if (id) {
          await API.update('eglises', id, payload);
          showToast('Église mise à jour avec succès', 'success');
          closeModal();
          renderEglises();
        } else {
          const creds = generateEgliseCredentials(nom);
          const newId = generateId('egl');
          await API.create('eglises', {
            id: newId, ...payload,
            identifiant:   creds.identifiant,
            mot_de_passe:  creds.mot_de_passe
          });
          // Créer le compte utilisateur de la paroisse
          try {
            await Auth.createUser({
              username:  creds.identifiant,
              password:  creds.mot_de_passe,
              nom,
              role:      'secretaire',
              eglise_id: newId,
              actif:     true
            });
          } catch (_) { /* non bloquant */ }

          closeModal();
          // Afficher les identifiants générés
          openModal(
            '✅ Paroisse créée avec succès',
            `<div style="text-align:center;padding:16px 0">
              <i class="fas fa-check-circle" style="font-size:52px;color:var(--success);margin-bottom:16px"></i>
              <h3 style="color:var(--primary);margin-bottom:20px">${nom}</h3>
              <div style="background:linear-gradient(135deg,#f9f0ff,#fff8e7);
                border:2px solid var(--gold);border-radius:14px;
                padding:20px;text-align:left;max-width:340px;margin:0 auto">
                <p style="font-size:12px;font-weight:700;color:#856404;
                  text-transform:uppercase;letter-spacing:0.5px;margin-bottom:14px">
                  <i class="fas fa-key"></i> Identifiants de connexion de la paroisse
                </p>
                <div style="margin-bottom:12px">
                  <label style="font-size:11px;color:var(--text-muted);display:block">Identifiant</label>
                  <code style="font-size:18px;font-weight:700;color:var(--primary);
                    background:#fff;padding:6px 14px;border-radius:8px;
                    display:block;margin-top:4px;letter-spacing:2px">
                    ${creds.identifiant}
                  </code>
                </div>
                <div>
                  <label style="font-size:11px;color:var(--text-muted);display:block">Mot de passe</label>
                  <code style="font-size:18px;font-weight:700;color:var(--danger);
                    background:#fff;padding:6px 14px;border-radius:8px;
                    display:block;margin-top:4px;letter-spacing:2px">
                    ${creds.mot_de_passe}
                  </code>
                </div>
              </div>
              <p style="font-size:12px;color:var(--text-muted);margin-top:16px;max-width:300px;
                margin-left:auto;margin-right:auto">
                <i class="fas fa-exclamation-triangle" style="color:var(--warning)"></i>
                <strong>Notez ces identifiants maintenant.</strong> Ils ne seront plus affichés.
              </p>
            </div>`,
            'Fermer',
            () => { closeModal(); renderEglises(); },
            'small'
          );
        }
      } catch (err) {
        showToast('Erreur : ' + err.message, 'error');
      }
    },
    'large'
  );
}

function updateSrOptions(regionId, selectedId = '') {
  const srSel = document.getElementById('fEglSr');
  if (!srSel) return;
  const srs = (window._srData || []).filter(s => s.region_id === regionId);
  srSel.innerHTML = `<option value="">— Choisir une sous-région —</option>
    ${srs.map(s =>
      `<option value="${s.id}" ${selectedId === s.id ? 'selected' : ''}>${s.nom}</option>`
    ).join('')}`;
}

async function deleteEglise(id, nom) {
  confirmDelete(nom, async () => {
    try {
      await API.remove('eglises', id);
      showToast('Église supprimée', 'success');
      closeModal();
      renderEglises();
    } catch (err) {
      showToast('Erreur : ' + err.message, 'error');
    }
  });
}
