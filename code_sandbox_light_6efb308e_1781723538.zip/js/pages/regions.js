/**
 * Régions Page
 */
App.registerAddHandler('regions', () => showRegionForm());

async function renderRegions() {
  setBreadcrumb([{ label: I18n.t('regions.title') }]);
  const content = document.getElementById('pageContent');
  try {
    const [regs, srs, egls, mems] = await Promise.all([
      API.getAll('regions'),
      API.getAll('sous_regions'),
      API.getAll('eglises'),
      API.getAll('membres')
    ]);

    content.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2><i class="fas fa-globe-africa" style="color:var(--info);margin-right:10px"></i>${I18n.t('regions.title')}</h2>
          <p>${regs.total} ${I18n.lang==='en'?'region(s) registered':'région(s) enregistrée(s)'}</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-primary" onclick="showRegionForm()">
            <i class="fas fa-plus"></i> ${I18n.t('regions.new')}
          </button>
        </div>
      </div>

      <div class="page-search">
        <div class="search-input-wrapper">
          <i class="fas fa-search"></i>
          <input type="text" id="regionSearch" placeholder="${I18n.t('regions.search')}"
            oninput="filterRegions()" />
        </div>
      </div>

      <div class="grid-auto" id="regionsGrid">
        ${regs.data.length === 0
          ? emptyState('fa-globe-africa',I18n.t('regions.none'),I18n.t('regions.none_sub'),
              I18n.t('regions.create'),'showRegionForm()')
          : ''}
        ${regs.data.map(reg => {
          const regSrs  = srs.data.filter(s => s.region_id === reg.id);
          const regEgls = egls.data.filter(e => e.region_id === reg.id);
          const regMems = mems.data.filter(m => regEgls.some(e => e.id === m.eglise_id));
          const grade   = reg.responsable_grade || '';
          return `
          <div class="entity-card" data-name="${reg.nom.toLowerCase()}" data-id="${reg.id}">
            <div class="entity-card-header region">
              <div class="entity-card-icon"><i class="fas fa-globe-africa"></i></div>
              <h4>${reg.nom}</h4>
              <p>
                <i class="fas fa-user-tie" style="margin-right:4px"></i>
                ${reg.responsable || 'Non défini'}
                ${grade ? `<span class="badge badge-gold" style="margin-left:6px;font-size:10px">${grade}</span>` : ''}
              </p>
            </div>
            <div class="entity-card-body">
              <div class="meta">
                <i class="fas fa-phone"></i>${reg.contact || 'Non défini'}
              </div>
              <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
                <span class="badge badge-info"><i class="fas fa-map-marked-alt"></i> ${regSrs.length} sous-région(s)</span>
                <span class="badge badge-success"><i class="fas fa-church"></i> ${regEgls.length} église(s)</span>
                <span class="badge badge-primary"><i class="fas fa-users"></i> ${regMems.length} membre(s)</span>
              </div>
            </div>
            <div class="entity-card-footer">
              <button class="btn btn-sm btn-primary"
                onclick="App.navigate('sous_regions',{region_id:'${reg.id}'})">
                <i class="fas fa-eye"></i> Voir
              </button>
              <button class="btn btn-sm btn-outline" onclick="showRegionForm('${reg.id}')">
                <i class="fas fa-edit"></i> Modifier
              </button>
              <button class="btn btn-sm btn-danger"
                onclick="deleteRegion('${reg.id}','${reg.nom}')">
                <i class="fas fa-trash"></i>
              </button>
            </div>
          </div>`;
        }).join('')}
      </div>`;
  } catch (err) {
    document.getElementById('pageContent').innerHTML =
      `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i>
       <h3>Erreur</h3><p>${err.message}</p></div>`;
  }
}

function filterRegions() {
  const q = document.getElementById('regionSearch').value.toLowerCase();
  document.querySelectorAll('#regionsGrid .entity-card').forEach(card => {
    card.style.display = card.dataset.name.includes(q) ? '' : 'none';
  });
}

async function showRegionForm(id = null) {
  let data = {};
  if (id) { try { data = await API.getById('regions', id); } catch {} }

  const grades = typeof GRADES_HOMME !== 'undefined' ? GRADES_HOMME : [];

  const html = `
    <div class="form-group">
      <label>Nom de la région <span style="color:var(--danger)">*</span></label>
      <input class="form-control" id="fRegNom" value="${data.nom || ''}"
        placeholder="Ex: Région Nord" />
    </div>

    <div style="background:#f8f9fa;border:1px solid #e9ecef;border-radius:10px;
                padding:14px;margin-bottom:12px">
      <div style="font-size:12px;font-weight:700;color:var(--primary-dark);
                  text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">
        <i class="fas fa-user-tie" style="margin-right:6px;color:var(--gold)"></i>
        Responsable Régional
      </div>
      <div class="form-row" style="margin:0">
        <div class="form-group" style="margin-bottom:0">
          <label style="font-size:11px">Nom complet</label>
          <input class="form-control" id="fRegResp" value="${data.responsable || ''}"
            placeholder="Prénom Nom du responsable" />
        </div>
        <div class="form-group" style="margin-bottom:0">
          <label style="font-size:11px">Grade <small style="color:var(--text-muted)">(masculin)</small></label>
          <select class="form-control" id="fRegGrade">
            <option value="">— Choisir le grade —</option>
            ${grades.map(g =>
              `<option value="${g}" ${(data.responsable_grade||'')===g?'selected':''}>${g}</option>`
            ).join('')}
          </select>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label>Contact <small style="color:var(--text-muted)">(+229 01 XX XX XX XX)</small></label>
      <input class="form-control" id="fRegContact" value="${data.contact || ''}"
        placeholder="+229 01 XX XX XX XX" />
    </div>
    <div class="form-group">
      <label>Description</label>
      <textarea class="form-control" id="fRegDesc"
        placeholder="Description de la région">${data.description || ''}</textarea>
    </div>`;

  openModal(id ? 'Modifier la région' : 'Nouvelle région', html,
    id ? 'Enregistrer' : 'Créer',
    async () => {
      const nom = document.getElementById('fRegNom').value.trim();
      if (!nom) { showToast('Le nom est requis', 'warning'); return; }
      const payload = {
        nom,
        responsable:       document.getElementById('fRegResp').value.trim(),
        responsable_grade: document.getElementById('fRegGrade').value,
        contact:           document.getElementById('fRegContact').value.trim(),
        description:       document.getElementById('fRegDesc').value.trim()
      };
      try {
        if (id) {
          await API.update('regions', id, payload);
          showToast('Région mise à jour', 'success');
        } else {
          await API.create('regions', { id: generateId('reg'), ...payload });
          showToast('Région créée', 'success');
        }
        closeModal();
        renderRegions();
      } catch (err) { showToast('Erreur: ' + err.message, 'error'); }
    }
  );
}

async function deleteRegion(id, nom) {
  confirmDelete(nom, async () => {
    try {
      await API.remove('regions', id);
      showToast('Région supprimée', 'success');
      closeModal();
      renderRegions();
    } catch (err) { showToast('Erreur: ' + err.message, 'error'); }
  });
}
