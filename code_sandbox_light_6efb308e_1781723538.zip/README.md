# Registre Mondial des Paroisses — Église du Christianisme Céleste (ECC)

Plateforme de recensement, géolocalisation et évaluation de la viabilité des paroisses de l'Église du Christianisme Céleste (ECC) à travers le monde.

---

## 🎯 Objectifs

- Identifier, géolocaliser et recenser toutes les paroisses ECC mondiales
- Recenser les responsables de chaque paroisse
- Évaluer la conformité aux normes de l'ECC
- Centraliser les données dans une base mondiale

---

## 🚀 Fonctionnalités implémentées

### 🔐 Authentification & Portails
- **2 portails de connexion** (Woli supprimé) :
  - Saint-Siège & Admins (violet `#6C3483`)
  - Compte Paroisse (vert `#0E6655`)
- **Super admin secours** : `admin` / `admin777@` (atob encodé)
- **Auto-inscription paroisse** (libre) : téléphone + mot de passe + 2+ photos + GPS → statut `en_attente` → notification admin

### 🏛️ Hiérarchie
- Régions → Sous-régions → Paroisses (4 niveaux)
- Carte des paroisses (GPS)

### ⛪ Gestion des Paroisses
- Formulaire complet (nom, ville, continent, pays, GPS, région, sous-région)
- **Direction paroissiale** (9 postes) :
  - 1er/2ème Chargé Paroissial, Secrétaire, Secrétaire Adjoint (hommes)
  - Maître de Chœurs, Adjoint de Chœurs (mixte)
  - Leader en Charge (homme)
  - **Trésorier** (homme) ← *nouveau*
  - **Trésorière** (femme) ← *nouveau*
- Comité paroissial (membres libres, postes suggérés)
- Génération automatique d'identifiants de connexion
- Statut actif/inactif, description

### 👥 Membres & Fidèles
- Recensement des fidèles (prenom, nom, sexe, grade CSMO, statut)
- Grades CSMO harmonisés : `GRADES_LEADER` (18), `GRADES_WOLI_HOMME` (5), `GRADES_WOLI_FEMME` (6), `GRADES_ALLAGBA` (5), `GRADES_MAMAN` (9)
- Choristes, Enfants AJ, Historique

### 📅 Calendrier Liturgique ECC
- **Fêtes ECC propres** (catholiques supprimées) :
  - 29 septembre : Naissance de l'ECC (1947)
  - 10 septembre : Décès du Fondateur Rév. Proph. S.B.J. Oschoffa (1985)
  - 19 octobre : Enterrement du Fondateur (1985)
  - 1er vendredi de juillet : Jour de la Vierge Marie (apparition 1977)
  - 1er dimanche de juin : Fête des Moissons des Enfants ECC
- Pâques, Ascension, Pentecôte, Semaine Sainte (chrétien universel)
- Fêtes civiles Bénin, France

### 📢 Communiqués CSMO
- Création réservée au super_admin
- Lecture pour tous les rôles
- 9 communiqués initiaux (Acte Inaugural + Décisions + Règlement)
- Filtres par catégorie, priorité, cible, recherche

### 🔔 Notifications
- Notifications admin pour les nouvelles inscriptions paroisses
- Badge en temps réel dans la sidebar

### 🌍 Identité Visuelle ECC
- Logo étoile à 12 branches (SVG) dans la sidebar et l'écran de connexion
- Titre : "Registre des Paroisses ECC"
- Couleur primaire : `#7C3AED` (violet ECC)
- Couleur or : `#D4AC0D`

---

## 🔑 Accès

| Rôle | Identifiant | Mot de passe |
|------|-------------|--------------|
| super_admin | `admin` | `admin777@` |
| Paroisse | (téléphone) | (choisi lors inscription) |

---

## 📁 Structure des fichiers clés

```
index.html                      ← Application principale (PWA)
css/style.css                   ← Styles globaux
js/
  auth.js                       ← Authentification (2 portails + auto-inscription)
  app.js                        ← Contrôleur principal, routing, sidebar
  api.js                        ← Fetch helper (text→JSON.parse, no content-type check)
  utils.js                      ← Grades CSMO, helpers
  pages/
    eglises.js                  ← Gestion paroisses (+ trésorier/trésorière)
    fideles.js                  ← Fidèles / Woli
    woli_accounts.js            ← Hiérarchie Woli
    communiques.js              ← Communiqués CSMO
    calendrier.js               ← Calendrier liturgique ECC
    comites_nationaux.js        ← Comités CSMO
    contributeurs.js            ← À propos
manifest.json                   ← PWA manifest
sw.js                           ← Service Worker (cache offline)
```

---

## 🗄️ Tables de données (RESTful API)

| Table | Champs clés | Usage |
|-------|-------------|-------|
| `utilisateurs` | username, password_hash, role, actif, statut, telephone, gps_latitude, gps_longitude, photos | Comptes + auto-inscription |
| `eglises` | nom, continent, pays, région, GPS, dir_*_nom/grade, dir_tresorier_nom/grade, dir_tresoriere_nom/grade | Paroisses |
| `membres` | prenom, nom, sexe, grade, statut, eglise_id | Fidèles |
| `communiques` | titre, contenu, categorie, priorite, cible, auteur | Communiqués CSMO |
| `notifications` | titre, message, type, lue, destinataire | Notifications admin |
| `comite_paroissial` | nom, sexe, poste, grade, telephone, eglise_id | Comités |
| `fideles` | prenom, nom, sexe, grade, role_woli | Fidèles Woli |

---

## 🔄 Pattern API robuste

```javascript
// Tous les helpers fetch utilisent ce pattern (pas de vérif Content-Type) :
const r   = await fetch(url);
const txt = await r.text().catch(() => '');
if (!r.ok) throw new Error(`Erreur ${r.status}`);
if (!txt || !txt.trim()) return {};
try { return JSON.parse(txt); } catch { throw new Error('Réponse invalide'); }
```

---

## ✅ Dernière vérification Playwright

- **Erreurs JS : 0**
- **Logs : 1** (`[PWA] SW enregistré`)
- Temps de chargement : ~10s

---

## 🚀 Déploiement

Aller dans l'onglet **Publish** pour publier le projet en ligne.

---

## ❓ Fonctionnalités en attente / futures

- [ ] Logo ECC officiel (photo à envoyer par l'utilisateur)
- [ ] Système de notation des paroisses (0-100 points)
- [ ] Certificat de conformité PDF (valable 3 ans)
- [ ] Intégration Mobile Money (MTN MoMo, Moov Africa, Celtiis Cash)
- [ ] Algorithme du tiers pastoral (reversement hebdomadaire au Saint-Siège)
- [ ] Row Level Security (chaque paroisse ne voit que ses données)
- [ ] Carte mondiale interactive avec clusters GPS
- [ ] Validation des inscriptions en attente (admin approuve/rejette)
- [ ] Recalibrage du barème Organisation & Gouvernance (10+5+5+15 ≠ 20 pts)
