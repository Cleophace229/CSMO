/**
 * i18n.js — Système de traduction léger FR / EN
 * Usage : I18n.t('key')  ou  data-i18n="key" sur les éléments HTML
 * Toggle : I18n.toggle() — bascule FR ↔ EN et rafraîchit le DOM
 */
const I18n = (() => {

  /* ── Dictionnaire ────────────────────────────────────────────── */
  const DICT = {
    fr: {
      /* Navigation / titres */
      'nav.dashboard':        'Tableau de bord',
      'nav.stats':            'Statistiques',
      'nav.map':              'Carte des Paroisses',
      'nav.regions':          'Régions',
      'nav.sous_regions':     'Sous-régions',
      'nav.eglises':          'Églises',
      'nav.my_church':        'Mon Église',
      'nav.members':          'Fidèles & Membres',
      'nav.history':          'Historique',
      'nav.committees':       'Comités Supérieurs',
      'nav.children_aj':      'Enfants AJ',
      'nav.choristes':        'Choristes',
      'nav.messages':         'Messages',
      'nav.events':           'Événements',
      'nav.calendar':         'Calendrier Liturgique',
      'nav.contributions':    'Cotisations',
      'nav.tools':            'Outils',
      'nav.import':           'Import CSV',
      'nav.export':           'Export & Impression',
      'nav.notifications':    'Notifications',
      'nav.about':            'À propos',
      'nav.admin':            'Administration',
      'nav.users':            'Utilisateurs',
      'nav.promotions':       'Promotions',
      'role.saint_siege':     'Saint Siège',
      'role.admin':           'Administrateur',
      'role.secretaire':      'Secrétaire',
      'role.lecteur':         'Lecteur',
      /* Sections sidebar */
      'section.principal':    'Principal',
      'section.hierarchy':    'Hiérarchie',
      'section.members':      'Membres',
      'section.messaging':    'Messagerie',
      'section.activities':   'Activités',
      'section.info':         'Informations',
      /* Topbar */
      'topbar.search':        'Recherche globale...',
      'topbar.darkmode':      'Mode sombre / clair',
      'topbar.language':      'Switch to English',
      'topbar.add':           'Ajouter',
      /* Login */
      'login.title':          'Connexion',
      'login.subtitle':       'Communauté Céleste — Système Paroissial',
      'login.username':       'Nom d\'utilisateur',
      'login.password':       'Mot de passe',
      'login.btn':            'Se connecter',
      'login.forgot':         'Mot de passe oublié ?',
      'login.remember':       'Rester connecté',
      /* Boutons communs */
      'btn.save':             'Enregistrer',
      'btn.cancel':           'Annuler',
      'btn.edit':             'Modifier',
      'btn.delete':           'Supprimer',
      'btn.add':              'Ajouter',
      'btn.close':            'Fermer',
      'btn.export_pdf':       'Exporter PDF',
      'btn.print':            'Imprimer',
      'btn.filter':           'Filtrer',
      'btn.search':           'Rechercher',
      'btn.confirm':          'Confirmer',
      'btn.retry':            'Réessayer',
      /* Statuts */
      'status.active':        'Actif',
      'status.inactive':      'Inactif',
      'status.pending':       'En attente',
      /* Carte */
      'map.title':            'Carte des Paroisses',
      'map.all_regions':      'Toutes les régions',
      'map.all_statuts':      'Tous statuts',
      'map.active':           'Actives',
      'map.inactive':         'Inactives',
      'map.positioned':       'église(s) positionnée(s)',
      'map.center':           'Centrer',
      'map.locate':           'Localiser',
      'map.position':         'Positionner',
      'map.no_coords':        'Aucune coordonnée GPS — cliquez "Positionner"',
      'map.add_coords':       'Ajouter des coordonnées',
      'map.click_info':       'Cliquer sur un marqueur pour détails',
      /* Onboarding */
      'onboard.title':        'Bienvenue ! 👋',
      'onboard.subtitle':     'Configurons votre système en 4 étapes',
      'onboard.step1':        'Créer une Région',
      'onboard.step2':        'Créer une Sous-région',
      'onboard.step3':        'Enregistrer une Église',
      'onboard.step4':        'Ajouter un Membre',
      'onboard.skip':         'Passer pour l\'instant',
      'onboard.next':         'Suivant →',
      'onboard.finish':       'Terminer',
      /* Messages génériques */
      'msg.loading':          'Chargement...',
      'msg.no_result':        'Aucun résultat',
      'msg.error':            'Une erreur est survenue',
      'msg.saved':            'Enregistré avec succès',
      'msg.deleted':          'Supprimé avec succès',
      'msg.confirm_delete':   'Êtes-vous sûr de vouloir supprimer cet élément ?',
      'msg.offline':          'Mode hors ligne — Les modifications seront synchronisées à la reconnexion.',
      /* Dashboard */
      'dash.total_members':   'Total membres',
      'dash.active_members':  'Membres actifs',
      'dash.men':             'Hommes',
      'dash.women':           'Femmes',
      'dash.events':          'Événements',
      'dash.messages':        'Messages',
      'dash.title':           'Tableau de Bord',
      'dash.subtitle':        'Vue d\'ensemble du recensement paroissial',
      'dash.send_msg':        'Envoyer un message',
      'dash.regions':         'Régions',
      'dash.sous_regions':    'Sous-régions',
      'dash.active_churches': 'Églises actives',
      'dash.upcoming_events': 'Événements à venir',
      'dash.contributions':   'Cotisations perçues',
      'dash.unread_replies':  'Réponses non lues',
      'dash.sent_messages':   'Messages envoyés',
      'dash.hierarchy':       'Structure Hiérarchique',
      'dash.see_all':         'Voir tout',
      'dash.recent_members':  'Membres récents',
      'dash.see_all_members': 'Voir tous',
      'dash.no_members':      'Aucun membre enregistré',
      'dash.upcoming_events_title': 'Événements à venir',
      'dash.no_events':       'Aucun événement à venir',
      'dash.religious_feasts':'Fêtes religieuses à venir',
      'dash.today':           'Aujourd\'hui !',
      'dash.in_days':         'Dans {{n}} jour(s)',
      /* Régions */
      'regions.title':        'Régions',
      'regions.new':          'Nouvelle région',
      'regions.search':       'Rechercher une région...',
      'regions.none':         'Aucune région',
      'regions.none_sub':     'Commencez par créer votre première région.',
      'regions.create':       'Créer une région',
      'regions.sub_count':    'sous-région(s)',
      'regions.church_count': 'église(s)',
      'regions.member_count': 'membre(s)',
      'regions.form_name':    'Nom de la région',
      'regions.form_resp':    'Responsable',
      'regions.form_grade':   'Grade du responsable',
      'regions.form_desc':    'Description',
      /* Sous-régions */
      'srs.title':            'Sous-régions',
      'srs.new':              'Nouvelle sous-région',
      'srs.search':           'Rechercher une sous-région...',
      'srs.none':             'Aucune sous-région',
      /* Églises */
      'eglises.title':        'Paroisses & Églises',
      'eglises.new':          'Nouvelle église',
      'eglises.search':       'Rechercher une église...',
      'eglises.none':         'Aucune église enregistrée',
      'eglises.all_regions':  'Toutes les régions',
      'eglises.all_statuts':  'Tous les statuts',
      'eglises.active':       'Actives',
      'eglises.inactive':     'Inactives',
      'eglises.export':       'Exporter',
      /* Membres */
      'membres.title':        'Membres & Fidèles',
      'membres.new':          'Nouveau membre',
      'membres.search':       'Rechercher un membre...',
      'membres.all_churches': 'Toutes les églises',
      'membres.all_grades':   'Tous les grades',
      'membres.all_roles':    'Tous les rôles',
      'membres.all':          'Tous',
      'membres.men':          '♂ Hommes',
      'membres.women':        '♀ Femmes',
      'membres.all_statuts':  'Tous statuts',
      'membres.active':       'Actifs',
      'membres.inactive':     'Inactifs',
      'membres.suspended':    'Suspendus',
      'membres.view_table':   'Tableau',
      'membres.view_cards':   'Cartes',
      'membres.export':       'Exporter',
      'membres.nom':          'Nom',
      'membres.prenom':       'Prénom',
      'membres.role':         'Rôle',
      'membres.grade':        'Grade',
      'membres.church':       'Église',
      'membres.phone':        'Téléphone',
      'membres.statut':       'Statut',
      'membres.actions':      'Actions',
      'membres.none':         'Aucun membre trouvé',
      'membres.retry':        'Réessayer',
      /* Choristes */
      'choristes.title':      'Choristes',
      'choristes.new':        'Nouveau choriste',
      'choristes.search':     'Rechercher un choriste...',
      'choristes.none':       'Aucun choriste enregistré',
      /* Cotisations */
      'cotisations.title':    'Cotisations',
      'cotisations.new':      'Nouvelle cotisation',
      'cotisations.all':      'Toutes',
      'cotisations.paid':     'Payées',
      'cotisations.pending':  'En attente',
      'cotisations.overdue':  'En retard',
      'cotisations.none':     'Aucune cotisation',
      /* Événements */
      'events.title':         'Événements',
      'events.new':           'Nouvel événement',
      'events.search':        'Rechercher un événement...',
      'events.none':          'Aucun événement',
      'events.all_types':     'Tous les types',
      /* Messages */
      'messages.title':       'Messagerie',
      'messages.new':         'Nouveau message',
      'messages.search':      'Rechercher...',
      'messages.none':        'Aucun message',
      'messages.inbox':       'Messages reçus',
      'messages.sent':        'Envoyés',
      'messages.read':        'Lu',
      'messages.unread':      'Non lu',
      /* Statistiques */
      'stats.title':          'Statistiques',
      'stats.overview':       'Vue d\'ensemble',
      'stats.by_region':      'Par région',
      'stats.by_continent':   'Par continent',
      'stats.by_country':     'Par pays',
      'stats.promotions':     'Promotions',
      /* Promotions */
      'promo.title':          'Promotions',
      'promo.new':            'Nouvelle promotion',
      'promo.history':        'Historique des promotions',
      'promo.search':         'Rechercher un membre...',
      'promo.none':           'Aucune promotion enregistrée',
      'promo.confirm':        'Confirmer la promotion',
      'promo.grade_from':     'Grade actuel',
      'promo.grade_to':       'Nouveau grade',
      'promo.reason':         'Motif',
      /* Comptes utilisateurs */
      'users.title':          'Gestion des Comptes',
      'users.new':            'Nouveau compte',
      'users.new_parish':     'Créer un compte paroisse',
      'users.none':           'Aucun compte paroisse',
      'users.none_sub':       'Créez un compte pour permettre à une paroisse de se connecter.',
      'users.name':           'Nom / Paroisse',
      'users.username':       'Identifiant',
      'users.email':          'Email',
      'users.role':           'Rôle',
      'users.church':         'Église liée',
      'users.status':         'Statut',
      'users.actions':        'Actions',
      'users.active':         'Actif',
      'users.disabled':       'Désactivé',
      'users.no_email':       'Non renseigné',
      'users.all':            'Toutes',
      /* Carte */
      'map.zoom_in':          'Zoom +',
      'map.zoom_out':         'Zoom -',
      /* Import/Export */
      'import.title':         'Import CSV',
      'export.title':         'Export & Impression',
      /* Calendrier */
      'calendar.title':       'Calendrier Liturgique',
      /* À propos */
      'about.title':          'À propos',
      /* Erreurs génériques */
      'err.access_denied':    'Accès refusé',
      'err.admin_only':       'Seul un administrateur peut gérer les comptes.',
      'err.loading':          'Erreur de chargement',
    },

    en: {
      /* Navigation / titres */
      'nav.dashboard':        'Dashboard',
      'nav.stats':            'Statistics',
      'nav.map':              'Parish Map',
      'nav.regions':          'Regions',
      'nav.sous_regions':     'Sub-regions',
      'nav.eglises':          'Churches',
      'nav.my_church':        'My Church',
      'nav.members':          'Faithful & Members',
      'nav.history':          'History',
      'nav.committees':       'National Committees',
      'nav.children_aj':      'AJ Children',
      'nav.choristes':        'Choir Members',
      'nav.messages':         'Messages',
      'nav.events':           'Events',
      'nav.calendar':         'Liturgical Calendar',
      'nav.contributions':    'Contributions',
      'nav.tools':            'Tools',
      'nav.import':           'Import CSV',
      'nav.export':           'Export & Print',
      'nav.notifications':    'Notifications',
      'nav.about':            'About',
      'nav.admin':            'Administration',
      'nav.users':            'Users',
      'nav.promotions':       'Promotions',
      'role.saint_siege':     'Saint Siège',
      'role.admin':           'Administrator',
      'role.secretaire':      'Secretary',
      'role.lecteur':         'Reader',
      /* Sections sidebar */
      'section.principal':    'Main',
      'section.hierarchy':    'Hierarchy',
      'section.members':      'Members',
      'section.messaging':    'Messaging',
      'section.activities':   'Activities',
      'section.info':         'Information',
      /* Topbar */
      'topbar.search':        'Global search...',
      'topbar.darkmode':      'Dark / light mode',
      'topbar.language':      'Passer en Français',
      'topbar.add':           'Add',
      /* Login */
      'login.title':          'Sign In',
      'login.subtitle':       'Communauté Céleste — Parish System',
      'login.username':       'Username',
      'login.password':       'Password',
      'login.btn':            'Sign In',
      'login.forgot':         'Forgot password?',
      'login.remember':       'Stay signed in',
      /* Boutons communs */
      'btn.save':             'Save',
      'btn.cancel':           'Cancel',
      'btn.edit':             'Edit',
      'btn.delete':           'Delete',
      'btn.add':              'Add',
      'btn.close':            'Close',
      'btn.export_pdf':       'Export PDF',
      'btn.print':            'Print',
      'btn.filter':           'Filter',
      'btn.search':           'Search',
      'btn.confirm':          'Confirm',
      'btn.retry':            'Retry',
      /* Statuts */
      'status.active':        'Active',
      'status.inactive':      'Inactive',
      'status.pending':       'Pending',
      /* Carte */
      'map.title':            'Parish Map',
      'map.all_regions':      'All regions',
      'map.all_statuts':      'All statuses',
      'map.active':           'Active',
      'map.inactive':         'Inactive',
      'map.positioned':       'church(es) positioned',
      'map.center':           'Reset View',
      'map.locate':           'Locate',
      'map.position':         'Position',
      'map.no_coords':        'No GPS coordinates — click "Position"',
      'map.add_coords':       'Add coordinates',
      'map.click_info':       'Click a marker for details',
      /* Onboarding */
      'onboard.title':        'Welcome! 👋',
      'onboard.subtitle':     'Let\'s set up your system in 4 steps',
      'onboard.step1':        'Create a Region',
      'onboard.step2':        'Create a Sub-region',
      'onboard.step3':        'Register a Church',
      'onboard.step4':        'Add a Member',
      'onboard.skip':         'Skip for now',
      'onboard.next':         'Next →',
      'onboard.finish':       'Finish',
      /* Messages génériques */
      'msg.loading':          'Loading...',
      'msg.no_result':        'No results found',
      'msg.error':            'An error occurred',
      'msg.saved':            'Saved successfully',
      'msg.deleted':          'Deleted successfully',
      'msg.confirm_delete':   'Are you sure you want to delete this item?',
      'msg.offline':          'Offline mode — Changes will sync when reconnected.',
      /* Dashboard */
      'dash.total_members':   'Total members',
      'dash.active_members':  'Active members',
      'dash.men':             'Men',
      'dash.women':           'Women',
      'dash.events':          'Events',
      'dash.messages':        'Messages',
      'dash.title':           'Dashboard',
      'dash.subtitle':        'Parish census overview',
      'dash.send_msg':        'Send a message',
      'dash.regions':         'Regions',
      'dash.sous_regions':    'Sub-regions',
      'dash.active_churches': 'Active churches',
      'dash.upcoming_events': 'Upcoming events',
      'dash.contributions':   'Contributions received',
      'dash.unread_replies':  'Unread replies',
      'dash.sent_messages':   'Messages sent',
      'dash.hierarchy':       'Hierarchical Structure',
      'dash.see_all':         'See all',
      'dash.recent_members':  'Recent members',
      'dash.see_all_members': 'See all',
      'dash.no_members':      'No members registered',
      'dash.upcoming_events_title': 'Upcoming events',
      'dash.no_events':       'No upcoming events',
      'dash.religious_feasts':'Upcoming religious feasts',
      'dash.today':           'Today!',
      'dash.in_days':         'In {{n}} day(s)',
      /* Régions */
      'regions.title':        'Regions',
      'regions.new':          'New region',
      'regions.search':       'Search a region...',
      'regions.none':         'No regions',
      'regions.none_sub':     'Start by creating your first region.',
      'regions.create':       'Create a region',
      'regions.sub_count':    'sub-region(s)',
      'regions.church_count': 'church(es)',
      'regions.member_count': 'member(s)',
      'regions.form_name':    'Region name',
      'regions.form_resp':    'Manager',
      'regions.form_grade':   'Manager grade',
      'regions.form_desc':    'Description',
      /* Sous-régions */
      'srs.title':            'Sub-regions',
      'srs.new':              'New sub-region',
      'srs.search':           'Search a sub-region...',
      'srs.none':             'No sub-regions',
      /* Églises */
      'eglises.title':        'Parishes & Churches',
      'eglises.new':          'New church',
      'eglises.search':       'Search a church...',
      'eglises.none':         'No churches registered',
      'eglises.all_regions':  'All regions',
      'eglises.all_statuts':  'All statuses',
      'eglises.active':       'Active',
      'eglises.inactive':     'Inactive',
      'eglises.export':       'Export',
      /* Membres */
      'membres.title':        'Members & Faithful',
      'membres.new':          'New member',
      'membres.search':       'Search a member...',
      'membres.all_churches': 'All churches',
      'membres.all_grades':   'All grades',
      'membres.all_roles':    'All roles',
      'membres.all':          'All',
      'membres.men':          '♂ Men',
      'membres.women':        '♀ Women',
      'membres.all_statuts':  'All statuses',
      'membres.active':       'Active',
      'membres.inactive':     'Inactive',
      'membres.suspended':    'Suspended',
      'membres.view_table':   'Table',
      'membres.view_cards':   'Cards',
      'membres.export':       'Export',
      'membres.nom':          'Last name',
      'membres.prenom':       'First name',
      'membres.role':         'Role',
      'membres.grade':        'Grade',
      'membres.church':       'Church',
      'membres.phone':        'Phone',
      'membres.statut':       'Status',
      'membres.actions':      'Actions',
      'membres.none':         'No members found',
      'membres.retry':        'Retry',
      /* Choristes */
      'choristes.title':      'Choir Members',
      'choristes.new':        'New choir member',
      'choristes.search':     'Search a choir member...',
      'choristes.none':       'No choir members registered',
      /* Cotisations */
      'cotisations.title':    'Contributions',
      'cotisations.new':      'New contribution',
      'cotisations.all':      'All',
      'cotisations.paid':     'Paid',
      'cotisations.pending':  'Pending',
      'cotisations.overdue':  'Overdue',
      'cotisations.none':     'No contributions',
      /* Événements */
      'events.title':         'Events',
      'events.new':           'New event',
      'events.search':        'Search an event...',
      'events.none':          'No events',
      'events.all_types':     'All types',
      /* Messages */
      'messages.title':       'Messaging',
      'messages.new':         'New message',
      'messages.search':      'Search...',
      'messages.none':        'No messages',
      'messages.inbox':       'Inbox',
      'messages.sent':        'Sent',
      'messages.read':        'Read',
      'messages.unread':      'Unread',
      /* Statistiques */
      'stats.title':          'Statistics',
      'stats.overview':       'Overview',
      'stats.by_region':      'By region',
      'stats.by_continent':   'By continent',
      'stats.by_country':     'By country',
      'stats.promotions':     'Promotions',
      /* Promotions */
      'promo.title':          'Promotions',
      'promo.new':            'New promotion',
      'promo.history':        'Promotion history',
      'promo.search':         'Search a member...',
      'promo.none':           'No promotions recorded',
      'promo.confirm':        'Confirm promotion',
      'promo.grade_from':     'Current grade',
      'promo.grade_to':       'New grade',
      'promo.reason':         'Reason',
      /* Comptes utilisateurs */
      'users.title':          'Account Management',
      'users.new':            'New account',
      'users.new_parish':     'Create parish account',
      'users.none':           'No parish accounts',
      'users.none_sub':       'Create an account to allow a parish to log in.',
      'users.name':           'Name / Parish',
      'users.username':       'Username',
      'users.email':          'Email',
      'users.role':           'Role',
      'users.church':         'Linked church',
      'users.status':         'Status',
      'users.actions':        'Actions',
      'users.active':         'Active',
      'users.disabled':       'Disabled',
      'users.no_email':       'Not provided',
      'users.all':            'All',
      /* Carte */
      'map.zoom_in':          'Zoom in',
      'map.zoom_out':         'Zoom out',
      /* Import/Export */
      'import.title':         'Import CSV',
      'export.title':         'Export & Print',
      /* Calendrier */
      'calendar.title':       'Liturgical Calendar',
      /* À propos */
      'about.title':          'About',
      /* Erreurs génériques */
      'err.access_denied':    'Access denied',
      'err.admin_only':       'Only an administrator can manage accounts.',
      'err.loading':          'Loading error',
    }
  };

  /* ── État interne ────────────────────────────────────────────── */
  let _lang = localStorage.getItem('cc_lang') || 'fr';

  /* ── API publique ────────────────────────────────────────────── */
  return {

    /** Langue courante */
    get lang() { return _lang; },

    /** Initialise i18n au démarrage (applique la langue stockée) */
    init() {
      _lang = localStorage.getItem('cc_lang') || 'fr';
      this._applyToDOM();
      this._updateToggleBtn();
      this._updateSearchPlaceholder();
    },

    /**
     * Traduit une clé.
     * @param {string} key
     * @param {Object} [vars] — variables {name: 'Valeur'} → {{name}}
     * @returns {string}
     */
    t(key, vars = {}) {
      const dict = DICT[_lang] || DICT.fr;
      let str = dict[key] || DICT.fr[key] || key;
      Object.keys(vars).forEach(k => {
        str = str.replace(new RegExp(`{{${k}}}`, 'g'), vars[k]);
      });
      return str;
    },

    /** Bascule FR ↔ EN */
    toggle() {
      _lang = _lang === 'fr' ? 'en' : 'fr';
      localStorage.setItem('cc_lang', _lang);
      this._applyToDOM();
      this._updateToggleBtn();
      this._updateSearchPlaceholder();
      /* Rafraîchit la page courante pour re-render le contenu */
      if (typeof App !== 'undefined' && App.currentPage) {
        App.navigate(App.currentPage);
      }
    },

    /**
     * Applique les traductions aux éléments [data-i18n]
     * Ex : <span data-i18n="nav.dashboard"></span>
     */
    _applyToDOM() {
      document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        const attr = el.getAttribute('data-i18n-attr'); // ex: "placeholder"
        const translated = this.t(key);
        if (attr) {
          el.setAttribute(attr, translated);
        } else {
          el.textContent = translated;
        }
      });
      /* Langue HTML */
      document.documentElement.lang = _lang;
    },

    /** Met à jour le bouton langue dans la topbar */
    _updateToggleBtn() {
      const btn = document.getElementById('langToggleBtn');
      if (!btn) return;
      btn.title = _lang === 'fr' ? 'Switch to English' : 'Passer en Français';
      btn.innerHTML = _lang === 'fr'
        ? '<span style="font-size:15px">🇬🇧</span>'
        : '<span style="font-size:15px">🇫🇷</span>';
      btn.setAttribute('aria-label', btn.title);
    },

    /** Met à jour le placeholder de la barre de recherche */
    _updateSearchPlaceholder() {
      const input = document.getElementById('globalSearch');
      if (input) input.placeholder = this.t('topbar.search');
    }
  };
})();
